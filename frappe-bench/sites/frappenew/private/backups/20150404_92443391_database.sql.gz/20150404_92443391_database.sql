-- MySQL dump 10.14  Distrib 5.5.42-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: 62179b8d82
-- ------------------------------------------------------
-- Server version	5.5.42-MariaDB-1~trusty-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `__Auth`
--

DROP TABLE IF EXISTS `__Auth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `__Auth` (
  `user` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`user`),
  KEY `user` (`user`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `__Auth`
--

LOCK TABLES `__Auth` WRITE;
/*!40000 ALTER TABLE `__Auth` DISABLE KEYS */;
INSERT INTO `__Auth` VALUES ('Administrator','*4ACFE3202A5FF5CF467898FC58AAB1D615029441');
/*!40000 ALTER TABLE `__Auth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabAbout Us Team Member`
--

DROP TABLE IF EXISTS `tabAbout Us Team Member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabAbout Us Team Member` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `image_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabAbout Us Team Member`
--

LOCK TABLES `tabAbout Us Team Member` WRITE;
/*!40000 ALTER TABLE `tabAbout Us Team Member` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabAbout Us Team Member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabBlock Module`
--

DROP TABLE IF EXISTS `tabBlock Module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabBlock Module` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `module` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabBlock Module`
--

LOCK TABLES `tabBlock Module` WRITE;
/*!40000 ALTER TABLE `tabBlock Module` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabBlock Module` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabBlog Category`
--

DROP TABLE IF EXISTS `tabBlog Category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabBlog Category` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `published` int(1) DEFAULT NULL,
  `parent_website_route` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'blog',
  `category_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `page_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabBlog Category`
--

LOCK TABLES `tabBlog Category` WRITE;
/*!40000 ALTER TABLE `tabBlog Category` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabBlog Category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabBlog Post`
--

DROP TABLE IF EXISTS `tabBlog Post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabBlog Post` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `parent_website_route` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published_on` date DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blogger` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_sent` int(1) DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `page_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published` int(1) DEFAULT NULL,
  `blog_category` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blog_intro` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabBlog Post`
--

LOCK TABLES `tabBlog Post` WRITE;
/*!40000 ALTER TABLE `tabBlog Post` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabBlog Post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabBlogger`
--

DROP TABLE IF EXISTS `tabBlogger`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabBlogger` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `short_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `posts` int(11) DEFAULT NULL,
  `disabled` int(1) DEFAULT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabBlogger`
--

LOCK TABLES `tabBlogger` WRITE;
/*!40000 ALTER TABLE `tabBlogger` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabBlogger` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabBulk Email`
--

DROP TABLE IF EXISTS `tabBulk Email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabBulk Email` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Not Sent',
  `reference_doctype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sender` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `send_after` datetime(6) DEFAULT NULL,
  `error` text COLLATE utf8mb4_unicode_ci,
  `message` longtext COLLATE utf8mb4_unicode_ci,
  `recipient` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabBulk Email`
--

LOCK TABLES `tabBulk Email` WRITE;
/*!40000 ALTER TABLE `tabBulk Email` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabBulk Email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabComment`
--

DROP TABLE IF EXISTS `tabComment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabComment` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `comment_date` date DEFAULT NULL,
  `comment_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `post_topic` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment_docname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment_time` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unsubscribed` int(1) DEFAULT NULL,
  `comment_doctype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment_by_fullname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`),
  KEY `comment_doctype_docname_index` (`comment_doctype`,`comment_docname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabComment`
--

LOCK TABLES `tabComment` WRITE;
/*!40000 ALTER TABLE `tabComment` DISABLE KEYS */;
INSERT INTO `tabComment` VALUES ('626a649de3','2015-04-04 15:11:31.019339','2015-04-04 15:11:31.019339','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Administrator shared this document with Guest',NULL,'Shared','Administrator',NULL,'Guest',NULL,0,'User',NULL),('c61a47eaf6','2015-04-04 15:11:30.994555','2015-04-04 15:11:30.994555','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Administrator shared this document with Administrator',NULL,'Shared','Administrator',NULL,'Administrator',NULL,0,'User',NULL);
/*!40000 ALTER TABLE `tabComment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabCommunication`
--

DROP TABLE IF EXISTS `tabCommunication`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabCommunication` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `naming_series` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'COMM-',
  `email_account` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_doctype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unread_notification_sent` int(1) DEFAULT '0',
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `communication_medium` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recipients` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `_user_tags` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sender` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sent_or_received` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sender_full_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `communication_date` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`),
  KEY `reference_doctype_reference_name_index` (`reference_doctype`,`reference_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabCommunication`
--

LOCK TABLES `tabCommunication` WRITE;
/*!40000 ALTER TABLE `tabCommunication` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabCommunication` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabCompany History`
--

DROP TABLE IF EXISTS `tabCompany History`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabCompany History` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `highlight` text COLLATE utf8mb4_unicode_ci,
  `year` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabCompany History`
--

LOCK TABLES `tabCompany History` WRITE;
/*!40000 ALTER TABLE `tabCompany History` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabCompany History` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabCountry`
--

DROP TABLE IF EXISTS `tabCountry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabCountry` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `country_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_format` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time_zones` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabCountry`
--

LOCK TABLES `tabCountry` WRITE;
/*!40000 ALTER TABLE `tabCountry` DISABLE KEYS */;
INSERT INTO `tabCountry` VALUES ('Afghanistan',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Afghanistan','dd-mm-yyyy','af','Asia/Kabul'),('Åland Islands',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Åland Islands','dd-mm-yyyy','ax',''),('Albania',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Albania','dd-mm-yyyy','al','Europe/Tirane'),('Algeria',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Algeria','dd-mm-yyyy','dz','Africa/Algiers'),('American Samoa',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'American Samoa','dd-mm-yyyy','as',''),('Andorra',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Andorra','dd-mm-yyyy','ad','Europe/Andorra'),('Angola',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Angola','dd-mm-yyyy','ao','Africa/Luanda'),('Anguilla',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Anguilla','dd-mm-yyyy','ai','America/Anguilla'),('Antarctica',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Antarctica','dd-mm-yyyy','aq','Antarctica/Casey\nAntarctica/Davis\nAntarctica/DumontDUrville\nAntarctica/Macquarie\nAntarctica/Mawson\nAntarctica/McMurdo\nAntarctica/Palmer\nAntarctica/Rothera\nAntarctica/Syowa\nAntarctica/Vostok'),('Antigua and Barbuda',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Antigua and Barbuda','dd-mm-yyyy','ag','America/Antigua'),('Argentina',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Argentina','dd-mm-yyyy','ar','America/Argentina/Buenos_Aires\nAmerica/Argentina/Catamarca\nAmerica/Argentina/Cordoba\nAmerica/Argentina/Jujuy\nAmerica/Argentina/La_Rioja\nAmerica/Argentina/Mendoza\nAmerica/Argentina/Rio_Gallegos\nAmerica/Argentina/Salta\nAmerica/Argentina/San_Juan\nAmerica/Argentina/San_Luis\nAmerica/Argentina/Tucuman\nAmerica/Argentina/Ushuaia'),('Armenia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Armenia','dd-mm-yyyy','am','Asia/Yerevan'),('Aruba',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Aruba','dd-mm-yyyy','aw','America/Aruba'),('Australia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Australia','dd-mm-yyyy','au','Australia/Adelaide\nAustralia/Brisbane\nAustralia/Broken_Hill\nAustralia/Currie\nAustralia/Darwin\nAustralia/Eucla\nAustralia/Hobart\nAustralia/Lindeman\nAustralia/Lord_Howe\nAustralia/Melbourne\nAustralia/Perth\nAustralia/Sydney'),('Austria',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Austria','dd-mm-yyyy','at','Europe/Vienna'),('Azerbaijan',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Azerbaijan','dd-mm-yyyy','az','Asia/Baku'),('Bahamas',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Bahamas','dd-mm-yyyy','bs','America/Nassau'),('Bahrain',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Bahrain','dd-mm-yyyy','bh','Asia/Bahrain'),('Bangladesh',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Bangladesh','dd-mm-yyyy','bd','Asia/Dhaka'),('Barbados',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Barbados','dd-mm-yyyy','bb','America/Barbados'),('Belarus',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Belarus','dd-mm-yyyy','by','Europe/Minsk'),('Belgium',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Belgium','dd-mm-yyyy','be','Europe/Brussels'),('Belize',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Belize','mm-dd-yyyy','bz','America/Belize'),('Benin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Benin','dd-mm-yyyy','bj','Africa/Porto-Novo'),('Bermuda',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Bermuda','dd-mm-yyyy','bm','Atlantic/Bermuda'),('Bhutan',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Bhutan','dd-mm-yyyy','bt','Asia/Thimphu'),('Bolivia, Plurinational State of',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Bolivia, Plurinational State of','dd-mm-yyyy','bo',''),('Bonaire, Sint Eustatius and Saba',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Bonaire, Sint Eustatius and Saba','dd-mm-yyyy','bq',''),('Bosnia and Herzegovina',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Bosnia and Herzegovina','dd-mm-yyyy','ba','Europe/Belgrade'),('Botswana',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Botswana','dd-mm-yyyy','bw','Africa/Gaborone'),('Bouvet Island',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Bouvet Island','dd-mm-yyyy','bv',''),('Brazil',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Brazil','dd/mm/yyyy','br','America/Araguaina\nAmerica/Bahia\nAmerica/Belem\nAmerica/Boa_Vista\nAmerica/Campo_Grande\nAmerica/Cuiaba\nAmerica/Eirunepe\nAmerica/Fortaleza\nAmerica/Maceio\nAmerica/Manaus\nAmerica/Noronha\nAmerica/Porto_Velho\nAmerica/Recife\nAmerica/Rio_Branco\nAmerica/Santarem\nAmerica/Sao_Paulo'),('British Indian Ocean Territory',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'British Indian Ocean Territory','dd-mm-yyyy','io','Indian/Chagos'),('Brunei Darussalam',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Brunei Darussalam','dd-mm-yyyy','bn','Asia/Brunei'),('Bulgaria',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Bulgaria','dd-mm-yyyy','bg','Europe/Sofia'),('Burkina Faso',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Burkina Faso','dd-mm-yyyy','bf','Africa/Ouagadougou'),('Burundi',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Burundi','dd-mm-yyyy','bi','Africa/Bujumbura'),('Cambodia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Cambodia','dd-mm-yyyy','kh','Asia/Phnom_Penh'),('Cameroon',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Cameroon','dd-mm-yyyy','cm','Africa/Douala'),('Canada',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Canada','mm-dd-yyyy','ca','America/Atikokan\nAmerica/Blanc-Sablon\nAmerica/Cambridge_Bay\nAmerica/Creston\nAmerica/Dawson\nAmerica/Dawson_Creek\nAmerica/Edmonton\nAmerica/Glace_Bay\nAmerica/Goose_Bay\nAmerica/Halifax\nAmerica/Inuvik\nAmerica/Iqaluit\nAmerica/Moncton\nAmerica/Montreal\nAmerica/Nipigon\nAmerica/Pangnirtung\nAmerica/Rainy_River\nAmerica/Rankin_Inlet\nAmerica/Regina\nAmerica/Resolute\nAmerica/St_Johns\nAmerica/Swift_Current\nAmerica/Thunder_Bay\nAmerica/Toronto\nAmerica/Vancouver\nAmerica/Whitehorse\nAmerica/Winnipeg\nAmerica/Yellowknife'),('Cape Verde',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Cape Verde','dd-mm-yyyy','cv','Atlantic/Cape_Verde'),('Cayman Islands',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Cayman Islands','dd-mm-yyyy','ky','America/Cayman'),('Central African Republic',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Central African Republic','dd-mm-yyyy','cf','Africa/Bangui'),('Chad',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Chad','dd-mm-yyyy','td','Africa/Ndjamena'),('Chile',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Chile','dd-mm-yyyy','cl','America/Santiago\nPacific/Easter'),('China',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'China','yyyy-mm-dd','cn','Asia/Chongqing\nAsia/Harbin\nAsia/Kashgar\nAsia/Shanghai\nAsia/Urumqi'),('Christmas Island',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Christmas Island','dd-mm-yyyy','cx','Indian/Christmas'),('Cocos (Keeling) Islands',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Cocos (Keeling) Islands','dd-mm-yyyy','cc','Indian/Cocos'),('Colombia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Colombia','dd-mm-yyyy','co','America/Bogota'),('Comoros',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Comoros','dd-mm-yyyy','km','Indian/Comoro'),('Congo',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Congo','dd-mm-yyyy','cg',''),('Congo, The Democratic Republic of the',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Congo, The Democratic Republic of the','dd-mm-yyyy',NULL,''),('Cook Islands',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Cook Islands','dd-mm-yyyy','ck','Pacific/Rarotonga'),('Costa Rica',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Costa Rica','dd-mm-yyyy','cr','America/Costa_Rica'),('Croatia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Croatia','dd-mm-yyyy','hr','Europe/Belgrade'),('Cuba',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Cuba','dd-mm-yyyy','cu','America/Havana'),('Curaçao',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Curaçao','dd-mm-yyyy','cw',''),('Cyprus',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Cyprus','dd-mm-yyyy','cy','Asia/Nicosia'),('Czech Republic',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Czech Republic','dd-mm-yyyy','cz','Europe/Prague'),('Denmark',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Denmark','dd-mm-yyyy','dk','Europe/Copenhagen'),('Djibouti',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Djibouti','dd-mm-yyyy','dj','Africa/Djibouti'),('Dominica',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Dominica','dd-mm-yyyy','dm','America/Dominica'),('Dominican Republic',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Dominican Republic','dd-mm-yyyy','do','America/Santo_Domingo'),('Ecuador',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Ecuador','dd-mm-yyyy','ec','America/Guayaquil\nPacific/Galapagos'),('Egypt',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Egypt','dd-mm-yyyy','eg','Africa/Cairo'),('El Salvador',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'El Salvador','dd-mm-yyyy','sv','America/El_Salvador'),('Equatorial Guinea',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Equatorial Guinea','dd-mm-yyyy','gq','Africa/Malabo'),('Eritrea',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Eritrea','dd-mm-yyyy','er','Africa/Asmara'),('Estonia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Estonia','dd-mm-yyyy','ee','Europe/Tallinn'),('Ethiopia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Ethiopia','dd-mm-yyyy','et','Africa/Addis_Ababa'),('Falkland Islands (Malvinas)',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Falkland Islands (Malvinas)','dd-mm-yyyy','fk',''),('Faroe Islands',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Faroe Islands','dd-mm-yyyy','fo','Atlantic/Faroe'),('Fiji',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Fiji','dd-mm-yyyy','fj','Pacific/Fiji'),('Finland',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Finland','dd-mm-yyyy','fi','Europe/Helsinki'),('France',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'France','dd-mm-yyyy','fr','Europe/Paris'),('French Guiana',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'French Guiana','dd-mm-yyyy','gf','America/Cayenne'),('French Polynesia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'French Polynesia','dd-mm-yyyy','pf','Pacific/Gambier\nPacific/Marquesas\nPacific/Tahiti'),('French Southern Territories',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'French Southern Territories','dd-mm-yyyy','tf',''),('Gabon',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Gabon','dd-mm-yyyy','ga','Africa/Libreville'),('Gambia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Gambia','dd-mm-yyyy','gm','Africa/Banjul'),('Georgia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Georgia','dd-mm-yyyy','ge','Asia/Tbilisi'),('Germany',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Germany','dd-mm-yyyy','de','Europe/Berlin'),('Ghana',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Ghana','dd-mm-yyyy','gh','Africa/Accra'),('Gibraltar',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Gibraltar','dd-mm-yyyy','gi','Europe/Gibraltar'),('Greece',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Greece','dd-mm-yyyy','gr','Europe/Athens'),('Greenland',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Greenland','dd-mm-yyyy','gl','America/Danmarkshavn\nAmerica/Godthab\nAmerica/Scoresbysund\nAmerica/Thule'),('Grenada',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Grenada','dd-mm-yyyy','gd','America/Grenada'),('Guadeloupe',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Guadeloupe','dd-mm-yyyy','gp','America/Guadeloupe'),('Guam',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Guam','dd-mm-yyyy','gu','Pacific/Guam'),('Guatemala',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Guatemala','dd-mm-yyyy','gt','America/Guatemala'),('Guernsey',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Guernsey','dd-mm-yyyy','gg','Europe/London'),('Guinea',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Guinea','dd-mm-yyyy','gn','Africa/Conakry'),('Guinea-Bissau',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Guinea-Bissau','dd-mm-yyyy','gw','Africa/Bissau'),('Guyana',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Guyana','dd-mm-yyyy','gy','America/Guyana'),('Haiti',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Haiti','dd-mm-yyyy','ht','America/Guatemala\nAmerica/Port-au-Prince'),('Heard Island and McDonald Islands',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Heard Island and McDonald Islands','dd-mm-yyyy','hm',''),('Holy See (Vatican City State)',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Holy See (Vatican City State)','dd-mm-yyyy','va',''),('Honduras',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Honduras','dd-mm-yyyy','hn','America/Tegucigalpa'),('Hong Kong',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Hong Kong','dd-mm-yyyy','hk','Asia/Hong_Kong'),('Hungary',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Hungary','yyyy-mm-dd','hu','Europe/Budapest'),('Iceland',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Iceland','dd-mm-yyyy','is','Atlantic/Reykjavik'),('India',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'India','dd-mm-yyyy','in','Asia/Kolkata'),('Indonesia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Indonesia','dd-mm-yyyy','id','Asia/Jakarta\nAsia/Jayapura\nAsia/Makassar\nAsia/Pontianak'),('Iran, Islamic Republic of',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Iran, Islamic Republic of','dd-mm-yyyy','ir',''),('Iraq',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Iraq','dd-mm-yyyy','iq','Asia/Baghdad'),('Ireland',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Ireland','dd-mm-yyyy','ie','Europe/Dublin'),('Isle of Man',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Isle of Man','dd-mm-yyyy','im','Europe/London'),('Israel',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Israel','dd-mm-yyyy','il','Asia/Jerusalem'),('Italy',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Italy','dd-mm-yyyy','it','Europe/Rome'),('Ivory Coast',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Ivory Coast','dd-mm-yyyy',NULL,''),('Jamaica',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Jamaica','dd-mm-yyyy','jm','America/Jamaica'),('Japan',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Japan','dd-mm-yyyy','jp','Asia/Tokyo'),('Jersey',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Jersey','dd-mm-yyyy','je','Europe/London'),('Jordan',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Jordan','dd-mm-yyyy','jo','Asia/Amman'),('Kazakhstan',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Kazakhstan','dd-mm-yyyy','kz','Asia/Almaty\nAsia/Aqtau\nAsia/Aqtobe\nAsia/Oral\nAsia/Qyzylorda'),('Kenya',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Kenya','dd-mm-yyyy','ke','Africa/Nairobi'),('Kiribati',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Kiribati','dd-mm-yyyy','ki','Pacific/Enderbury\nPacific/Kiritimati\nPacific/Tarawa'),('Korea, Democratic Peoples Republic of',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Korea, Democratic Peoples Republic of','dd-mm-yyyy',NULL,''),('Korea, Republic of',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Korea, Republic of','dd-mm-yyyy','kr',''),('Kuwait',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Kuwait','dd-mm-yyyy','kw','Asia/Kuwait'),('Kyrgyzstan',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Kyrgyzstan','dd-mm-yyyy','kg','Asia/Bishkek'),('Lao Peoples Democratic Republic',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Lao Peoples Democratic Republic','dd-mm-yyyy',NULL,''),('Latvia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Latvia','dd-mm-yyyy','lv','Europe/Riga'),('Lebanon',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Lebanon','dd-mm-yyyy','lb','Asia/Beirut'),('Lesotho',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Lesotho','dd-mm-yyyy','ls','Africa/Maseru'),('Liberia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Liberia','dd-mm-yyyy','lr','Africa/Monrovia'),('Libya',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Libya','dd-mm-yyyy','ly','Africa/Tripoli'),('Liechtenstein',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Liechtenstein','dd-mm-yyyy','li','Europe/Vaduz'),('Lithuania',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Lithuania','yyyy-mm-dd','lt','Europe/Vilnius'),('Luxembourg',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Luxembourg','dd-mm-yyyy','lu','Europe/Luxembourg'),('Macao',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Macao','dd-mm-yyyy','mo',''),('Macedonia, Republic of',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Macedonia, Republic of','dd-mm-yyyy',NULL,''),('Madagascar',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Madagascar','dd-mm-yyyy','mg','Indian/Antananarivo'),('Malawi',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Malawi','dd-mm-yyyy','mw','Africa/Blantyre'),('Malaysia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Malaysia','dd-mm-yyyy','my','Asia/Kuala_Lumpur\nAsia/Kuching'),('Maldives',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Maldives','dd-mm-yyyy','mv','Indian/Maldives'),('Mali',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Mali','dd-mm-yyyy','ml','Africa/Bamako'),('Malta',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Malta','dd-mm-yyyy','mt','Europe/Malta'),('Marshall Islands',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Marshall Islands','dd-mm-yyyy','mh','Pacific/Kwajalein\nPacific/Majuro'),('Martinique',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Martinique','dd-mm-yyyy','mq','America/Martinique'),('Mauritania',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Mauritania','dd-mm-yyyy','mr','Africa/Nouakchott'),('Mauritius',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Mauritius','dd-mm-yyyy','mu','Indian/Mauritius'),('Mayotte',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Mayotte','dd-mm-yyyy','yt','Indian/Mayotte'),('Mexico',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Mexico','dd-mm-yyyy','mx','America/Bahia_Banderas\nAmerica/Cancun\nAmerica/Chihuahua\nAmerica/Hermosillo\nAmerica/Matamoros\nAmerica/Mazatlan\nAmerica/Merida\nAmerica/Mexico_City\nAmerica/Monterrey\nAmerica/Ojinaga\nAmerica/Santa_Isabel\nAmerica/Tijuana'),('Micronesia, Federated States of',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Micronesia, Federated States of','dd-mm-yyyy','fm',''),('Moldova, Republic of',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Moldova, Republic of','dd-mm-yyyy','md',''),('Monaco',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Monaco','dd-mm-yyyy','mc','Europe/Monaco'),('Mongolia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Mongolia','yyyy-mm-dd','mn','Asia/Choibalsan\nAsia/Hovd\nAsia/Ulaanbaatar'),('Montenegro',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Montenegro','dd-mm-yyyy','me','Europe/Belgrade'),('Montserrat',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Montserrat','dd-mm-yyyy','ms','America/Montserrat'),('Morocco',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Morocco','dd-mm-yyyy','ma','Africa/Casablanca'),('Mozambique',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Mozambique','dd-mm-yyyy','mz','Africa/Maputo'),('Myanmar',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Myanmar','dd-mm-yyyy','mm','Asia/Rangoon'),('Namibia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Namibia','dd-mm-yyyy','na','Africa/Windhoek'),('Nauru',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Nauru','dd-mm-yyyy','nr','Pacific/Nauru'),('Nepal',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Nepal','dd-mm-yyyy','np','Asia/Kathmandu'),('Netherlands',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Netherlands','dd-mm-yyyy','nl','Europe/Amsterdam'),('New Caledonia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'New Caledonia','dd-mm-yyyy','nc','Pacific/Noumea'),('New Zealand',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'New Zealand','dd-mm-yyyy','nz','Pacific/Auckland\nPacific/Chatham'),('Nicaragua',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Nicaragua','dd-mm-yyyy','ni','America/Managua'),('Niger',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Niger','dd-mm-yyyy','ne','Africa/Niamey'),('Nigeria',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Nigeria','dd-mm-yyyy','ng','Africa/Lagos'),('Niue',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Niue','dd-mm-yyyy','nu','Pacific/Niue'),('Norfolk Island',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Norfolk Island','dd-mm-yyyy','nf','Pacific/Norfolk'),('Northern Mariana Islands',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Northern Mariana Islands','dd-mm-yyyy','mp','Pacific/Saipan'),('Norway',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Norway','dd-mm-yyyy','no','Europe/Oslo'),('Oman',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Oman','dd-mm-yyyy','om','Asia/Muscat'),('Pakistan',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Pakistan','dd-mm-yyyy','pk','Asia/Karachi'),('Palau',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Palau','mm-dd-yyyy','pw','Pacific/Palau'),('Palestinian Territory, Occupied',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Palestinian Territory, Occupied','dd-mm-yyyy',NULL,''),('Panama',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Panama','dd-mm-yyyy','pa','America/Panama'),('Papua New Guinea',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Papua New Guinea','dd-mm-yyyy','pg','Pacific/Port_Moresby'),('Paraguay',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Paraguay','dd-mm-yyyy','py','America/Asuncion'),('Peru',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Peru','dd-mm-yyyy','pe','America/Lima'),('Philippines',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Philippines','mm-dd-yyyy','ph','Asia/Manila'),('Pitcairn',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Pitcairn','dd-mm-yyyy','pn','Pacific/Pitcairn'),('Poland',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Poland','dd-mm-yyyy','pl','Europe/Warsaw'),('Portugal',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Portugal','dd-mm-yyyy','pt','Atlantic/Azores\nAtlantic/Madeira\nEurope/Lisbon'),('Puerto Rico',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Puerto Rico','dd-mm-yyyy','pr','America/Puerto_Rico'),('Qatar',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Qatar','dd-mm-yyyy','qa','Asia/Qatar'),('Réunion',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Réunion','dd-mm-yyyy','re',''),('Romania',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Romania','dd-mm-yyyy','ro','Europe/Bucharest'),('Russian Federation',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Russian Federation','dd-mm-yyyy','ru',''),('Rwanda',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Rwanda','dd-mm-yyyy','rw','Africa/Kigali'),('Saint Barthélemy',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Saint Barthélemy','dd-mm-yyyy','bl',''),('Saint Helena, Ascension and Tristan da Cunha',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Saint Helena, Ascension and Tristan da Cunha','dd-mm-yyyy','sh',''),('Saint Kitts and Nevis',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Saint Kitts and Nevis','dd-mm-yyyy','kn','America/St_Kitts'),('Saint Lucia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Saint Lucia','dd-mm-yyyy','lc','America/St_Lucia'),('Saint Martin (French part)',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Saint Martin (French part)','dd-mm-yyyy','mf',''),('Saint Pierre and Miquelon',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Saint Pierre and Miquelon','dd-mm-yyyy','pm',''),('Saint Vincent and the Grenadines',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Saint Vincent and the Grenadines','dd-mm-yyyy','vc','America/St_Vincent'),('Samoa',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Samoa','dd-mm-yyyy','ws','Pacific/Apia'),('San Marino',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'San Marino','dd-mm-yyyy','sm','Europe/Rome'),('Sao Tome and Principe',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sao Tome and Principe','dd-mm-yyyy','st',''),('Saudi Arabia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Saudi Arabia','dd-mm-yyyy','sa','Asia/Riyadh'),('Senegal',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Senegal','dd-mm-yyyy','sn','Africa/Dakar'),('Serbia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Serbia','dd-mm-yyyy','rs','Europe/Belgrade'),('Seychelles',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Seychelles','dd-mm-yyyy','sc','Indian/Mahe'),('Sierra Leone',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sierra Leone','dd-mm-yyyy','sl','Africa/Freetown'),('Singapore',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Singapore','dd-mm-yyyy','sg','Asia/Singapore'),('Sint Maarten (Dutch part)',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sint Maarten (Dutch part)','dd-mm-yyyy','sx',''),('Slovakia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Slovakia','dd-mm-yyyy','sk','Europe/Prague'),('Slovenia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Slovenia','dd-mm-yyyy','si','Europe/Belgrade'),('Solomon Islands',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Solomon Islands','dd-mm-yyyy','sb','Pacific/Guadalcanal'),('Somalia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Somalia','dd-mm-yyyy','so','Africa/Mogadishu'),('South Africa',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'South Africa','yyyy-mm-dd','za','Africa/Johannesburg'),('South Georgia and the South Sandwich Islands',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'South Georgia and the South Sandwich Islands','dd-mm-yyyy','gs',''),('South Sudan',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'South Sudan','dd-mm-yyyy','ss','Africa/Juba'),('Spain',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Spain','dd-mm-yyyy','es','Africa/Ceuta\nAtlantic/Canary\nEurope/Madrid'),('Sri Lanka',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sri Lanka','dd-mm-yyyy','lk','Asia/Colombo'),('Sudan',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sudan','dd-mm-yyyy','sd','Africa/Khartoum'),('Suriname',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Suriname','dd-mm-yyyy','sr','America/Paramaribo'),('Svalbard and Jan Mayen',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Svalbard and Jan Mayen','dd-mm-yyyy','sj',''),('Swaziland',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Swaziland','dd-mm-yyyy','sz','Africa/Mbabane'),('Sweden',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sweden','dd-mm-yyyy','se','Europe/Stockholm'),('Switzerland',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Switzerland','dd-mm-yyyy','ch','Europe/Zurich'),('Syrian Arab Republic',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Syrian Arab Republic','dd-mm-yyyy','sy',''),('Taiwan',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Taiwan','yyyy-mm-dd','tw',''),('Tajikistan',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tajikistan','dd-mm-yyyy','tj','Asia/Dushanbe'),('Tanzania, United Republic of',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tanzania, United Republic of','dd-mm-yyyy','tz',''),('Thailand',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Thailand','dd-mm-yyyy','th','Asia/Bangkok'),('Timor-Leste',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Timor-Leste','dd-mm-yyyy','tl',''),('Togo',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Togo','dd-mm-yyyy','tg','Africa/Lome'),('Tokelau',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tokelau','dd-mm-yyyy','tk','Pacific/Fakaofo'),('Tonga',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tonga','dd-mm-yyyy','to','Pacific/Tongatapu'),('Trinidad and Tobago',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Trinidad and Tobago','dd-mm-yyyy','tt','America/Port_of_Spain'),('Tunisia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tunisia','dd-mm-yyyy','tn','Africa/Tunis'),('Turkey',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Turkey','dd-mm-yyyy','tr','Europe/Istanbul'),('Turkmenistan',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Turkmenistan','dd-mm-yyyy','tm','Asia/Ashgabat'),('Turks and Caicos Islands',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Turks and Caicos Islands','dd-mm-yyyy','tc',''),('Tuvalu',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Tuvalu','dd-mm-yyyy','tv','Pacific/Funafuti'),('Uganda',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Uganda','dd-mm-yyyy','ug','Africa/Kampala'),('Ukraine',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Ukraine','dd-mm-yyyy','ua','Europe/Kiev\nEurope/Simferopol\nEurope/Uzhgorod\nEurope/Zaporozhye'),('United Arab Emirates',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'United Arab Emirates','dd-mm-yyyy','ae','Asia/Dubai'),('United Kingdom',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'United Kingdom','dd-mm-yyyy','gb','Europe/London'),('United States',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'United States','mm-dd-yyyy','us','America/Adak\nAmerica/Anchorage\nAmerica/Boise\nAmerica/Chicago\nAmerica/Denver\nAmerica/Detroit\nAmerica/Indiana/Indianapolis\nAmerica/Indiana/Knox\nAmerica/Indiana/Marengo\nAmerica/Indiana/Petersburg\nAmerica/Indiana/Tell_City\nAmerica/Indiana/Vevay\nAmerica/Indiana/Vincennes\nAmerica/Indiana/Winamac\nAmerica/Juneau\nAmerica/Kentucky/Louisville\nAmerica/Kentucky/Monticello\nAmerica/Los_Angeles\nAmerica/Menominee\nAmerica/Metlakatla\nAmerica/New_York\nAmerica/Nome\nAmerica/North_Dakota/Beulah\nAmerica/North_Dakota/Center\nAmerica/North_Dakota/New_Salem\nAmerica/Phoenix\nAmerica/Denver\nAmerica/Sitka\nAmerica/Yakutat\nPacific/Honolulu'),('United States Minor Outlying Islands',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'United States Minor Outlying Islands','dd-mm-yyyy','um',''),('Uruguay',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Uruguay','dd-mm-yyyy','uy','America/Montevideo'),('Uzbekistan',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Uzbekistan','dd-mm-yyyy','uz','Asia/Samarkand\nAsia/Tashkent'),('Vanuatu',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Vanuatu','dd-mm-yyyy','vu','Pacific/Efate'),('Venezuela, Bolivarian Republic of',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Venezuela, Bolivarian Republic of','dd-mm-yyyy','ve',''),('Vietnam',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Vietnam','dd-mm-yyyy','vn',''),('Virgin Islands, British',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Virgin Islands, British','dd-mm-yyyy','vg',''),('Virgin Islands, U.S.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Virgin Islands, U.S.','dd-mm-yyyy','vi',''),('Wallis and Futuna',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Wallis and Futuna','dd-mm-yyyy','wf',''),('Western Sahara',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Western Sahara','dd-mm-yyyy','eh','Africa/El_Aaiun'),('Yemen',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Yemen','dd-mm-yyyy','ye','Asia/Aden'),('Zambia',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Zambia','dd-mm-yyyy','zm','Africa/Lusaka'),('Zimbabwe',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Zimbabwe','dd-mm-yyyy','zw','Africa/Harare');
/*!40000 ALTER TABLE `tabCountry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabCurrency`
--

DROP TABLE IF EXISTS `tabCurrency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabCurrency` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `currency_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `symbol` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled` int(1) DEFAULT NULL,
  `fraction_units` int(11) DEFAULT NULL,
  `fraction` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `number_format` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabCurrency`
--

LOCK TABLES `tabCurrency` WRITE;
/*!40000 ALTER TABLE `tabCurrency` DISABLE KEYS */;
INSERT INTO `tabCurrency` VALUES ('AED',NULL,'2015-04-04 15:11:31.471447','Administrator',NULL,NULL,NULL,NULL,NULL,NULL,'AED','د.إ',1,100,'Fils','#,###.##'),('ALL',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALL','L',NULL,100,'Qindarkë','#,###.##'),('AMD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'AMD','֏',NULL,100,'Luma','#,###.##'),('ARS',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ARS','$',NULL,100,'Centavo','#.###,##'),('AUD',NULL,'2015-04-04 15:11:31.471806','Administrator',NULL,NULL,NULL,NULL,NULL,NULL,'AUD','$',1,100,'Cent','# ###.##'),('AWG',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'AWG','Afl',NULL,100,'Cent','#,###.##'),('BBD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'BBD','$',NULL,100,'Cent','#,###.##'),('BDT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'BDT','৳',NULL,100,'Paisa','#,###.##'),('BHD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'BHD','.د.ب',NULL,1000,'Fils','#,###.###'),('BIF',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'BIF','Fr',NULL,100,'Centime','#,###.##'),('BMD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'BMD','$',NULL,100,'Cent','#,###.##'),('BND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'BND',NULL,NULL,NULL,NULL,'#,###.##'),('BOB',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'BOB',NULL,NULL,NULL,NULL,'#,###.##'),('BRL',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'BRL','R$',NULL,100,'Centavo','#.###,##'),('BSD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'BSD',NULL,NULL,NULL,NULL,'#,###.##'),('BTN',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'BTN','Nu.',NULL,100,'Chetrum','#,###.##'),('BWP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'BWP','P',NULL,100,'Thebe','#,###.##'),('BZD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'BZD','$',NULL,100,'Cent','#,###.##'),('CAD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CAD','$',NULL,100,'Cent','#,###.##'),('CHF',NULL,'2015-04-04 15:11:31.472809','Administrator',NULL,NULL,NULL,NULL,NULL,NULL,'CHF','Fr',1,100,'Rappen[K]','#\'###.##'),('CLP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CLP','$',NULL,100,'Centavo','#.###'),('CNY',NULL,'2015-04-04 15:11:31.472477','Administrator',NULL,NULL,NULL,NULL,NULL,NULL,'CNY',NULL,1,NULL,NULL,'#,###.##'),('COP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'COP','$',NULL,100,'Centavo','#.###,##'),('CRC',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CRC','₡',NULL,100,'Céntimo','#.###,##'),('CUP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CUP','$',NULL,100,'Centavo','#,###.##'),('CVE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CVE','Esc or $',NULL,100,'Centavo','#,###.##'),('CYP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CYP','€',NULL,100,'Cent','#.###,##'),('CZK',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CZK','Kč',NULL,100,'Haléř','#.###,##'),('DJF',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'DJF','Fr',NULL,100,'Centime','#,###.##'),('DKK',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'DKK','kr',NULL,100,'Øre','#.###,##'),('DOP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'DOP','$',NULL,100,'Centavo','#,###.##'),('DZD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'DZD','د.ج',NULL,100,'Santeem','#,###.##'),('EEK',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'EEK','€',NULL,100,'Cent','#,###.##'),('EGP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'EGP','£ or ج.م',NULL,100,'Piastre[F]','#,###.##'),('ERN',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ERN','Nfk',NULL,100,'Cent','#,###.##'),('EUR',NULL,'2015-04-04 15:11:31.471101','Administrator',NULL,NULL,NULL,NULL,NULL,NULL,'EUR','€',1,100,'Cent','#,###.##'),('FJD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'FJD','$',NULL,100,'Cent','#,###.##'),('FKP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'FKP',NULL,NULL,NULL,NULL,'#,###.##'),('GBP',NULL,'2015-04-04 15:11:31.470749','Administrator',NULL,NULL,NULL,NULL,NULL,NULL,'GBP','£',1,100,'Penny','#,###.##'),('GIP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GIP','£',NULL,100,'Penny','#,###.##'),('GMD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GMD',NULL,NULL,NULL,NULL,'#,###.##'),('GNF',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GNF','Fr',NULL,100,'Centime','#,###.##'),('GTQ',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GTQ','Q',NULL,100,'Centavo','#,###.##'),('GYD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'GYD','$',NULL,100,'Cent','#,###.##'),('HKD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HKD','$',NULL,100,'Cent','#,###.##'),('HNL',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HNL','L',NULL,100,'Centavo','#,###.##'),('HRK',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HRK','kn',NULL,100,'Lipa','#.###,##'),('HTG',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HTG','G',NULL,100,'Centime','#,###.##'),('HUF',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'HUF','Ft',NULL,100,'Fillér','#.###'),('IDR',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'IDR','Rp',NULL,100,'Sen','#.###,##'),('ILS',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ILS','₪',NULL,100,'Agora','#,###.##'),('INR',NULL,'2015-04-04 15:11:31.469940','Administrator',NULL,NULL,NULL,NULL,NULL,NULL,'INR','₹',1,100,'Paisa','#,##,###.##'),('IQD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'IQD','ع.د',NULL,1000,'Fils','#,###.###'),('IRR',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'IRR',NULL,NULL,NULL,NULL,'#,###.##'),('ISK',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ISK','kr',NULL,100,'Eyrir','#.###'),('JMD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'JMD','$',NULL,100,'Cent','#,###.##'),('JOD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'JOD','د.ا',NULL,100,'Piastre[H]','#,###.###'),('JPY',NULL,'2015-04-04 15:11:31.472144','Administrator',NULL,NULL,NULL,NULL,NULL,NULL,'JPY','¥',1,100,'Sen[G]','#,###'),('KES',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'KES','Sh',NULL,100,'Cent','#,###.##'),('KGS',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'KGS','лв',NULL,100,'Tyiyn','#,###.##'),('KHR',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'KHR','៛',NULL,100,'Sen','#,###.##'),('KMF',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'KMF','Fr',NULL,100,'Centime','#,###.##'),('KPW',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'KPW',NULL,NULL,NULL,NULL,'#,###.##'),('KRW',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'KRW',NULL,NULL,NULL,NULL,'#,###'),('KWD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'KWD','د.ك',NULL,1000,'Fils','#,###.###'),('KYD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'KYD','$',NULL,100,'Cent','#,###.##'),('KZT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'KZT','₸',NULL,100,'Tïın','#,###.##'),('LAK',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'LAK',NULL,NULL,NULL,NULL,'#,###.##'),('LBP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'LBP','ل.ل',NULL,100,'Piastre','#,###.##'),('LKR',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'LKR','Rs',NULL,100,'Cent','#,###.##'),('LRD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'LRD','$',NULL,100,'Cent','#,###.##'),('LSL',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'LSL','L',NULL,100,'Sente','#,###.##'),('LTL',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'LTL','Lt',NULL,100,'Centas','# ###,##'),('LVL',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'LVL','Ls',NULL,100,'Santīms','#,###.##'),('LYD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'LYD','ل.د',NULL,1000,'Dirham','#,###.###'),('MAD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'MAD','د.م.',NULL,100,'Centime','#,###.##'),('MDL',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'MDL',NULL,NULL,NULL,NULL,'#,###.##'),('MKD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'MKD','ден',NULL,100,'Deni','#,###.##'),('MMK',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'MMK',NULL,NULL,NULL,NULL,'#,###.##'),('MNT',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'MNT','₮',NULL,100,'Möngö','#,###.##'),('MOP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'MOP',NULL,NULL,NULL,NULL,'#,###.##'),('MRO',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'MRO','UM',NULL,5,'Khoums','#,###.##'),('MTL',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'MTL','€',NULL,100,'Cent','#,###.##'),('MUR',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'MUR','₨',NULL,100,'Cent','#,###'),('MVR',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'MVR','.ރ',NULL,100,'Laari','#,###.##'),('MWK',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'MWK','MK',NULL,100,'Tambala','#,###.##'),('MXN',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'MXN','$',NULL,100,'Centavo','#,###.##'),('MYR',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'MYR','RM',NULL,100,'Sen','#,###.##'),('NAD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NAD','$',NULL,100,'Cent','#,###.##'),('NGN',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NGN','₦',NULL,100,'Kobo','#,###.##'),('NIO',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NIO','C$',NULL,100,'Centavo','#,###.##'),('NOK',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NOK','kr',NULL,100,'Øre','#.###,##'),('NPR',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NPR','₨',NULL,100,'Paisa','#,###.##'),('NZD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'NZD','$',NULL,100,'Cent','#,###.##'),('OMR',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'OMR','ر.ع.',NULL,1000,'Baisa','#,###.###'),('PEN',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'PEN','S/.',NULL,100,'Céntimo','#,###.##'),('PGK',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'PGK','K',NULL,100,'Toea','#,###.##'),('PHP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'PHP','₱',NULL,100,'Centavo','#,###.##'),('PKR',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'PKR','₨',NULL,100,'Paisa','#,###.##'),('PLN',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'PLN','zł',NULL,100,'Grosz','#.###,##'),('PYG',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'PYG','₲',NULL,100,'Céntimo','#,###.##'),('QAR',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'QAR','ر.ق',NULL,100,'Dirham','#,###.##'),('RON',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'RON','lei',NULL,100,'Bani','#,###.##'),('RUB',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'RUB',NULL,NULL,NULL,NULL,'#.###,##'),('RWF',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'RWF','Fr',NULL,100,'Centime','#,###.##'),('SAR',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'SAR','ر.س',NULL,100,'Halala','#,###.##'),('SBD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'SBD','$',NULL,100,'Cent','#,###.##'),('SCR',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'SCR','₨',NULL,100,'Cent','#,###.##'),('SEK',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'SEK','kr',NULL,100,'Öre','#.###,##'),('SGD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'SGD','$',NULL,100,'Sen','#,###.##'),('SHP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'SHP',NULL,NULL,NULL,NULL,'#,###.##'),('SLL',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'SLL','Le',NULL,100,'Cent','#,###.##'),('SOS',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'SOS','Sh',NULL,100,'Cent','#,###.##'),('STD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'STD',NULL,NULL,NULL,NULL,'#,###.##'),('SVC',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'SVC','₡',NULL,100,'Centavo','#,###.##'),('SYP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'SYP',NULL,NULL,NULL,NULL,'#,###.##'),('SZL',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'SZL','L',NULL,100,'Cent','#, ###.##'),('THB',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'THB','฿',NULL,100,'Satang','#,###.##'),('TMM',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TMM','m',NULL,100,'Tennesi','#,###.##'),('TND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TND','د.ت',NULL,1000,'Millime','#,###.###'),('TOP',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TOP','T$',NULL,100,'Seniti[L]','#,###.##'),('TRY',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TRY','₺',NULL,100,'Kuruş','#,###.##'),('TTD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TTD','$',NULL,100,'Cent','#,###.##'),('TWD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TWD',NULL,NULL,NULL,NULL,'#,###.##'),('TZS',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'TZS',NULL,NULL,NULL,NULL,'#,###.##'),('UGX',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'UGX','Sh',NULL,100,'Cent','#,###.##'),('USD',NULL,'2015-04-04 15:11:31.470382','Administrator',NULL,NULL,NULL,NULL,NULL,NULL,'USD','$',1,100,'Cent','#,###.##'),('UYU',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'UYU','$',NULL,100,'Centésimo','#.###,##'),('UZS',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'UZS','лв',NULL,100,'Tiyin','#,###.##'),('VND',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'VND',NULL,NULL,NULL,NULL,'#.###'),('VUV',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'VUV','Vt',NULL,0,'None','#,###'),('WST',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'WST','T',NULL,100,'Sene','#,###.##'),('ZAR',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ZAR','R',NULL,100,'Cent','# ###.##'),('ZMK',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ZMK','ZK',NULL,100,'Ngwee','#,###.##'),('ZWD',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ZWD','P',NULL,100,'Thebe','# ###.##');
/*!40000 ALTER TABLE `tabCurrency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabCustom Field`
--

DROP TABLE IF EXISTS `tabCustom Field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabCustom Field` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `print_width` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_copy` int(1) DEFAULT NULL,
  `depends_on` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `in_list_view` int(1) DEFAULT NULL,
  `reqd` int(1) DEFAULT NULL,
  `in_filter` int(1) DEFAULT NULL,
  `read_only` int(1) DEFAULT NULL,
  `print_hide` int(1) DEFAULT NULL,
  `ignore_user_permissions` int(1) DEFAULT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `width` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hidden` int(1) DEFAULT NULL,
  `permlevel` int(11) DEFAULT '0',
  `insert_after` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `search_index` int(1) DEFAULT NULL,
  `allow_on_submit` int(1) DEFAULT NULL,
  `precision` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unique` int(1) DEFAULT NULL,
  `default` text COLLATE utf8mb4_unicode_ci,
  `fieldname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fieldtype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Data',
  `options` text COLLATE utf8mb4_unicode_ci,
  `report_hide` int(1) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `dt` (`dt`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabCustom Field`
--

LOCK TABLES `tabCustom Field` WRITE;
/*!40000 ALTER TABLE `tabCustom Field` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabCustom Field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabCustom Script`
--

DROP TABLE IF EXISTS `tabCustom Script`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabCustom Script` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `dt` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `script_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Client',
  `script` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabCustom Script`
--

LOCK TABLES `tabCustom Script` WRITE;
/*!40000 ALTER TABLE `tabCustom Script` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabCustom Script` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabCustomize Form Field`
--

DROP TABLE IF EXISTS `tabCustomize Form Field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabCustomize Form Field` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `print_width` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `in_list_view` int(1) DEFAULT NULL,
  `reqd` int(1) DEFAULT NULL,
  `in_filter` int(1) DEFAULT NULL,
  `print_hide` int(1) DEFAULT NULL,
  `ignore_user_permissions` int(1) DEFAULT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `width` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `depends_on` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hidden` int(1) DEFAULT NULL,
  `permlevel` int(11) DEFAULT '0',
  `description` text COLLATE utf8mb4_unicode_ci,
  `allow_on_submit` int(1) DEFAULT NULL,
  `precision` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unique` int(1) DEFAULT NULL,
  `default` text COLLATE utf8mb4_unicode_ci,
  `options` text COLLATE utf8mb4_unicode_ci,
  `fieldname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fieldtype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Data',
  `report_hide` int(1) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `label` (`label`),
  KEY `fieldname` (`fieldname`),
  KEY `fieldtype` (`fieldtype`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabCustomize Form Field`
--

LOCK TABLES `tabCustomize Form Field` WRITE;
/*!40000 ALTER TABLE `tabCustomize Form Field` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabCustomize Form Field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDefaultValue`
--

DROP TABLE IF EXISTS `tabDefaultValue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDefaultValue` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `defvalue` text COLLATE utf8mb4_unicode_ci,
  `defkey` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`),
  KEY `defaultvalue_parent_defkey_index` (`parent`,`defkey`),
  KEY `defaultvalue_parent_parenttype_index` (`parent`,`parenttype`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDefaultValue`
--

LOCK TABLES `tabDefaultValue` WRITE;
/*!40000 ALTER TABLE `tabDefaultValue` DISABLE KEYS */;
INSERT INTO `tabDefaultValue` VALUES ('0afacaa5ac','2015-04-04 15:11:30.193538','2015-04-04 15:11:30.193538','Administrator','Administrator',0,'__default','system_defaults','__default',NULL,'','float_precision'),('10560e2fa2','2015-04-04 15:11:29.960105','2015-04-04 15:11:29.960105','Administrator','Administrator',0,'__default','system_defaults','__default',NULL,NULL,'time_zone'),('483c04e920','2015-04-04 15:11:30.289152','2015-04-04 15:11:30.289152','Administrator','Administrator',0,'__default','system_defaults','__default',NULL,'0','enable_scheduler'),('4d73672b8c','2015-04-04 15:11:30.046347','2015-04-04 15:11:30.046347','Administrator','Administrator',0,'__default','system_defaults','__default',NULL,'yyyy-mm-dd','date_format'),('5417ea5ec8','2015-04-04 15:11:30.241456','2015-04-04 15:11:30.241456','Administrator','Administrator',0,'__default','system_defaults','__default',NULL,'06:00','session_expiry'),('9ea36ec5b6','2015-04-04 15:11:29.875173','2015-04-04 15:11:29.875173','Administrator','Administrator',0,'__default','system_defaults','__default',NULL,NULL,'language'),('c37c692bdc','2015-04-04 15:11:30.837718','2015-04-04 15:11:30.837718','Administrator','Administrator',0,'__global','system_defaults','__default',NULL,'[\"frappe\"]','installed_apps'),('d9147f8254','2015-04-04 15:11:30.132465','2015-04-04 15:11:30.132465','Administrator','Administrator',0,'__default','system_defaults','__default',NULL,'#,###.##','number_format');
/*!40000 ALTER TABLE `tabDefaultValue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDocField`
--

DROP TABLE IF EXISTS `tabDocField`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDocField` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `fieldname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oldfieldname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fieldtype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Data',
  `oldfieldtype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `options` text COLLATE utf8mb4_unicode_ci,
  `search_index` int(1) DEFAULT NULL,
  `hidden` int(1) DEFAULT NULL,
  `set_only_once` int(1) DEFAULT NULL,
  `print_hide` int(1) DEFAULT NULL,
  `report_hide` int(1) DEFAULT NULL,
  `reqd` int(1) DEFAULT NULL,
  `unique` int(1) DEFAULT NULL,
  `no_copy` int(1) DEFAULT NULL,
  `allow_on_submit` int(1) DEFAULT NULL,
  `trigger` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `depends_on` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permlevel` int(11) DEFAULT '0',
  `ignore_user_permissions` int(1) DEFAULT NULL,
  `width` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `print_width` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default` text COLLATE utf8mb4_unicode_ci,
  `description` text COLLATE utf8mb4_unicode_ci,
  `in_filter` int(1) DEFAULT NULL,
  `in_list_view` int(1) DEFAULT NULL,
  `no_column` int(1) DEFAULT NULL,
  `read_only` int(1) DEFAULT NULL,
  `precision` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`),
  KEY `label` (`label`),
  KEY `fieldtype` (`fieldtype`),
  KEY `fieldname` (`fieldname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDocField`
--

LOCK TABLES `tabDocField` WRITE;
/*!40000 ALTER TABLE `tabDocField` DISABLE KEYS */;
INSERT INTO `tabDocField` VALUES ('000eeea436','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',34,'subdomain','Subdomain',NULL,'Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Sub-domain provided by erpnext.com',NULL,NULL,NULL,1,NULL),('00f2c0f476','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',10,'fields_section_break','Fields',NULL,'Section Break','Section Break',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('00fd4bf2ad','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',13,'submit','Submit','submit','Check','Check',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,'32px','32px',NULL,NULL,NULL,1,NULL,NULL,NULL),('011a2820e1','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',30,'footer','Footer',NULL,'Text Editor',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('01346d4646','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',17,'allow_on_submit','Allow on Submit','allow_on_submit','Check','Check',NULL,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('0136b6d413','2013-01-16 13:09:40.000000','2015-04-04 15:11:14.607024','Administrator','Administrator',0,'Scheduler Log','fields','DocType',1,'method','Method',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('017b318afd','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',28,'allow_import','Allow Import',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Allow Import via Data Import Tool',NULL,NULL,NULL,NULL,NULL),('02da261198','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',9,'precision','Precision',NULL,'Select',NULL,'\n1\n2\n3\n4\n5\n6\n7\n8\n9',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,'eval:in_list([\"Float\", \"Currency\", \"Percent\"], doc.fieldtype)',0,NULL,NULL,NULL,NULL,'Set non-standard precision for a Float or Currency field',NULL,NULL,NULL,NULL,NULL),('03412bd8b0','2012-12-28 10:49:55.000000','2015-04-04 15:11:21.053948','Administrator','Administrator',0,'Workflow','fields','DocType',6,'transition_rules','Transition Rules',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Rules for how states are transitions, like next state and which role is allowed to change state etc.',NULL,NULL,NULL,NULL,NULL),('036e1bf86c','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',28,'location','Location',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('03868bafae','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',8,'unsubscribed','Unsubscribed',NULL,'Check',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('0441ccad67','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',21,'in_filter','In Filter','in_filter','Check','Check',NULL,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,'50px','50px',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('0473dee203','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',21,'copyright','Copyright',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('0484eed399','2012-07-03 13:29:42.000000','2015-04-04 15:11:25.760244','Administrator','Administrator',0,'Feed','fields','DocType',5,'color','Color',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('0489e3d99a','2014-04-17 16:53:52.640856','2015-04-04 15:11:13.078614','Administrator','Administrator',0,'System Settings','fields','DocType',6,'number_format','Number Format',NULL,'Select',NULL,'#,###.##\n#.###,##\n# ###.##\n# ###,##\n#\'###.##\n#, ###.##\n#,##,###.##\n#,###.###\n#.###\n#,###',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('04a43568ad','2014-07-11 17:18:09.923399','2015-04-04 15:11:22.628033','Administrator','Administrator',0,'Email Alert','fields','DocType',9,'condition','Condition',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',0,NULL,NULL,NULL,NULL,'Optional: The alert will be sent if this expression is true',NULL,1,NULL,NULL,NULL),('04e448e993','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',25,'print_width','Print Width',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'50px','50px',NULL,'Print Width of the field, if the field is a column in a table',NULL,NULL,NULL,NULL,NULL),('059c2df5f0','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',17,'width','Width','width','Data','Data',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('0603f199c9','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',7,'last_name','Last Name','last_name','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL),('06eed0f301','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',21,'smtp_port','Port',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'enable_outgoing',0,NULL,NULL,NULL,NULL,'If non standard port (e.g. 587)',NULL,NULL,NULL,NULL,''),('070feb84ab','2012-07-03 13:30:35.000000','2015-04-04 15:11:26.811873','Administrator','Administrator',0,'ToDo','fields','DocType',1,'description_and_status','Description and Status',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('0738b8cbe9','2014-09-01 14:08:48.624556','2015-04-04 15:11:18.596754','Administrator','Administrator',0,'Web Form','fields','DocType',9,'allow_delete','Allow Delete',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'allow_multiple',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('073bb59209','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',12,'permlevel','Permission Level','permlevel','Int','Int',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL),('077a9894fe','2013-01-29 17:55:08.000000','2015-04-04 15:11:24.475702','Administrator','Administrator',0,'Customize Form','fields','DocType',13,'fields','Fields',NULL,'Table',NULL,'Customize Form Field',0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('078c011682','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',28,'ref_name','Ref Name','ref_name','Dynamic Link','Data','ref_type',0,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL),('07c8922a91','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',21,'sunday','Sunday',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:doc.repeat_this_event && doc.repeat_on===\"Every Day\"',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('07c8d3eb72','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',18,'user_image_show','user_image_show',NULL,'Image',NULL,'user_image',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('087226165a','2012-12-12 11:19:22.000000','2015-04-04 15:11:13.498761','Administrator','Administrator',0,'File Data','fields','DocType',2,'file_url','File URL',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,NULL),('08a01bb35b','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',4,'column_break_2',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('08aca8af0d','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',20,'use_tls','Use TLS',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'enable_outgoing',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('08ea13e012','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',33,'cb31','Hide Actions',NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('0a1b35c85c','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',10,'banner','Banner',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Add a banner to the site. (small banners are usually good)',NULL,NULL,NULL,NULL,NULL),('0ac538eb2c','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',9,'section_break_8',NULL,NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('0bbed73ca4','2012-12-20 17:16:49.000000','2015-04-04 15:11:08.696742','Administrator','Administrator',0,'Page','fields','DocType',2,'page_name','Page Name','page_name','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('0c136c5fe7','2012-11-22 17:45:46.000000','2015-04-04 15:11:28.541028','Administrator','Administrator',0,'Letter Head','fields','DocType',1,'letter_head_name','Letter Head Name','letter_head_name','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,1,NULL,NULL,NULL),('0cac4d3ec9','2013-02-22 01:27:36.000000','2015-04-04 15:11:20.741323','Administrator','Administrator',0,'Workflow Document State','fields','DocType',2,'doc_status','Doc Status',NULL,'Select',NULL,'0\n1\n2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'80px','80px',NULL,'0 - Draft; 1 - Submitted; 2 - Cancelled',NULL,1,NULL,NULL,NULL),('0cdad71d60','2013-03-28 10:35:30.000000','2015-04-04 15:11:16.027377','Administrator','Administrator',0,'Blog Post','fields','DocType',8,'section_break_5',NULL,NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('0cdfc6ed10','2014-07-11 17:18:09.923399','2015-04-04 15:11:22.628033','Administrator','Administrator',0,'Email Alert','fields','DocType',13,'recipients','Recipients',NULL,'Table',NULL,'Email Alert Recipient',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('0d724c750f','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',6,'middle_name','Middle Name (Optional)','middle_name','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('0d8fcbbefc','2014-09-01 14:08:48.624556','2015-04-04 15:11:18.596754','Administrator','Administrator',0,'Web Form','fields','DocType',11,'fields','Fields',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('0da4c6e5ab','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',10,'heading_webfont','Google Font (Heading)',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Add the name of a <a href=\"https://www.google.com/fonts/\" target=\"_blank\">Google Web Font</a> e.g. \"Open Sans\"',NULL,NULL,NULL,NULL,''),('0e431b1927','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',14,'name_case','Name Case','name_case','Select','Select','\nTitle Case\nUPPER CASE',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('0ead491917','2014-03-04 08:29:52.000000','2015-04-04 15:11:15.926427','Administrator','Administrator',0,'Social Login Keys','fields','DocType',1,'facebook','Facebook',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('0f8a3501b7','2015-03-18 09:41:20.216319','2015-04-04 15:11:23.842816','Administrator','Administrator',0,'Email Unsubscribe','fields','DocType',2,'reference_doctype','Reference DocType',NULL,'Link',NULL,'DocType',0,0,0,0,0,1,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,1,NULL,0,''),('0fa09dfab7','2013-01-23 19:54:43.000000','2015-04-04 15:11:28.894125','Administrator','Administrator',0,'Print Format','fields','DocType',3,'column_break_3',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('0fdc8b1fa7','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',12,'text_color','Text Color',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('102ff1fb7f','2014-07-17 06:54:20.782907','2015-04-04 15:11:29.372802','Administrator','Administrator',0,'Print Settings','fields','DocType',8,'with_letterhead','With Letterhead',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'1','Print with Letterhead, unless unchecked in a particular Document',NULL,NULL,NULL,NULL,NULL),('1042111fa4','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',2,'subject','Subject',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('1063b4ffb2','2013-02-22 01:28:08.000000','2015-04-04 15:11:18.240871','Administrator','Administrator',0,'Top Bar Item','fields','DocType',3,'url','URL',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,'200px','200px',NULL,'Link to the page you want to open',NULL,1,NULL,NULL,NULL),('10e074b49d','2014-09-01 14:14:14.292173','2015-04-04 15:11:16.724128','Administrator','Administrator',0,'Web Form Field','fields','DocType',3,'label','Label',NULL,'Data',NULL,NULL,0,0,0,0,0,1,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,1,NULL,0,NULL),('113c2aa3c7','2013-01-10 16:34:01.000000','2015-04-04 15:11:24.153999','Administrator','Administrator',0,'Custom Script','fields','DocType',1,'dt','DocType','dt','Link','Link','DocType',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('1143e1d6dd','2014-07-17 06:54:20.782907','2015-04-04 15:11:29.372802','Administrator','Administrator',0,'Print Settings','fields','DocType',9,'section_break_8',NULL,NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('123878a58c','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',24,'no_copy','No Copy','no_copy','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'50px','50px',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('126cb74d77','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',8,'column_break_7',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('131dac85e5','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',28,'print_width','Print Width',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('1370bc1bef','2013-02-21 20:12:42.000000','2015-04-04 15:11:15.105507','Administrator','Administrator',0,'Contact Us Settings','fields','DocType',5,'query_options','Query Options',NULL,'Small Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Contact options, like \"Sales Query, Support Query\" etc each on a new line or separated by commas.',NULL,NULL,NULL,NULL,NULL),('13ef0a71b2','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',39,'sb3','Security Settings',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL),('14b58e6c8c','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',20,'column_break_20',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('14ecccf6f9','2014-04-17 16:53:52.640856','2015-04-04 15:11:13.078614','Administrator','Administrator',0,'System Settings','fields','DocType',8,'security','Security',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('14fbd0f895','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',22,'share','Share',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,''),('15cb2e4ab8','2013-03-19 12:02:15.000000','2015-04-04 15:11:17.521595','Administrator','Administrator',0,'About Us Settings','fields','DocType',7,'team_members_heading','Team Members Heading',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'\"Team Members\" or \"Management\"',NULL,NULL,NULL,0,NULL),('15d9e3676e','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',7,'website_theme','Website Theme',NULL,'Link',NULL,'Website Theme',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'Standard',NULL,NULL,NULL,NULL,NULL,''),('165a172edd','2014-07-17 06:54:20.782907','2015-04-04 15:11:29.372802','Administrator','Administrator',0,'Print Settings','fields','DocType',2,'send_print_as_pdf','Send Print as PDF',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'1','Send Email Print Attachments as PDF (Recommended)',NULL,NULL,NULL,NULL,NULL),('165ba49fa3','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',11,'fields','Fields','fields','Table','Table','DocField',0,0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('1686db803d','2013-01-29 17:55:08.000000','2015-04-04 15:11:24.475702','Administrator','Administrator',0,'Customize Form','fields','DocType',12,'fields_section_break','Fields',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'doc_type',0,NULL,NULL,NULL,NULL,'Customize Label, Print Hide, Default etc.',NULL,NULL,NULL,NULL,NULL),('17cca5cf7b','2013-02-06 11:30:13.000000','2015-04-04 15:11:12.114404','Administrator','Administrator',0,'UserRole','fields','DocType',1,'role','Role','role','Link','Link','Role',0,0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,'200px','200px',NULL,NULL,NULL,1,NULL,NULL,NULL),('185ada6c6f','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',51,'google_userid','Google User ID',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL),('1873ca4c34','2014-03-04 08:29:52.000000','2015-04-04 15:11:15.926427','Administrator','Administrator',0,'Social Login Keys','fields','DocType',4,'google','Google',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('18cb03286a','2013-03-28 10:35:30.000000','2015-04-04 15:11:16.027377','Administrator','Administrator',0,'Blog Post','fields','DocType',6,'blogger','Blogger',NULL,'Link',NULL,'Blogger',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('1926a842de','2013-01-23 19:54:43.000000','2015-04-04 15:11:28.894125','Administrator','Administrator',0,'Print Format','fields','DocType',7,'custom_format','Custom Format',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('193645edc8','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',29,'set_footer','',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('1965137b74','2013-02-21 20:12:42.000000','2015-04-04 15:11:15.105507','Administrator','Administrator',0,'Contact Us Settings','fields','DocType',1,'introduction_section','Introduction',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('196c5d7f39','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',16,'ignore_user_permissions','Ignore User Permissions',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('1a41f159bf','2014-07-17 06:54:20.782907','2015-04-04 15:11:29.372802','Administrator','Administrator',0,'Print Settings','fields','DocType',3,'pdf_page_size','PDF Page Size',NULL,'Select',NULL,'A4\nLetter',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'A4',NULL,NULL,NULL,NULL,NULL,NULL),('1ae2902b1f','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',19,'friday','Friday',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:doc.repeat_this_event && doc.repeat_on===\"Every Day\"',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('1b0c83d4ac','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',25,'in_filter','In Report Filter','in_filter','Check','Check',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('1bc6df38f4','2013-03-09 15:45:57.000000','2015-04-04 15:11:13.159277','Administrator','Administrator',0,'Report','fields','DocType',4,'module','Module',NULL,'Link',NULL,'Module Def',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('1bf63de1f6','2013-02-22 01:28:08.000000','2015-04-04 15:11:16.411393','Administrator','Administrator',0,'Company History','fields','DocType',1,'year','Year',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('1c48d3e35a','2013-03-28 10:35:30.000000','2015-04-04 15:11:16.027377','Administrator','Administrator',0,'Blog Post','fields','DocType',2,'published_on','Published On',NULL,'Date',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('1c628ef996','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',13,'section_break_13',NULL,NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'enable_incoming',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('1d04b957c8','2013-03-07 15:53:15.000000','2015-04-04 15:11:15.250035','Administrator','Administrator',0,'Website Slideshow','fields','DocType',1,'slideshow_name','Slideshow Name',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),('1d307382f4','2013-03-19 12:02:15.000000','2015-04-04 15:11:17.521595','Administrator','Administrator',0,'About Us Settings','fields','DocType',4,'company_history_heading','Org History Heading',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'\"Company History\"',NULL,1,NULL,0,NULL),('1dde959790','2012-11-22 17:45:46.000000','2015-04-04 15:11:28.541028','Administrator','Administrator',0,'Letter Head','fields','DocType',3,'is_default','Is Default','is_default','Check','Check',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'letter_head_name',0,NULL,NULL,NULL,NULL,'Check this to make this the default letter head in all prints',NULL,1,NULL,NULL,NULL),('1dff484c4b','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',10,'options','Options','options','Text','Text',NULL,0,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'For Links, enter the DocType as range\nFor Select, enter list of Options separated by comma',NULL,1,NULL,NULL,NULL),('1e886f2854','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',19,'import','Import',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('1f520aa5a1','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','fields','DocType',13,'sender_full_name','Sender Full Name',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('1f9d97d49d','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',7,'icon','Icon',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('1fd5ad4e19','2013-01-10 16:34:04.000000','2015-04-04 15:11:07.697838','Administrator','Administrator',0,'Property Setter','fields','DocType',7,'field_name','Field Name',NULL,'Data',NULL,NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'eval:doc.doctype_or_field==\'DocField\'',0,NULL,NULL,NULL,NULL,'ID (name) of the entity whose property is to be set',0,NULL,NULL,NULL,NULL),('205781df10','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',26,'read_only','User Cannot Search','read_only','Check','Check',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('206787b042','2014-07-11 17:18:09.923399','2015-04-04 15:11:22.628033','Administrator','Administrator',0,'Email Alert','fields','DocType',8,'value_changed','Value Changed',NULL,'Select',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:doc.event==\"Value Change\"',0,NULL,NULL,NULL,NULL,'Send alert if this field\'s value changes',NULL,NULL,NULL,NULL,NULL),('20c82f81f9','2013-02-21 20:12:42.000000','2015-04-04 15:11:15.105507','Administrator','Administrator',0,'Contact Us Settings','fields','DocType',7,'address_title','Address Title',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('20c95ae1bf','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',22,'section_break_6',NULL,NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('20f7b556f1','2012-12-28 10:49:55.000000','2015-04-04 15:11:21.053948','Administrator','Administrator',0,'Workflow','fields','DocType',3,'is_active','Is Active',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'If checked, all other workflows become inactive.',NULL,0,NULL,NULL,NULL),('21220ddff7','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',18,'default','Default Value','default','Text','Text',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('22d9fb477c','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',11,'custom_javascript','Custom Javascript',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('22eed9df17','2014-07-11 17:18:09.923399','2015-04-04 15:11:22.628033','Administrator','Administrator',0,'Email Alert','fields','DocType',3,'subject','Subject',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('22f56d8141','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',19,'column_break_11',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('23a6e9ac04','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',25,'column_break_22',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('23b68bf046','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',4,'insert_after','Insert After','insert_after','Select','Select',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Select the label after which you want to insert new field.',NULL,NULL,NULL,NULL,NULL),('24726db5eb','2012-07-03 13:30:35.000000','2015-04-04 15:11:26.811873','Administrator','Administrator',0,'ToDo','fields','DocType',8,'section_break_6','Reference',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('258c0349ea','2014-09-01 14:08:48.624556','2015-04-04 15:11:18.596754','Administrator','Administrator',0,'Web Form','fields','DocType',7,'allow_edit','Allow Edit',NULL,'Check',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,'login_required',0,0,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL),('25b9c7057e','2014-09-01 14:08:48.624556','2015-04-04 15:11:18.596754','Administrator','Administrator',0,'Web Form','fields','DocType',4,'column_break_4',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL),('2602b4b421','2013-03-19 12:02:15.000000','2015-04-04 15:11:17.521595','Administrator','Administrator',0,'About Us Settings','fields','DocType',3,'sb0','Org History',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),('26d72e41ef','2014-09-01 14:14:14.292173','2015-04-04 15:11:16.724128','Administrator','Administrator',0,'Web Form Field','fields','DocType',1,'fieldname','Fieldname',NULL,'Select',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,1,NULL,0,NULL),('2704facaba','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',1,'dt','Document','dt','Link','Link','DocType',1,NULL,NULL,NULL,NULL,1,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,1,NULL,NULL,NULL),('273906949f','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',18,'sidebar','Sidebar',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Sidebar Links for Home Page only',NULL,NULL,NULL,NULL,NULL),('27f6b9cc5b','2012-07-03 13:29:42.000000','2015-04-04 15:11:25.760244','Administrator','Administrator',0,'Feed','fields','DocType',3,'doc_name','Doc Name',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('2827062cbd','2014-09-01 14:08:48.624556','2015-04-04 15:11:18.596754','Administrator','Administrator',0,'Web Form','fields','DocType',6,'login_required','Login Required',NULL,'Check',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL),('28dd060138','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',14,'unique','Unique',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('291e44ef69','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',21,'display','Display',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('29b097cad5','2013-01-10 16:34:04.000000','2015-04-04 15:11:07.697838','Administrator','Administrator',0,'Property Setter','fields','DocType',9,'property_type','Property Type',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('2a4c7ab7e9','2012-12-20 17:16:49.000000','2015-04-04 15:11:08.696742','Administrator','Administrator',0,'Page','fields','DocType',7,'standard','Standard','standard','Select','Select','\nYes\nNo',1,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('2ace2f87aa','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',18,'enable_comments','Enable Comments',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('2b73155c35','2013-02-22 01:28:08.000000','2015-04-04 15:11:18.240871','Administrator','Administrator',0,'Top Bar Item','fields','DocType',4,'target','Target',NULL,'Select',NULL,'\ntarget = \"_blank\"',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Select target = \"_blank\" to open in a new page.',NULL,0,NULL,NULL,NULL),('2bbfc17e85','2015-02-04 04:33:36.330477','2015-04-04 15:11:11.308875','Administrator','Administrator',0,'DocShare','fields','DocType',3,'share_name','Document Name',NULL,'Dynamic Link',NULL,'share_doctype',1,0,0,0,0,1,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,1,NULL,0,''),('2c2adea5b2','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',17,'title_field','Title Field',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Show this field as title',NULL,NULL,NULL,NULL,NULL),('2cba825a3f','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',28,'search_index','Index',NULL,'Check',NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('2d140b85fb','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',24,'column_break_6',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('2d26268a53','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',14,'notify_if_unreplied','Notify if unreplied',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('2d34c2bb91','2013-03-07 11:55:11.000000','2015-04-04 15:11:17.629439','Administrator','Administrator',0,'About Us Team Member','fields','DocType',2,'image_link','Image Link',NULL,'Attach',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'150px',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('2d47dd187a','2013-02-22 01:28:08.000000','2015-04-04 15:11:18.240871','Administrator','Administrator',0,'Top Bar Item','fields','DocType',5,'right','Right',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'For top bar',NULL,NULL,NULL,NULL,NULL),('2d6765a110','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',36,'block_modules','Block Modules',NULL,'Table',NULL,'Block Module',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('2e9ea731b4','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',5,'cb01',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('2f0b9a8f18','2012-07-03 13:30:35.000000','2015-04-04 15:11:26.811873','Administrator','Administrator',0,'ToDo','fields','DocType',5,'priority','Priority','priority','Select','Data','High\nMedium\nLow',0,0,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,'Medium',NULL,0,0,NULL,NULL,NULL),('2f161bf088','2013-03-19 12:02:15.000000','2015-04-04 15:11:17.521595','Administrator','Administrator',0,'About Us Settings','fields','DocType',9,'footer','Footer',NULL,'Text Editor',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'More content for the bottom of the page.',NULL,NULL,NULL,0,NULL),('2f3c6e71cb','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',1,'label_and_type','',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('2f5c9b46e2','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',20,'footer_color','Footer Color',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('308ab5dcd4','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',12,'column_break_8',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('30a4f025f8','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',11,'banner_image','Banner Image',NULL,'Attach Image',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Select an image of approx width 150px with a transparent background for best results.',NULL,NULL,NULL,NULL,NULL),('31f21990ef','2013-02-22 01:27:36.000000','2015-04-04 15:11:21.384297','Administrator','Administrator',0,'Workflow Transition','fields','DocType',2,'action','Action',NULL,'Link',NULL,'Workflow Action',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,'200px','200px',NULL,NULL,NULL,1,NULL,NULL,NULL),('322114a51c','2014-04-17 16:53:52.640856','2015-04-04 15:11:13.078614','Administrator','Administrator',0,'System Settings','fields','DocType',1,'localization','Localization',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('325cb8821c','2014-07-17 06:54:20.782907','2015-04-04 15:11:29.372802','Administrator','Administrator',0,'Print Settings','fields','DocType',1,'pdf_settings','PDF Settings',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('32cb961788','2014-07-17 06:54:20.782907','2015-04-04 15:11:29.372802','Administrator','Administrator',0,'Print Settings','fields','DocType',10,'print_style_preview','Print Style Preview',NULL,'HTML',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('3310c97bc1','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',13,'permlevel','Perm Level','permlevel','Int','Int',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,'50px','50px','0',NULL,NULL,NULL,NULL,NULL,NULL),('331bc45c91','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',18,'report_hide','Report Hide','report_hide','Check','Check',NULL,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('355812115b','2013-03-08 09:41:11.000000','2015-04-04 15:11:15.582389','Administrator','Administrator',0,'Blog Category','fields','DocType',2,'title','Title',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('35599a6561','2014-04-17 16:53:52.640856','2015-04-04 15:11:13.078614','Administrator','Administrator',0,'System Settings','fields','DocType',2,'language','Language',NULL,'Select',NULL,'Loading...',0,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('3572bd0eb1','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',25,'in_create','User Cannot Create','in_create','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('3585599b29','2012-07-03 13:30:35.000000','2015-04-04 15:11:26.811873','Administrator','Administrator',0,'ToDo','fields','DocType',4,'status','Status',NULL,'Select',NULL,'Open\nClosed',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'Open',NULL,NULL,1,NULL,NULL,NULL),('358a6eb9a9','2013-01-23 19:54:43.000000','2015-04-04 15:11:28.894125','Administrator','Administrator',0,'Print Format','fields','DocType',5,'disabled','Disabled',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('35aefefb4d','2012-12-28 10:49:56.000000','2015-04-04 15:11:21.707031','Administrator','Administrator',0,'Workflow State','fields','DocType',3,'style','Style',NULL,'Select',NULL,'\nPrimary\nInfo\nSuccess\nWarning\nDanger\nInverse',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Style represents the button color: Success - Green, Danger - Red, Inverse - Black, Primary - Dark Blue, Info - Light Blue, Warning - Orange',NULL,NULL,NULL,NULL,NULL),('36388feb6e','2012-12-28 10:49:55.000000','2015-04-04 15:11:21.053948','Administrator','Administrator',0,'Workflow','fields','DocType',5,'states','Document States',NULL,'Table',NULL,'Workflow Document State',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'All possible Workflow States and roles of the workflow. <br>Docstatus Options: 0 is\"Saved\", 1 is \"Submitted\" and 2 is \"Cancelled\"',NULL,NULL,NULL,NULL,NULL),('3695ffe257','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',45,'last_login','Last Login','last_login','Read Only','Read Only',NULL,0,0,NULL,NULL,NULL,0,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL),('3702abc000','2014-07-11 17:19:37.037109','2015-04-04 15:11:23.046681','Administrator','Administrator',0,'Email Alert Recipient','fields','DocType',1,'email_by_document_field','Email By Document Field',NULL,'Select',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Optional: Alert will only be sent if value is a valid email id.',NULL,1,NULL,NULL,NULL),('377bfee70e','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','fields','DocType',3,'status','Status',NULL,'Select',NULL,'Open\nReplied\nArchived',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('37daa2a6dc','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',12,'insert_code','Insert Code',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Add code as &lt;script&gt;',NULL,NULL,NULL,NULL,NULL),('37e6b03907','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',7,'in_list_view','In List View',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'70px','70px',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('39694c2e87','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',26,'section_break_21',NULL,NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('398ea77a44','2013-02-22 01:27:33.000000','2015-04-04 15:11:28.073434','Administrator','Administrator',0,'Event Role','fields','DocType',1,'role','Role','role','Link','Link','Role',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'240px','240px',NULL,NULL,NULL,1,NULL,NULL,NULL),('39e4ceac33','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',17,'wednesday','Wednesday',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:doc.repeat_this_event && doc.repeat_on===\"Every Day\"',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('3a59ba5a02','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',6,'page_name','Page Name',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Page url name (auto-generated)',NULL,0,NULL,0,NULL),('3acc2638d6','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',18,'ignore_user_permissions','Ignore User Permissions',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'User permissions should not apply for this Link',NULL,NULL,NULL,NULL,NULL),('3c14782369','2013-01-23 19:54:43.000000','2015-04-04 15:11:28.894125','Administrator','Administrator',0,'Print Format','fields','DocType',12,'print_format_builder','Print Format Builder',NULL,'Check',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('3c2c7a3a94','2013-01-29 17:55:08.000000','2015-04-04 15:11:24.475702','Administrator','Administrator',0,'Customize Form','fields','DocType',11,'sort_order','Sort Order',NULL,'Select',NULL,'ASC\nDESC',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('3c62406ea5','2013-03-09 15:45:57.000000','2015-04-04 15:11:13.159277','Administrator','Administrator',0,'Report','fields','DocType',13,'json','JSON',NULL,'Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:doc.report_type==\"Report Builder\"',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL),('3c6abdaeb5','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',11,'properties','Properties',NULL,'Column Break','Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'50%','50%',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('3ce10898cf','2015-03-18 09:41:20.216319','2015-04-04 15:11:23.842816','Administrator','Administrator',0,'Email Unsubscribe','fields','DocType',1,'email','Email',NULL,'Data',NULL,NULL,0,0,0,0,0,1,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,1,NULL,0,''),('3d1073b91f','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',16,'set_only_once','Set Only Once',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Do not allow user to change after set the first time',NULL,NULL,NULL,NULL,NULL),('3d6daf606a','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','fields','DocType',5,'column_break_5',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('3e4e097ecb','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',11,'permissions','Permissions',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('3e84df00d6','2012-12-28 10:49:55.000000','2015-04-04 15:11:21.053948','Administrator','Administrator',0,'Workflow','fields','DocType',1,'workflow_name','Workflow Name',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,0,NULL),('3ebbbcd42b','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',18,'export','Export',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL),('3f335cb5ea','2014-03-04 08:29:52.000000','2015-04-04 15:11:15.926427','Administrator','Administrator',0,'Social Login Keys','fields','DocType',2,'facebook_client_id','Facebook Client ID',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('3f4b7b1de6','2012-12-12 11:19:22.000000','2015-04-04 15:11:13.498761','Administrator','Administrator',0,'File Data','fields','DocType',5,'file_size','File Size',NULL,'Int',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,NULL),('3fde61be43','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','fields','DocType',15,'phone_no','Phone No.',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('418789dbcc','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',7,'enable_incoming','Enable Incoming',NULL,'Check',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,NULL,NULL,'','Check this to pull emails from your mailbox',0,0,NULL,0,''),('41d0e9a233','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',11,'column_break_18',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('4290e63454','2014-07-11 17:18:09.923399','2015-04-04 15:11:22.628033','Administrator','Administrator',0,'Email Alert','fields','DocType',7,'days_in_advance','Days Before or After',NULL,'Int',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:doc.event==\"Days After\" || doc.event==\"Days Before\"',0,NULL,NULL,NULL,'0','Send days before or after the reference date',NULL,NULL,NULL,NULL,NULL),('43066e76fb','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',25,'sb2','',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:!doc.__islocal',0,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL),('4378efb4d7','2012-07-03 13:29:42.000000','2015-04-04 15:11:25.760244','Administrator','Administrator',0,'Feed','fields','DocType',6,'full_name','Full Name',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('439bde3011','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',9,'precision','Precision',NULL,'Select',NULL,'\n1\n2\n3\n4\n5\n6\n7\n8\n9',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:in_list([\"Float\", \"Currency\", \"Percent\"], doc.fieldtype)',0,NULL,NULL,NULL,NULL,'Set non-standard precision for a Float or Currency field',NULL,NULL,NULL,NULL,''),('439fd29a92','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',6,'unique','Unique',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('4410ce646a','2013-02-22 01:28:08.000000','2015-04-04 15:11:18.240871','Administrator','Administrator',0,'Top Bar Item','fields','DocType',1,'label','Label',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,'120px','120px',NULL,NULL,NULL,1,NULL,NULL,NULL),('44656b549d','2012-12-20 17:16:49.000000','2015-04-04 15:11:08.696742','Administrator','Administrator',0,'Page','fields','DocType',4,'icon','icon',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('44c36278d6','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',10,'attachment_limit','Attachment Limit (MB)',NULL,'Int',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'enable_incoming',0,NULL,NULL,NULL,'1','Ignore attachments over this size',NULL,NULL,NULL,NULL,''),('44e80f8ada','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',13,'link_color','Link Color',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('455a7f7ed2','2014-02-20 17:22:37.000000','2015-04-04 15:11:12.769699','Administrator','Administrator',0,'Version','fields','DocType',3,'doclist_json','Doclist JSON',NULL,'Code',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('455f5c2dac','2013-02-22 01:27:32.000000','2015-04-04 15:11:09.369240','Administrator','Administrator',0,'DefaultValue','fields','DocType',2,'defvalue','Value','defvalue','Text','Text',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,'200px','200px',NULL,NULL,NULL,1,NULL,NULL,NULL),('45b18ff9f0','2013-02-21 20:12:42.000000','2015-04-04 15:11:15.105507','Administrator','Administrator',0,'Contact Us Settings','fields','DocType',4,'introduction','Introduction',NULL,'Text Editor',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Introductory information for the Contact Us Page',NULL,NULL,NULL,NULL,NULL),('45d69c0cc6','2014-07-11 17:18:09.923399','2015-04-04 15:11:22.628033','Administrator','Administrator',0,'Email Alert','fields','DocType',12,'column_break_5','Recipients',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('460e95299d','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',23,'print','Print',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL),('464adc980b','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',24,'print_hide','Print Hide','print_hide','Check','Check',NULL,0,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('46da0172aa','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',2,'label','Label','label','Data','Data',NULL,1,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,'163','163',NULL,NULL,NULL,1,NULL,NULL,NULL),('475b87eb80','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',26,'description','Description','description','Text','Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'300px','300px',NULL,NULL,NULL,1,NULL,NULL,NULL),('47e607bee0','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','fields','DocType',17,'column_break4','By',NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('48193f0df2','2013-02-22 01:28:08.000000','2015-04-04 15:11:16.411393','Administrator','Administrator',0,'Company History','fields','DocType',2,'highlight','Highlight',NULL,'Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'300px','300px',NULL,NULL,NULL,1,NULL,NULL,NULL),('4847086674','2015-02-04 04:33:36.330477','2015-04-04 15:11:11.308875','Administrator','Administrator',0,'DocShare','fields','DocType',6,'share','Share',NULL,'Check',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,NULL,NULL,'0',NULL,0,0,NULL,0,''),('48decacd71','2014-09-01 14:08:48.624556','2015-04-04 15:11:18.596754','Administrator','Administrator',0,'Web Form','fields','DocType',8,'allow_multiple','Allow Multiple',NULL,'Check',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,'login_required',0,0,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL),('49150527a9','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',15,'amend','Amend','amend','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'32px','32px',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('492806c69d','2013-03-09 15:45:57.000000','2015-04-04 15:11:13.159277','Administrator','Administrator',0,'Report','fields','DocType',2,'ref_doctype','Ref DocType',NULL,'Link',NULL,'DocType',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,NULL),('49923f8340','2013-02-21 20:12:42.000000','2015-04-04 15:11:15.105507','Administrator','Administrator',0,'Contact Us Settings','fields','DocType',8,'address_line1','Address Line 1',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('49a8aad80d','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',22,'background','',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('49bc6d229a','2014-09-01 14:14:14.292173','2015-04-04 15:11:16.724128','Administrator','Administrator',0,'Web Form Field','fields','DocType',10,'description','Description',NULL,'Text',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL),('49c14d0632','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',8,'sb1','Content',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Page content',NULL,NULL,NULL,NULL,NULL),('4b6f0f1693','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',6,'bootstrap','Link to Bootstrap CSS',NULL,'Small Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Link to your Bootstrap theme',NULL,NULL,NULL,NULL,''),('4c03a3a86b','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',15,'description','Description','description','Small Text','Text',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('4c09c10ac9','2013-02-22 01:27:36.000000','2015-04-04 15:11:20.741323','Administrator','Administrator',0,'Workflow Document State','fields','DocType',5,'allow_edit','Only Allow Edit For',NULL,'Link',NULL,'Role',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,'160px','160px',NULL,NULL,NULL,1,NULL,NULL,NULL),('4c278a8cbc','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',10,'language','Language',NULL,'Select',NULL,'Loading...',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL),('4c5c0be3f8','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',30,'oldfieldname',NULL,'oldfieldname','Data','Data',NULL,0,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('4ce4ac2019','2012-12-28 10:49:56.000000','2015-04-04 15:11:21.707031','Administrator','Administrator',0,'Workflow State','fields','DocType',2,'icon','Icon',NULL,'Select',NULL,'\nglass\nmusic\nsearch\nenvelope\nheart\nstar\nstar-empty\nuser\nfilm\nth-large\nth\nth-list\nok\nremove\nzoom-in\nzoom-out\noff\nsignal\ncog\ntrash\nhome\nfile\ntime\nroad\ndownload-alt\ndownload\nupload\ninbox\nplay-circle\nrepeat\nrefresh\nlist-alt\nlock\nflag\nheadphones\nvolume-off\nvolume-down\nvolume-up\nqrcode\nbarcode\ntag\ntags\nbook\nbookmark\nprint\ncamera\nfont\nbold\nitalic\ntext-height\ntext-width\nalign-left\nalign-center\nalign-right\nalign-justify\nlist\nindent-left\nindent-right\nfacetime-video\npicture\npencil\nmap-marker\nadjust\ntint\nedit\nshare\ncheck\nmove\nstep-backward\nfast-backward\nbackward\nplay\npause\nstop\nforward\nfast-forward\nstep-forward\neject\nchevron-left\nchevron-right\nplus-sign\nminus-sign\nremove-sign\nok-sign\nquestion-sign\ninfo-sign\nscreenshot\nremove-circle\nok-circle\nban-circle\narrow-left\narrow-right\narrow-up\narrow-down\nshare-alt\nresize-full\nresize-small\nplus\nminus\nasterisk\nexclamation-sign\ngift\nleaf\nfire\neye-open\neye-close\nwarning-sign\nplane\ncalendar\nrandom\ncomment\nmagnet\nchevron-up\nchevron-down\nretweet\nshopping-cart\nfolder-close\nfolder-open\nresize-vertical\nresize-horizontal\nhdd\nbullhorn\nbell\ncertificate\nthumbs-up\nthumbs-down\nhand-right\nhand-left\nhand-up\nhand-down\ncircle-arrow-right\ncircle-arrow-left\ncircle-arrow-up\ncircle-arrow-down\nglobe\nwrench\ntasks\nfilter\nbriefcase\nfullscreen',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Icon will appear on the button',NULL,NULL,NULL,NULL,NULL),('4d052e7942','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',29,'width','Width','width','Data','Data',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,'50px','50px',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('4d55827012','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',1,'email_settings','',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('4d5ab889b5','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',6,'starts_on','Starts on',NULL,'Datetime',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('4da9584956','2012-12-20 17:16:49.000000','2015-04-04 15:11:08.696742','Administrator','Administrator',0,'Page','fields','DocType',8,'section_break0',NULL,NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('4e0711f092','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',3,'fieldtype','Type','fieldtype','Select','Select','Attach\nAttach Image\nButton\nCheck\nCode\nColumn Break\nCurrency\nData\nDate\nDatetime\nDynamic Link\nFloat\nFold\nHeading\nHTML\nImage\nInt\nLink\nLong Text\nPassword\nPercent\nRead Only\nSection Break\nSelect\nSmall Text\nTable\nText\nText Editor\nTime',1,0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'Data',NULL,NULL,1,NULL,NULL,NULL),('4e1abe2a7e','2013-03-25 16:00:51.000000','2015-04-04 15:11:17.917763','Administrator','Administrator',0,'Blogger','fields','DocType',6,'avatar','Avatar',NULL,'Attach',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('4e76ce9151','2014-07-11 17:18:09.923399','2015-04-04 15:11:22.628033','Administrator','Administrator',0,'Email Alert','fields','DocType',6,'date_changed','Reference Date',NULL,'Select',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:doc.event==\"Days After\" || doc.event==\"Days Before\"',0,NULL,NULL,NULL,NULL,'Send alert if date matches this field\'s value',NULL,NULL,NULL,NULL,NULL),('4ec4b6109b','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',12,'depends_on','Depends On','depends_on','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('4ee4938f1c','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','fields','DocType',10,'additional_info','Additional Info',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('4f4b2edcff','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',22,'address','Address',NULL,'Text Editor',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Address and other legal information you may want to put in the footer.',NULL,NULL,NULL,NULL,NULL),('4f81d511c6','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',2,'role','Role','role','Link','Link','Role',0,0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,'150px','150px',NULL,NULL,NULL,1,NULL,NULL,NULL),('5048604b07','2014-07-11 17:18:09.923399','2015-04-04 15:11:22.628033','Administrator','Administrator',0,'Email Alert','fields','DocType',15,'message','Message',NULL,'Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('506e96f6c0','2013-01-29 17:55:08.000000','2015-04-04 15:11:24.475702','Administrator','Administrator',0,'Customize Form','fields','DocType',9,'sort_field','Sort Field',NULL,'Select',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('50719fa7c5','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',23,'idx','Priority',NULL,'Int',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'0 is highest',NULL,NULL,NULL,NULL,NULL),('5092ff4ba3','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',8,'pop3_server','POP3 Server',NULL,'Data',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,'enable_incoming',0,0,NULL,NULL,NULL,'e.g. pop.gmail.com',0,0,NULL,0,''),('50d4913de0','2014-09-01 14:14:14.292173','2015-04-04 15:11:16.724128','Administrator','Administrator',0,'Web Form Field','fields','DocType',9,'section_break_6',NULL,NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL),('50ee7938d2','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',4,'fieldname','Name','fieldname','Data','Data',NULL,1,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,NULL),('5139b8e0d3','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',20,'saturday','Saturday',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:doc.repeat_this_event && doc.repeat_on===\"Every Day\"',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('515f2b29f4','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',46,'last_ip','Last IP','last_ip','Read Only','Read Only',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL),('51d7672178','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',3,'email_id','Email Id',NULL,'Data',NULL,'email',0,0,0,0,0,1,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,NULL,0,''),('522c7b9ae1','2013-03-07 15:53:15.000000','2015-04-04 15:11:15.250035','Administrator','Administrator',0,'Website Slideshow','fields','DocType',2,'sb0','',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:!doc.__islocal',0,NULL,NULL,NULL,NULL,'Note: For best results, images must be of the same size and width must be greater than height.',NULL,NULL,NULL,NULL,NULL),('52d4bbd51b','2012-12-28 10:49:56.000000','2015-04-04 15:11:20.373529','Administrator','Administrator',0,'Workflow Action','fields','DocType',1,'workflow_action_name','Workflow Action Name',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('5386eb0058','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',4,'send_reminder','Send an email reminder in the morning',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL),('53d1c22f68','2014-04-17 16:53:52.640856','2015-04-04 15:11:13.078614','Administrator','Administrator',0,'System Settings','fields','DocType',4,'date_and_number_format','Date and Number Format',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('53e2d69578','2012-08-08 10:40:11.000000','2015-04-04 15:11:14.076672','Administrator','Administrator',0,'Comment','fields','DocType',9,'post_topic','Post Topic','post_topic','Data','Data',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('544d966d8e','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',23,'description','Description','description','Text Editor','Text',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,'300px','300px',NULL,NULL,NULL,0,NULL,NULL,NULL),('54b4dae670','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',6,'document_type','Document Type','document_type','Select','Select','\nMaster\nTransaction\nSystem\nOther',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('551a5cfbbf','2013-03-25 16:00:51.000000','2015-04-04 15:11:17.917763','Administrator','Administrator',0,'Blogger','fields','DocType',1,'disabled','Disabled',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('55f4109ec9','2013-02-21 20:12:42.000000','2015-04-04 15:11:15.105507','Administrator','Administrator',0,'Contact Us Settings','fields','DocType',9,'address_line2','Address Line 2',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('582cfd7e02','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',25,'signature','Signature',NULL,'Text Editor',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,'add_signature',0,0,NULL,NULL,NULL,NULL,0,0,NULL,0,''),('597a812000','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',16,'brand_html','Brand HTML',NULL,'Small Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Brand is what appears on the top-left of the toolbar. If it is an image, make sure it\nhas a transparent background and use the &lt;img /&gt; tag. Keep size as 200px x 30px',NULL,NULL,NULL,NULL,NULL),('5987983913','2013-01-29 17:55:08.000000','2015-04-04 15:11:24.475702','Administrator','Administrator',0,'Customize Form','fields','DocType',5,'column_break_5',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('5a1ca86ca5','2012-12-12 11:19:22.000000','2015-04-04 15:11:13.498761','Administrator','Administrator',0,'File Data','fields','DocType',4,'attached_to_name','Attached To Name',NULL,'Data',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,NULL),('5aa14a008c','2013-02-22 01:27:34.000000','2015-04-04 15:11:09.590636','Administrator','Administrator',0,'Page Role','fields','DocType',1,'role','Role','role','Link','Link','Role',0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('5af2be7a69','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',16,'ignore_user_permissions','Ignore User Permissions',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:doc.fieldtype===\"Link\"',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('5b62fd4000','2013-03-19 12:02:15.000000','2015-04-04 15:11:17.521595','Administrator','Administrator',0,'About Us Settings','fields','DocType',6,'sb1','Team Members',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),('5b872e6704','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',18,'search_fields','Search Fields','search_fields','Data','Data',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('5ba55a86e9','2014-04-17 16:53:52.640856','2015-04-04 15:11:13.078614','Administrator','Administrator',0,'System Settings','fields','DocType',10,'enable_scheduler','Enable Scheduled Jobs',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Run scheduled jobs only if checked',NULL,0,NULL,NULL,NULL),('5bb759e489','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',15,'display_settings','',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:!doc.__islocal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('5bd80d4dd3','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',49,'fb_username','Facebook Username',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL),('5c1d74e137','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','fields','DocType',14,'communication_medium','Communication Medium',NULL,'Select',NULL,'\nChat\nPhone\nEmail\nSMS\nVisit\nOther',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('5c659dc480','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',30,'bio','Bio',NULL,'Small Text',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('5cd5341f8b','2013-03-08 09:41:11.000000','2015-04-04 15:11:15.582389','Administrator','Administrator',0,'Blog Category','fields','DocType',1,'category_name','Category Name',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('5d6a43a22a','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',8,'font_size','Font Size',NULL,'Select',NULL,'\n12px\n13px\n14px\n15px\n16px\n17px\n18px',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,''),('5d957024b0','2013-03-09 15:45:57.000000','2015-04-04 15:11:13.159277','Administrator','Administrator',0,'Report','fields','DocType',10,'section_break_6',NULL,NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),('5e24bcda05','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',22,'column_break_21',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('5edb35d17f','2015-02-04 04:33:36.330477','2015-04-04 15:11:11.308875','Administrator','Administrator',0,'DocShare','fields','DocType',1,'user','User',NULL,'Link',NULL,'User',1,0,0,0,0,1,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,1,NULL,0,''),('5f21a6a2bf','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',3,'label_help','Label Help',NULL,'HTML','HTML',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('5f2ac1f868','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',2,'service','Service',NULL,'Select',NULL,'\nGMail\nYahoo Mail\nOutlook.com',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('5f8cc430a1','2013-03-19 12:02:15.000000','2015-04-04 15:11:17.521595','Administrator','Administrator',0,'About Us Settings','fields','DocType',8,'team_members','Team Members',NULL,'Table',NULL,'About Us Team Member',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),('602be558d4','2014-04-17 16:53:52.640856','2015-04-04 15:11:13.078614','Administrator','Administrator',0,'System Settings','fields','DocType',9,'session_expiry','Session Expiry',NULL,'Data',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'06:00','Session Expiry in Hours e.g. 06:00',NULL,NULL,NULL,NULL,NULL),('603ecefeaf','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','fields','DocType',19,'user','User',NULL,'Link',NULL,'User',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,NULL,NULL,'__user',NULL,NULL,NULL,NULL,1,NULL),('609924b413','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',1,'section_title','Title',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('60c1d21f16','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',26,'description','Description',NULL,'Small Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Description for search engine optimization.',NULL,NULL,NULL,NULL,NULL),('614778c012','2013-01-19 10:23:30.000000','2015-04-04 15:11:25.438587','Administrator','Administrator',0,'Country','fields','DocType',4,'code','Code',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('626ce0c650','2013-02-22 01:27:32.000000','2015-04-04 15:11:09.369240','Administrator','Administrator',0,'DefaultValue','fields','DocType',1,'defkey','Key','defkey','Data','Data',NULL,0,0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,'200px','200px',NULL,NULL,NULL,1,NULL,NULL,NULL),('628357b9e3','2012-07-03 13:29:42.000000','2015-04-04 15:11:25.760244','Administrator','Administrator',0,'Feed','fields','DocType',1,'feed_type','Feed Type',NULL,'Select',NULL,'\nComment\nLogin\nLabel\nInfo',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('631d069902','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',34,'modules_access','Modules Access',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'','Uncheck modules to hide from user\'s desktop',NULL,NULL,NULL,NULL,''),('633991ded5','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',33,'user_roles','Roles Assigned',NULL,'Table',NULL,'UserRole',NULL,1,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL),('63461b565a','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',2,'label','Label','label','Data','Data',NULL,0,NULL,NULL,NULL,NULL,0,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL),('634a6e5002','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','fields','DocType',2,'sent_or_received','Sent or Received',NULL,'Select',NULL,'Sent\nReceived',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('63c75d56f0','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',15,'read_only','Read Only',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('642584ab08','2013-01-08 15:50:01.000000','2015-04-04 15:11:06.866524','Administrator','Administrator',0,'Role','fields','DocType',1,'role_name','Role Name','role_name','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('647e9144a5','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',19,'sort_field','Sort Field',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'modified','',NULL,NULL,NULL,NULL,NULL),('6597fac296','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',2,'module','Module',NULL,'Link',NULL,'Module Def',0,0,0,0,0,1,NULL,0,0,NULL,NULL,0,0,NULL,NULL,'Website',NULL,0,0,NULL,0,''),('6610b49bbd','2013-03-09 15:45:57.000000','2015-04-04 15:11:13.159277','Administrator','Administrator',0,'Report','fields','DocType',5,'add_total_row','Add Total Row',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('661a5bac06','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',2,'home_page','Home Page',NULL,'Data',NULL,'',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Link that is the website home page. Standard Links (index, login, products, blog, about, contact)',NULL,1,NULL,NULL,NULL),('668e4d8e09','2014-07-17 06:54:20.782907','2015-04-04 15:11:29.372802','Administrator','Administrator',0,'Print Settings','fields','DocType',6,'column_break_6',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('66a15daa57','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',8,'column_break_6',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('66c8f9e065','2013-01-10 16:34:04.000000','2015-04-04 15:11:07.697838','Administrator','Administrator',0,'Property Setter','fields','DocType',6,'doc_type','DocType',NULL,'Link',NULL,'DocType',1,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),('66d34b4d9e','2014-04-17 16:53:52.640856','2015-04-04 15:11:13.078614','Administrator','Administrator',0,'System Settings','fields','DocType',3,'time_zone','Time Zone',NULL,'Select',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('676144bbc3','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',15,'read_only','Read Only',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'50px','50px',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('6867049ef7','2013-03-25 16:00:51.000000','2015-04-04 15:11:17.917763','Administrator','Administrator',0,'Blogger','fields','DocType',5,'bio','Bio',NULL,'Small Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('686fcae0f3','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',20,'report_hide','Report Hide','report_hide','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'50px','50px',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('687ed8171b','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',31,'twitter_share_via','Twitter Share via',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Tweet will be shared via your user account (if specified)',NULL,NULL,NULL,NULL,NULL),('69cfeaf303','2012-12-12 11:19:22.000000','2015-04-04 15:11:13.498761','Administrator','Administrator',0,'File Data','fields','DocType',3,'attached_to_doctype','Attached To DocType',NULL,'Link',NULL,'DocType',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,NULL),('6b166ebd38','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',6,'precision','Precision',NULL,'Select',NULL,'\n1\n2\n3\n4\n5\n6\n7\n8\n9',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:in_list([\"Float\", \"Currency\", \"Percent\"], doc.fieldtype)',0,NULL,NULL,NULL,NULL,'Set non-standard precision for a Float or Currency field',NULL,NULL,NULL,NULL,''),('6b93aff49d','2013-02-21 20:12:42.000000','2015-04-04 15:11:15.105507','Administrator','Administrator',0,'Contact Us Settings','fields','DocType',11,'state','State',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('6c130e43f6','2013-01-29 17:55:08.000000','2015-04-04 15:11:24.475702','Administrator','Administrator',0,'Customize Form','fields','DocType',1,'doc_type','Enter Form Type',NULL,'Link',NULL,'DocType',0,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('6c5bffcea3','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',32,'roles_html','Roles HTML',NULL,'HTML',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL),('6c5d622332','2013-01-29 17:55:08.000000','2015-04-04 15:11:24.475702','Administrator','Administrator',0,'Customize Form','fields','DocType',6,'max_attachments','Max Attachments',NULL,'Int',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,'',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('6c63b6f7db','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',5,'email_account_name','Email Account Name',NULL,'Data',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,'e.g. \"Support\", \"Sales\", \"Jerry Yang\"',0,0,NULL,0,''),('6d642571bc','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',16,'additional_permissions','Additional Permissions',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('6ddc070bb5','2013-03-28 10:35:30.000000','2015-04-04 15:11:16.027377','Administrator','Administrator',0,'Blog Post','fields','DocType',3,'published','Published',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('6ec730446a','2014-09-01 14:08:48.624556','2015-04-04 15:11:18.596754','Administrator','Administrator',0,'Web Form','fields','DocType',5,'published','Published',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('6ee293b784','2013-03-07 15:53:15.000000','2015-04-04 15:11:15.250035','Administrator','Administrator',0,'Website Slideshow','fields','DocType',4,'header','Header',NULL,'Text Editor',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:!doc.__islocal',0,NULL,NULL,NULL,NULL,'This goes above the slideshow.',NULL,NULL,NULL,NULL,NULL),('6ef60209ab','2012-08-02 15:17:28.000000','2015-04-04 15:11:22.003996','Administrator','Administrator',0,'Bulk Email','fields','DocType',1,'sender','Sender',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL),('6f0d9af48d','2014-03-04 08:29:52.000000','2015-04-04 15:11:15.926427','Administrator','Administrator',0,'Social Login Keys','fields','DocType',9,'github_client_secret','GitHub Client Secret',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('6f49cb2bd8','2012-08-08 10:40:11.000000','2015-04-04 15:11:14.076672','Administrator','Administrator',0,'Comment','fields','DocType',3,'comment_by','Comment By','comment_by','Data','Data',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('6fd22f312f','2014-07-11 17:18:09.923399','2015-04-04 15:11:22.628033','Administrator','Administrator',0,'Email Alert','fields','DocType',10,'column_break_6',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('700fc36901','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',17,'cb21',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('7139b60224','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',2,'label','Label','label','Data','Data',NULL,1,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('71507f4831','2013-01-17 11:36:45.000000','2015-04-04 15:11:12.426216','Administrator','Administrator',0,'Patch Log','fields','DocType',1,'patch','Patch',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('719536faaf','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',31,'oldfieldtype',NULL,'oldfieldtype','Data','Data',NULL,0,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('71c755c4d7','2012-12-28 10:49:55.000000','2015-04-04 15:11:21.053948','Administrator','Administrator',0,'Workflow','fields','DocType',2,'document_type','Document Type',NULL,'Link',NULL,'DocType',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'DocType on which this Workflow is applicable.',NULL,0,NULL,NULL,NULL),('71fa37a2a3','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','fields','DocType',23,'unread_notification_sent','Unread Notification Sent',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'0',NULL,NULL,NULL,NULL,1,''),('72711baf5b','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',23,'description','Description','description','Text','Text',NULL,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,'300px','300px',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('728569f0ef','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',12,'change_password','',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('7445462be1','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',13,'autoname','Auto Name','autoname','Data','Data',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'<a onclick=\"msgprint(\'<ol>\\\n<li><b>field:[fieldname]</b> - By Field\\\n<li><b>naming_series:</b> - By Naming Series (field called naming_series must be present\\\n<li><b>Prompt</b> - Prompt user for a name\\\n<li><b>[series]</b> - Series by prefix (separated by a dot); for example PRE.#####\\\n</ol>\')\">Naming Options</a>',NULL,NULL,NULL,NULL,NULL),('74eedb1eac','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',16,'css','CSS',NULL,'Code',NULL,'CSS',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'insert_style',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('75367a28fa','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',19,'text_align','Text Align',NULL,'Select',NULL,'Left\nCenter\nRight',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('75a6d64993','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',7,'options_help','Options Help',NULL,'HTML','HTML',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('75bcdb4750','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',13,'permlevel','Perm Level','permlevel','Int','Int',NULL,0,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'0',NULL,NULL,1,NULL,NULL,NULL),('75e7510e54','2013-01-10 16:34:04.000000','2015-04-04 15:11:07.697838','Administrator','Administrator',0,'Property Setter','fields','DocType',4,'value','Set Value',NULL,'Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'New value to be set',NULL,1,NULL,NULL,NULL),('76d6fcbeef','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',10,'create','Create','create','Check','Check',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,'32px','32px','1',NULL,NULL,1,NULL,NULL,NULL),('76f7c416c5','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',4,'password','Password',NULL,'Password',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,NULL,0,''),('779cf94b37','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',8,'custom','Custom?',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('77a782b616','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',21,'sb2','Permission Rules',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:!doc.istable',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('77d3f7be0d','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',14,'hidden','Hidden','hidden','Check','Check',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,'50px','50px',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('77e10d6aac','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',10,'options','Options','options','Text','Text',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'For Links, enter the DocType as range\nFor Select, enter list of Options separated by comma',NULL,1,NULL,NULL,NULL),('7823891445','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',12,'default_incoming','Default Incoming',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'enable_incoming',0,NULL,NULL,NULL,NULL,'e.g. replies@yourcomany.com. All replies will come to this inbox.',NULL,NULL,NULL,NULL,''),('782b769465','2014-03-04 08:29:52.000000','2015-04-04 15:11:15.926427','Administrator','Administrator',0,'Social Login Keys','fields','DocType',6,'google_client_secret','Google Client Secret',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('782fd8fb38','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',13,'repeat_till','Repeat Till',NULL,'Date',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'repeat_this_event',0,NULL,NULL,NULL,NULL,'Leave blank to repeat always',NULL,NULL,NULL,NULL,NULL),('787ceb093f','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',1,'sb0_5','',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('78ac01b9bb','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',27,'google_plus_one','Google Plus One',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('78b566de64','2015-03-24 14:28:15.882903','2015-04-04 15:11:10.519714','Administrator','Administrator',0,'Block Module','fields','DocType',1,'module','Module',NULL,'Data',NULL,'',0,0,0,0,0,1,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,NULL,0,''),('795476e3c4','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',7,'section_break_14',NULL,NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'apply_style',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('79c966a852','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',7,'in_list_view','In List View',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('7a95978a22','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',16,'send_notification_to','Send Notification to',NULL,'Small Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'notify_if_unreplied',0,NULL,NULL,NULL,NULL,'Email Ids',NULL,NULL,NULL,NULL,''),('7b979c69d7','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','fields','DocType',18,'email_account','Email Account',NULL,'Link',NULL,'Email Account',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('7bc051acb1','2014-07-17 06:54:20.782907','2015-04-04 15:11:29.372802','Administrator','Administrator',0,'Print Settings','fields','DocType',4,'print_style_section','Print Style',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('7bd1c7d493','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',13,'reqd','Is Mandatory Field','reqd','Check','Check',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('7bf22819dd','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',13,'new_password','Set New Password',NULL,'Password',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('7cbc03a543','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',12,'repeat_on','Repeat On',NULL,'Select',NULL,'\nEvery Day\nEvery Week\nEvery Month\nEvery Year',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'repeat_this_event',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('7d2e73fbc0','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',3,'apply_style','Apply Style',NULL,'Check',NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'1','This must be checked if the below style settings are applicable',NULL,NULL,NULL,NULL,''),('7dbcd10234','2012-08-08 10:40:11.000000','2015-04-04 15:11:14.076672','Administrator','Administrator',0,'Comment','fields','DocType',6,'comment_time','Comment Time','comment_time','Data','Data',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('7de4163eff','2013-03-07 12:26:33.000000','2015-04-04 15:11:19.456728','Administrator','Administrator',0,'Website Slideshow Item','fields','DocType',2,'heading','Heading',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'200px','200px',NULL,NULL,NULL,1,NULL,NULL,NULL),('7e2f923047','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',9,'column_break0',NULL,NULL,'Column Break','Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'50%','50%',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('7e7631c1c9','2012-12-28 10:49:56.000000','2015-04-04 15:11:21.707031','Administrator','Administrator',0,'Workflow State','fields','DocType',1,'workflow_state_name','State',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('7e7afdcc28','2012-08-08 10:40:11.000000','2015-04-04 15:11:14.076672','Administrator','Administrator',0,'Comment','fields','DocType',2,'comment_type','Comment Type',NULL,'Data',NULL,'Email\nChat\nPhone\nSMS\nCreated\nSubmitted\nCancelled\nAssigned\nAssignment Completed\nComment\nWorkflow\nLabel\nAttachment\nAttachment Removed',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('7e8b726b64','2013-01-23 19:54:43.000000','2015-04-04 15:11:28.894125','Administrator','Administrator',0,'Print Format','fields','DocType',2,'edit_format','Edit Format',NULL,'Button',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:!doc.custom_format',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('7f4adde2dd','2013-01-28 10:06:02.000000','2015-04-04 15:11:25.128723','Administrator','Administrator',0,'Currency','fields','DocType',4,'fraction_units','Fraction Units',NULL,'Int',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'1 Currency = [?] Fraction\nFor e.g. 1 USD = 100 Cent',NULL,1,NULL,NULL,NULL),('7f9e004408','2013-05-24 13:41:00.000000','2015-04-04 15:11:27.356000','Administrator','Administrator',0,'Note','fields','DocType',1,'title','Title',NULL,'Data',NULL,NULL,NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL),('7fe2510035','2013-03-09 15:45:57.000000','2015-04-04 15:11:13.159277','Administrator','Administrator',0,'Report','fields','DocType',7,'report_type','Report Type',NULL,'Select',NULL,'Report Builder\nQuery Report\nScript Report',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),('7fe42c32db','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',33,'favicon','FavIcon',NULL,'Attach',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'An icon file with .ico extension. Should be 16 x 16 px. Generated using a favicon generator. [<a href=\"http://favicon-generator.org/\" target=\"_blank\">favicon-generator.org</a>]',NULL,NULL,NULL,NULL,NULL),('8095ee0852','2013-01-29 17:55:08.000000','2015-04-04 15:11:24.475702','Administrator','Administrator',0,'Customize Form','fields','DocType',10,'column_break_10',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('8122febda5','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',32,'max_attachments','Max Attachments','max_attachments','Int','Int',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('81f6cfe34f','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',9,'use_ssl','Use SSL',NULL,'Check',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,'enable_incoming',0,0,NULL,NULL,NULL,NULL,0,0,NULL,0,''),('82d97ab4b1','2014-09-01 14:08:48.624556','2015-04-04 15:11:18.596754','Administrator','Administrator',0,'Web Form','fields','DocType',14,'actions','Actions',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('82e0f188c0','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',31,'sb1','Roles',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'Check / Uncheck roles assigned to the User. Click on the Role to find out what permissions that Role has.',NULL,NULL,NULL,1,NULL),('830f9c2c17','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',27,'css','Style using CSS',NULL,'Code',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'apply_style',0,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,''),('833d27cdd1','2013-01-10 16:34:03.000000','2015-04-04 15:11:10.200963','Administrator','Administrator',0,'Module Def','fields','DocType',1,'module_name','Module Name','module_name','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('83f61f5e4a','2013-03-07 12:26:33.000000','2015-04-04 15:11:19.456728','Administrator','Administrator',0,'Website Slideshow Item','fields','DocType',1,'image','Image',NULL,'Attach',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('84491e570d','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',6,'section_break_6',NULL,NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('8459b57160','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',22,'default','Default','default','Text','Text',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('853459a118','2014-09-01 14:08:48.624556','2015-04-04 15:11:18.596754','Administrator','Administrator',0,'Web Form','fields','DocType',1,'title','Title',NULL,'Data',NULL,NULL,0,0,0,0,0,1,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL),('85a723cd9a','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',20,'footer','Footer',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('85dd3a8742','2013-01-23 19:54:43.000000','2015-04-04 15:11:28.894125','Administrator','Administrator',0,'Print Format','fields','DocType',8,'print_format_type','Print Format Type',NULL,'Select',NULL,'Server\nClient',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'custom_format',0,NULL,NULL,NULL,'Server','',NULL,0,NULL,0,NULL),('8656e245b9','2012-08-08 10:40:11.000000','2015-04-04 15:11:14.076672','Administrator','Administrator',0,'Comment','fields','DocType',7,'comment_doctype','Comment Doctype','comment_doctype','Data','Data',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8712fecf54','2012-12-12 11:19:22.000000','2015-04-04 15:11:13.498761','Administrator','Administrator',0,'File Data','fields','DocType',1,'file_name','File Name','file_name','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,NULL),('87265f3ed3','2014-09-01 14:08:48.624556','2015-04-04 15:11:18.596754','Administrator','Administrator',0,'Web Form','fields','DocType',17,'advanced','Advanced',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('872fbf5035','2012-11-22 17:45:46.000000','2015-04-04 15:11:28.541028','Administrator','Administrator',0,'Letter Head','fields','DocType',4,'content','Content','content','Text Editor','Text Editor',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'letter_head_name',0,NULL,NULL,NULL,NULL,'Letter Head in HTML',NULL,1,NULL,NULL,NULL),('87d4d6d791','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',1,'role_and_level','Role and Level',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('889473dcce','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',14,'reset_password_key','Reset Password Key',NULL,'Data',NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL),('88f99a6b31','2014-07-11 17:18:09.923399','2015-04-04 15:11:22.628033','Administrator','Administrator',0,'Email Alert','fields','DocType',16,'attach_print','Attach Print',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('89ab42f1a9','2014-09-01 14:14:14.292173','2015-04-04 15:11:16.724128','Administrator','Administrator',0,'Web Form Field','fields','DocType',11,'column_break_8',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL),('89cc7de427','2014-07-17 06:54:20.782907','2015-04-04 15:11:29.372802','Administrator','Administrator',0,'Print Settings','fields','DocType',7,'font_size','Font Size',NULL,'Float',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'In points. Default is 9.',NULL,NULL,NULL,NULL,NULL),('8a2b477571','2013-02-22 01:27:36.000000','2015-04-04 15:11:21.384297','Administrator','Administrator',0,'Workflow Transition','fields','DocType',1,'state','State',NULL,'Link',NULL,'Workflow State',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,'200px','200px',NULL,NULL,NULL,1,NULL,NULL,NULL),('8a3def53b8','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',19,'display','Display',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('8a8262bca6','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',21,'parent_web_page','Parent Web Page',NULL,'Link',NULL,'Web Page',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8a9dd49b09','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','fields','DocType',12,'sender','Sender',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8b7ba01f16','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',18,'thursday','Thursday',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:doc.repeat_this_event && doc.repeat_on===\"Every Day\"',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8ba080b058','2013-01-10 16:34:03.000000','2015-04-04 15:11:10.200963','Administrator','Administrator',0,'Module Def','fields','DocType',2,'app_name','App Name',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('8bddb5f120','2013-03-28 10:35:30.000000','2015-04-04 15:11:16.027377','Administrator','Administrator',0,'Blog Post','fields','DocType',9,'blog_intro','Blog Intro',NULL,'Small Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Description for listing page, in plain text, only a couple of lines. (max 140 characters)',NULL,0,NULL,NULL,NULL),('8c5c7c854b','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',27,'print_hide','Print Hide','print_hide','Check','Check',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,'50px','50px',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8c9744eb84','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',21,'print_hide','Print Hide','print_hide','Check','Check',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8ca4bbb8f9','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',9,'website_theme_image_link','Website Theme Image Link',NULL,'Small Text',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('8dda350c78','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',16,'column_break_15',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8e01768f92','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',27,'enable_auto_reply','Enable Auto Reply',NULL,'Check',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,NULL,0,''),('8e0b582238','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',11,'append_to','Append To',NULL,'Link',NULL,'DocType',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'enable_incoming',0,NULL,NULL,NULL,NULL,'Append as communication against this DocType (must have fields, \"Status\", \"Subject\")',NULL,1,NULL,NULL,''),('8e26e6fbf4','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',40,'user_type','User Type','user_type','Select','Select','System User\nWebsite User',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'System User','User Type \"System User\" can access Desktop. \"Website User\" can only be logged into the website and portal pages. ',NULL,1,NULL,1,NULL),('8e9e6da796','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',1,'theme','Theme',NULL,'Data',NULL,NULL,1,0,0,0,0,1,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,NULL,0,''),('8ebf3fe92d','2012-12-28 10:49:55.000000','2015-04-04 15:11:21.053948','Administrator','Administrator',0,'Workflow','fields','DocType',4,'states_head','States',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Different \"States\" this document can exist in. Like \"Open\", \"Pending Approval\" etc.',NULL,NULL,NULL,NULL,NULL),('8eed8d6b42','2014-09-01 14:08:48.624556','2015-04-04 15:11:18.596754','Administrator','Administrator',0,'Web Form','fields','DocType',13,'web_form_fields','Web Form Fields',NULL,'Table',NULL,'Web Form Field',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('8efcb1c8db','2013-03-09 15:45:57.000000','2015-04-04 15:11:13.159277','Administrator','Administrator',0,'Report','fields','DocType',6,'column_break_4',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),('8f23653f42','2013-01-23 19:54:43.000000','2015-04-04 15:11:28.894125','Administrator','Administrator',0,'Print Format','fields','DocType',11,'format_data','Format Data',NULL,'Code',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,''),('8f79d84c28','2014-09-01 14:14:14.292173','2015-04-04 15:11:16.724128','Administrator','Administrator',0,'Web Form Field','fields','DocType',8,'options','Options',NULL,'Text',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,1,NULL,0,NULL),('8fc2de830b','2014-06-19 05:20:26.331041','2015-04-04 15:11:22.313767','Administrator','Administrator',0,'Standard Reply','fields','DocType',3,'owner','Owner',NULL,'Link',NULL,'User',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'user',NULL,NULL,NULL,NULL,NULL,NULL),('8fe50f02b9','2014-06-19 05:20:26.331041','2015-04-04 15:11:22.313767','Administrator','Administrator',0,'Standard Reply','fields','DocType',2,'response','Response',NULL,'Text Editor',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('901a75c63d','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',14,'cancel','Cancel','cancel','Check','Check',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,'32px','32px',NULL,NULL,NULL,1,NULL,NULL,NULL),('904b035590','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',10,'repeat_this_event','Repeat this Event',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('91c438e43e','2012-07-03 13:30:35.000000','2015-04-04 15:11:26.811873','Administrator','Administrator',0,'ToDo','fields','DocType',9,'reference_type','Reference Type','reference_type','Link','Data','DocType',0,0,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),('922359dcee','2013-01-19 10:23:30.000000','2015-04-04 15:11:25.438587','Administrator','Administrator',0,'Country','fields','DocType',3,'time_zones','Time Zones',NULL,'Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('9284258c45','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',8,'read','Read','read','Check','Check',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,'32px','32px','1',NULL,NULL,1,NULL,NULL,NULL),('930baac4b9','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',7,'ends_on','Ends on',NULL,'Datetime',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('931e212453','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',19,'smtp_server','SMTP Server',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'enable_outgoing',0,NULL,NULL,NULL,NULL,'e.g. smtp.gmail.com',NULL,NULL,NULL,NULL,''),('933868cb4b','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',12,'set_banner_from_image','Set Banner from Image',NULL,'Button',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('93550051e3','2013-01-29 17:55:08.000000','2015-04-04 15:11:24.475702','Administrator','Administrator',0,'Customize Form','fields','DocType',7,'allow_copy','Hide Copy',NULL,'Check',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('942a6d3c18','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',34,'hide_heading','Hide Heading','hide_heading','Check','Check',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('9433094687','2014-07-11 17:18:09.923399','2015-04-04 15:11:22.628033','Administrator','Administrator',0,'Email Alert','fields','DocType',4,'document_type','Document Type',NULL,'Link',NULL,'DocType',1,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('94368388d3','2014-04-17 16:53:52.640856','2015-04-04 15:11:13.078614','Administrator','Administrator',0,'System Settings','fields','DocType',7,'float_precision','Float Precision',NULL,'Select',NULL,'\n2\n3\n4\n5\n6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('945b1b11ab','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',1,'details','',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('95458231c5','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','fields','DocType',20,'column_break5','On',NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('954aedd270','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',26,'column_break_17',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('9569b95278','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',54,'github_username','Github Username',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL),('956bdb2a76','2013-03-28 10:35:30.000000','2015-04-04 15:11:16.027377','Administrator','Administrator',0,'Blog Post','fields','DocType',4,'column_break_3',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('95f1150dfd','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',27,'is_submittable','Is Submittable',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('96611de8f5','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',22,'parent_website_route','Parent Website Route',NULL,'Read Only',NULL,'',NULL,1,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('96976ad105','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',23,'no_copy','No Copy','no_copy','Check','Check',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('969ae6d5e0','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',29,'allow_rename','Allow Rename','allow_rename','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('97298e8475','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',16,'top_bar_color','Top Bar Color',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('98199ad1df','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',6,'search_index','Index','search_index','Check','Check',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,'50px','50px',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('986c0fcf23','2012-12-12 11:19:22.000000','2015-04-04 15:11:13.498761','Administrator','Administrator',0,'File Data','fields','DocType',6,'content_hash','Content Hash',NULL,'Data',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('9876ff7635','2014-03-04 08:29:52.000000','2015-04-04 15:11:15.926427','Administrator','Administrator',0,'Social Login Keys','fields','DocType',8,'github_client_id','GitHub Client ID',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('98a10519f7','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',29,'linked_in_share','Linked In Share',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('98e34842e0','2014-07-11 17:18:09.923399','2015-04-04 15:11:22.628033','Administrator','Administrator',0,'Email Alert','fields','DocType',2,'filters','Filters',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('991cb130a4','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',25,'groups','Groups',NULL,'Column Break','Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'50%','50%',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('991f4f2783','2014-07-11 17:19:37.037109','2015-04-04 15:11:23.046681','Administrator','Administrator',0,'Email Alert Recipient','fields','DocType',2,'cc','CC',NULL,'Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Optional: Always send to these ids. Each email id on a new row',NULL,1,NULL,NULL,NULL),('9941e5d595','2014-07-11 17:18:09.923399','2015-04-04 15:11:22.628033','Administrator','Administrator',0,'Email Alert','fields','DocType',17,'message_examples','Message Examples',NULL,'HTML',NULL,'<h5>Message Example (Markdown)</h5>\n<pre>Transaction {{ doc.name }} has exceeded Due Date. Please take relevant action\n\n#### Details\n\nCustomer: {{ doc.customer }}\nAmount: {{ doc.total_amount }}</pre>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('996496010a','2013-03-08 09:41:11.000000','2015-04-04 15:11:15.582389','Administrator','Administrator',0,'Blog Category','fields','DocType',3,'published','Published',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('999cafe3f2','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',6,'user_permission_doctypes','User Permission DocTypes',NULL,'Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',0,NULL,NULL,NULL,NULL,'JSON list of DocTypes used to apply User Permissions. If empty, all linked DocTypes will be used to apply User Permissions.',NULL,NULL,NULL,1,NULL),('99fe40013d','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',15,'top_bar','Top Bar',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Menu items in the Top Bar. For setting the color of the Top Bar, go to selected Website Theme.',NULL,NULL,NULL,NULL,NULL),('9a18b1c2f8','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',26,'gender','Gender','gender','Select','Select','\nMale\nFemale\nOther',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('9a3480ffbe','2014-07-11 17:18:09.923399','2015-04-04 15:11:22.628033','Administrator','Administrator',0,'Email Alert','fields','DocType',14,'message_sb','Message',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('9a3de58d70','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',8,'website_theme_image','Website Theme Image',NULL,'Image',NULL,'website_theme_image_link',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('9a9d333903','2012-07-03 13:29:42.000000','2015-04-04 15:11:25.760244','Administrator','Administrator',0,'Feed','fields','DocType',2,'doc_type','Doc Type',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('9ae4f46f84','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',20,'set_user_permissions','Set User Permissions',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'This role update User Permissions for a user',NULL,NULL,NULL,NULL,NULL),('9b925555ce','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',19,'sidebar_items','Sidebar Items',NULL,'Table',NULL,'Top Bar Item',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('9baef0d3ad','2014-09-01 14:08:48.624556','2015-04-04 15:11:18.596754','Administrator','Administrator',0,'Web Form','fields','DocType',3,'doc_type','Select DocType',NULL,'Link',NULL,'DocType',0,0,0,0,0,1,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,1,NULL,0,NULL),('9bd7d074c4','2013-02-22 01:27:36.000000','2015-04-04 15:11:21.384297','Administrator','Administrator',0,'Workflow Transition','fields','DocType',3,'next_state','Next State',NULL,'Link',NULL,'Workflow State',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,'200px','200px',NULL,NULL,NULL,1,NULL,NULL,NULL),('9d1c37c871','2014-06-19 05:20:26.331041','2015-04-04 15:11:22.313767','Administrator','Administrator',0,'Standard Reply','fields','DocType',1,'subject','Subject',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('9d5f680434','2013-03-08 09:41:11.000000','2015-04-04 15:11:15.582389','Administrator','Administrator',0,'Blog Category','fields','DocType',5,'page_name','Page Name',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('9db1b8c7df','2013-03-11 17:48:16.000000','2015-04-04 15:11:17.486352','Administrator','Administrator',0,'Blog Settings','fields','DocType',1,'blog_title','Blog Title',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('9e7d29918c','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',14,'column_break_11',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('9f1b09d9bb','2014-07-11 17:18:09.923399','2015-04-04 15:11:22.628033','Administrator','Administrator',0,'Email Alert','fields','DocType',5,'event','Send Alert On',NULL,'Select',NULL,'\nNew\nSave\nSubmit\nCancel\nDays After\nDays Before\nValue Change',1,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('9f1b94e60b','2012-07-03 13:30:35.000000','2015-04-04 15:11:26.811873','Administrator','Administrator',0,'ToDo','fields','DocType',11,'column_break_10',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('9f53aff7b7','2013-03-28 10:35:30.000000','2015-04-04 15:11:16.027377','Administrator','Administrator',0,'Blog Post','fields','DocType',5,'blog_category','Blog Category',NULL,'Link',NULL,'Blog Category',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('9f5f0968d9','2013-02-22 01:27:36.000000','2015-04-04 15:11:21.384297','Administrator','Administrator',0,'Workflow Transition','fields','DocType',4,'allowed','Allowed',NULL,'Link',NULL,'Role',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,'200px','200px',NULL,NULL,NULL,1,NULL,NULL,NULL),('a043b8f6ca','2013-02-22 01:28:08.000000','2015-04-04 15:11:18.240871','Administrator','Administrator',0,'Top Bar Item','fields','DocType',2,'parent_label','Parent Label',NULL,'Select',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'If you set this, this Item will come in a drop-down under the selected parent.',NULL,1,NULL,NULL,NULL),('a06017ea3f','2014-02-20 17:22:37.000000','2015-04-04 15:11:12.769699','Administrator','Administrator',0,'Version','fields','DocType',1,'ref_doctype','Ref DocType',NULL,'Link',NULL,'DocType',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('a249853b74','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',4,'custom','Custom?',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,''),('a25a215001','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',11,'permissions','Permissions',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('a25e7b8e45','2014-07-11 17:18:09.923399','2015-04-04 15:11:22.628033','Administrator','Administrator',0,'Email Alert','fields','DocType',1,'enabled','Enabled',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL),('a26f9522e3','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',14,'banner_html','Banner HTML',NULL,'Small Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Banner is above the Top Menu Bar.',NULL,NULL,NULL,NULL,NULL),('a272d0d62b','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',37,'sb2','Defaults',NULL,'Section Break','Column Break',NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,'50%','50%',NULL,'These values will be automatically updated in transactions and also will be useful to restrict permissions for this user on transactions containing these values.',NULL,NULL,NULL,1,NULL),('a27da7aa9d','2013-03-11 17:48:16.000000','2015-04-04 15:11:17.486352','Administrator','Administrator',0,'Blog Settings','fields','DocType',3,'writers_introduction','Writers Introduction',NULL,'Small Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('a3070ee05d','2014-02-20 17:22:37.000000','2015-04-04 15:11:12.769699','Administrator','Administrator',0,'Version','fields','DocType',2,'docname','Docname',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('a34fca1b55','2012-07-03 13:30:35.000000','2015-04-04 15:11:26.811873','Administrator','Administrator',0,'ToDo','fields','DocType',7,'owner','Assigned To',NULL,'Link',NULL,'User',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL),('a3eb851010','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',37,'default_print_format','Default Print Format',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('a418cec75f','2014-07-11 17:19:37.037109','2015-04-04 15:11:23.046681','Administrator','Administrator',0,'Email Alert Recipient','fields','DocType',3,'condition','Condition',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Expression, Optional',NULL,1,NULL,NULL,NULL),('a4968c35d1','2012-12-20 17:16:49.000000','2015-04-04 15:11:08.696742','Administrator','Administrator',0,'Page','fields','DocType',1,'page_html','Page HTML',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('a4cacea858','2013-01-10 16:34:04.000000','2015-04-04 15:11:07.697838','Administrator','Administrator',0,'Property Setter','fields','DocType',8,'property','Property',NULL,'Data',NULL,NULL,1,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),('a4e4d55429','2012-08-08 10:40:11.000000','2015-04-04 15:11:14.076672','Administrator','Administrator',0,'Comment','fields','DocType',10,'unsubscribed','Unsubscribed',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('a54cd4517d','2013-03-09 15:45:57.000000','2015-04-04 15:11:13.159277','Administrator','Administrator',0,'Report','fields','DocType',11,'query','Query',NULL,'Code',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:doc.report_type==\"Query Report\"',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),('a5b4d24d2c','2013-03-09 15:45:57.000000','2015-04-04 15:11:13.159277','Administrator','Administrator',0,'Report','fields','DocType',1,'report_name','Report Name',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),('a6508eafab','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',52,'column_break_49',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('a6a1dfd7e3','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',4,'email','Email','email','Data','Data','Email',0,0,NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('a788c55ce7','2012-08-02 15:17:28.000000','2015-04-04 15:11:22.003996','Administrator','Administrator',0,'Bulk Email','fields','DocType',5,'error','Error',NULL,'Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL),('a79c408df8','2014-09-01 14:08:48.624556','2015-04-04 15:11:18.596754','Administrator','Administrator',0,'Web Form','fields','DocType',15,'success_message','Success Message',NULL,'Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Message to be displayed on successful completion',NULL,NULL,NULL,NULL,NULL),('a823180d4f','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',16,'user_image','User Image',NULL,'Attach',NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Get your globally recognized avatar from <a href=\"https://gravatar.com/\">Gravatar.com</a>',NULL,NULL,NULL,NULL,NULL),('a873a84abb','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',17,'outgoing_mail_settings','',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('a8f34bef2b','2013-02-21 20:12:42.000000','2015-04-04 15:11:15.105507','Administrator','Administrator',0,'Contact Us Settings','fields','DocType',13,'country','Country',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('a91ebf5b61','2014-09-01 14:14:14.292173','2015-04-04 15:11:16.724128','Administrator','Administrator',0,'Web Form Field','fields','DocType',4,'reqd','Mandatory',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('a962ab3025','2014-09-01 14:08:48.624556','2015-04-04 15:11:18.596754','Administrator','Administrator',0,'Web Form','fields','DocType',12,'introduction_text','Introduction',NULL,'Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('a9ab108b75','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',19,'allow_on_submit','Allow on Submit','allow_on_submit','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'50px','50px',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('aa42f29a8a','2012-08-02 15:17:28.000000','2015-04-04 15:11:22.003996','Administrator','Administrator',0,'Bulk Email','fields','DocType',4,'status','Status',NULL,'Select',NULL,'\nNot Sent\nSending\nSent\nError',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'Not Sent',NULL,NULL,1,NULL,NULL,NULL),('aab5724133','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',11,'section_break_11',NULL,NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'repeat_this_event',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('aaee7f16d6','2012-12-20 17:16:49.000000','2015-04-04 15:11:08.696742','Administrator','Administrator',0,'Page','fields','DocType',6,'module','Module','module','Link','Select','Module Def',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('aaf7a78410','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','fields','DocType',7,'reference_name','Reference Name',NULL,'Dynamic Link',NULL,'reference_doctype',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('abe63eb28c','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',22,'section_break_4',NULL,NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'apply_style',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('ac8748a5aa','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',25,'short_bio','',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('acc047e328','2015-03-18 09:41:20.216319','2015-04-04 15:11:23.842816','Administrator','Administrator',0,'Email Unsubscribe','fields','DocType',3,'reference_name','Reference Name',NULL,'Dynamic Link',NULL,'reference_doctype',0,0,0,0,0,1,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,1,NULL,0,''),('acc77124c1','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',17,'column_break_13',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('acd6a941de','2014-09-01 14:08:48.624556','2015-04-04 15:11:18.596754','Administrator','Administrator',0,'Web Form','fields','DocType',18,'web_page_link_text','Web Page Link Text',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Text to be displayed for Link to Web Page if this form has a web page. Link route will be automatically generated based on `page_name` and `parent_website_route`',NULL,NULL,NULL,NULL,''),('ad1acc494f','2013-03-07 12:26:33.000000','2015-04-04 15:11:19.456728','Administrator','Administrator',0,'Website Slideshow Item','fields','DocType',3,'description','Description',NULL,'Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'200px','200px',NULL,NULL,NULL,1,NULL,NULL,NULL),('aea34d3e35','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','fields','DocType',16,'section_break2',NULL,NULL,'Section Break',NULL,'simple',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('aef2edd9fe','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',5,'cb1',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'50%',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('aefa4d06d8','2012-12-20 17:16:49.000000','2015-04-04 15:11:08.696742','Administrator','Administrator',0,'Page','fields','DocType',9,'roles','Roles','roles','Table','Table','Page Role',0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('aff5ce8fce','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',5,'first_name','First Name','first_name','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL),('b03c627783','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',18,'no_sidebar','Hide Sidebar',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('b0f774c6e5','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',25,'google_analytics_id','Google Analytics ID',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Add Google Analytics ID: eg. UA-89XXX57-1. Please search help on Google Analytics for more information.',NULL,NULL,NULL,NULL,NULL),('b1cc099ab7','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',41,'login_after','Login After',NULL,'Int',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Allow user to login only after this hour (0-24)',NULL,NULL,NULL,1,NULL),('b2375bdc6a','2013-01-23 19:54:43.000000','2015-04-04 15:11:28.894125','Administrator','Administrator',0,'Print Format','fields','DocType',6,'section_break_6',NULL,NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('b2fb313ebf','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',5,'reqd','Mandatory','reqd','Check','Check',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,'50px','50px',NULL,NULL,NULL,1,NULL,NULL,NULL),('b39f70967f','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',14,'hidden','Hidden','hidden','Check','Check',NULL,0,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,'50px','50px',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('b435a28ab7','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',23,'signature_section','',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,NULL,0,''),('b46640399b','2013-03-08 09:41:11.000000','2015-04-04 15:11:15.582389','Administrator','Administrator',0,'Blog Category','fields','DocType',4,'parent_website_route','Parent Website Route',NULL,'Read Only',NULL,'',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'blog',NULL,NULL,1,NULL,NULL,NULL),('b58005fe1f','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',24,'email','Email',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,NULL),('b5934f241e','2012-07-03 13:30:35.000000','2015-04-04 15:11:26.811873','Administrator','Administrator',0,'ToDo','fields','DocType',10,'reference_name','Reference Name','reference_name','Dynamic Link','Data','reference_type',0,0,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),('b5ee1f3d91','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',19,'email_settings','Email Settings',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('b67e85f945','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',24,'cb30','Permissions Settings',NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('b681f17ace','2013-03-09 15:45:57.000000','2015-04-04 15:11:13.159277','Administrator','Administrator',0,'Report','fields','DocType',3,'is_standard','Is Standard',NULL,'Select',NULL,'No\nYes',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,NULL),('b682ed3c35','2013-01-16 13:09:40.000000','2015-04-04 15:11:14.607024','Administrator','Administrator',0,'Scheduler Log','fields','DocType',2,'error','Error',NULL,'Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('b736b2754b','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',32,'misc_section','Misc',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('b739bef215','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',2,'module','Module','module','Link','Link','Module Def',1,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('b754847261','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',6,'mailbox_settings','',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,NULL,0,''),('b7647705b5','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','fields','DocType',11,'recipients','Recipients',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('b852c662f1','2013-03-07 11:55:11.000000','2015-04-04 15:11:17.629439','Administrator','Administrator',0,'About Us Team Member','fields','DocType',1,'full_name','Full Name',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,'150px',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('b8aa1ad410','2012-08-02 15:17:28.000000','2015-04-04 15:11:22.003996','Administrator','Administrator',0,'Bulk Email','fields','DocType',8,'send_after','Send After',NULL,'Datetime',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,''),('b8c8c89d67','2014-09-01 14:08:48.624556','2015-04-04 15:11:18.596754','Administrator','Administrator',0,'Web Form','fields','DocType',10,'allow_comments','Allow Comments',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'login_required',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('b91f5d5a27','2012-08-08 10:40:11.000000','2015-04-04 15:11:14.076672','Administrator','Administrator',0,'Comment','fields','DocType',1,'comment','Comment','comment','Text','Text',NULL,0,NULL,NULL,NULL,NULL,1,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('b9e29e306c','2013-02-22 01:27:36.000000','2015-04-04 15:11:20.741323','Administrator','Administrator',0,'Workflow Document State','fields','DocType',3,'update_field','Update Field',NULL,'Select',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('ba002d0422','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',13,'javascript','Javascript',NULL,'Code',NULL,'Javascript',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'insert_code',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('ba00b63414','2013-01-28 10:06:02.000000','2015-04-04 15:11:25.128723','Administrator','Administrator',0,'Currency','fields','DocType',2,'enabled','Enabled',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('bb1e1b19a5','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','fields','DocType',1,'naming_series','Series',NULL,'Select',NULL,'COMM-',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'COMM-',NULL,NULL,NULL,NULL,NULL,NULL),('bb7223098a','2014-09-01 14:08:48.624556','2015-04-04 15:11:18.596754','Administrator','Administrator',0,'Web Form','fields','DocType',19,'breadcrumbs','Breadcrumbs',NULL,'Small Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'In JSON as <pre>[{\"title\":\"Jobs\", \"name\":\"jobs\"}]</pre>',NULL,NULL,NULL,NULL,''),('bc55382ffb','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',20,'sort_order','Sort Order',NULL,'Select',NULL,'ASC\nDESC',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'DESC',NULL,NULL,NULL,NULL,NULL,NULL),('bccc9a3997','2012-12-28 10:49:55.000000','2015-04-04 15:11:21.053948','Administrator','Administrator',0,'Workflow','fields','DocType',7,'transitions','Transitions',NULL,'Table',NULL,'Workflow Transition',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Rules defining transition of state in the workflow.',NULL,NULL,NULL,NULL,NULL),('bce1925f13','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',15,'column_break_14',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('bd322411f8','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',11,'time_zone','Timezone',NULL,'Select',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL),('bd9359e230','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',9,'text_webfont','Google Font (Text)',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Add the name of a <a href=\"https://www.google.com/fonts/\" target=\"_blank\">Google Web Font</a> e.g. \"Open Sans\"',NULL,NULL,NULL,NULL,''),('bf09a3db93','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',5,'column_break_2',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,NULL,0,''),('bf1b9a7c90','2013-02-22 01:27:36.000000','2015-04-04 15:11:20.741323','Administrator','Administrator',0,'Workflow Document State','fields','DocType',1,'state','State',NULL,'Link',NULL,'Workflow State',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,'160px','160px',NULL,NULL,NULL,1,NULL,NULL,NULL),('bf421dbdb8','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',24,'add_signature','Add Signature',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('bf87443cd2','2013-01-28 10:06:02.000000','2015-04-04 15:11:25.128723','Administrator','Administrator',0,'Currency','fields','DocType',6,'number_format','Number Format',NULL,'Select',NULL,'\n#,###.##\n#.###,##\n# ###.##\n# ###,##\n#\'###.##\n#, ###.##\n#,##,###.##\n#,###.###\n#.###\n#,###',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'How should this currency be formatted? If not set, will use system defaults',NULL,1,NULL,NULL,NULL),('bff628f735','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',50,'fb_userid','Facebook User ID',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL),('c07326d613','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',23,'background_image','Background Image',NULL,'Attach',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('c09e07351e','2013-01-10 16:34:01.000000','2015-04-04 15:11:24.153999','Administrator','Administrator',0,'Custom Script','fields','DocType',3,'script','Script','script','Code','Code','Script',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('c0c3f13b7b','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',1,'sb0','',NULL,'Section Break','Section Break',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('c0d20cbdee','2013-03-25 16:00:51.000000','2015-04-04 15:11:17.917763','Administrator','Administrator',0,'Blogger','fields','DocType',7,'posts','Posts',NULL,'Int',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,NULL),('c0e714f92d','2013-03-19 12:02:15.000000','2015-04-04 15:11:17.521595','Administrator','Administrator',0,'About Us Settings','fields','DocType',5,'company_history','Org History',NULL,'Table',NULL,'Company History',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),('c0ef3af84f','2013-01-29 17:55:08.000000','2015-04-04 15:11:24.475702','Administrator','Administrator',0,'Customize Form','fields','DocType',2,'properties','',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'doc_type',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('c108d7d9ba','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',35,'column_break_28',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('c12db47416','2013-01-29 17:55:08.000000','2015-04-04 15:11:24.475702','Administrator','Administrator',0,'Customize Form','fields','DocType',8,'section_break_8',NULL,NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'doc_type',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('c229e09bde','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',9,'description','Field Description','description','Text','Text',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,'300px','300px',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('c2c2a187f1','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',3,'event_type','Event Type','event_type','Select','Select','Private\nPublic\nCancel',1,NULL,NULL,NULL,NULL,1,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('c35ac9724c','2013-05-24 13:41:00.000000','2015-04-04 15:11:27.356000','Administrator','Administrator',0,'Note','fields','DocType',3,'content','Content',NULL,'Text Editor',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Help: To link to another record in the system, use \"#Form/Note/[Note Name]\" as the Link URL. (don\'t use \"http://\")',NULL,0,NULL,NULL,NULL),('c46e9e0574','2013-02-22 01:27:36.000000','2015-04-04 15:11:20.741323','Administrator','Administrator',0,'Workflow Document State','fields','DocType',4,'update_value','Update Value',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('c51702b229','2012-12-20 17:16:49.000000','2015-04-04 15:11:08.696742','Administrator','Administrator',0,'Page','fields','DocType',3,'title','Title',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('c547bffd6b','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',27,'birth_date','Birth Date','birth_date','Date','Date',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('c554f7e67e','2013-03-28 10:35:30.000000','2015-04-04 15:11:16.027377','Administrator','Administrator',0,'Blog Post','fields','DocType',10,'content','Content',NULL,'Text Editor',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('c587da3960','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',23,'in_filter','In Filter','in_filter','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'50px','50px',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('c5f7e493d8','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',8,'all_day','All Day',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('c62448e902','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',24,'background_style','Background Style',NULL,'Select',NULL,'Fill Screen\nTile',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('c6cbcf7498','2014-09-01 14:14:14.292173','2015-04-04 15:11:16.724128','Administrator','Administrator',0,'Web Form Field','fields','DocType',7,'column_break_4',NULL,NULL,'Column Break',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL),('c7067e7830','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',28,'auto_reply_message','Auto Reply Message',NULL,'Text Editor',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,'enable_auto_reply',0,0,NULL,NULL,NULL,NULL,0,0,NULL,0,''),('c787d0686e','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',17,'section_break_17',NULL,NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('c7b034d63c','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',3,'fieldtype','Type','fieldtype','Select','Select','Attach\nButton\nCheck\nCode\nColumn Break\nCurrency\nData\nDate\nDatetime\nDynamic Link\nFloat\nFold\nHTML\nImage\nInt\nLink\nLong Text\nPassword\nPercent\nRead Only\nSection Break\nSelect\nSmall Text\nTable\nText\nText Editor\nTime',1,0,NULL,0,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'Data',NULL,NULL,1,NULL,NULL,NULL),('c7d4405ba6','2014-07-11 17:18:09.923399','2015-04-04 15:11:22.628033','Administrator','Administrator',0,'Email Alert','fields','DocType',11,'html_7',NULL,NULL,'HTML',NULL,'<p><strong>Condition Examples:</strong></p>\n<pre>doc.status==\"Open\"\ndoc.due_date==nowdate()\ndoc.total > 40000\n</pre>\n<p><strong>Hints:</strong></p>\n<ol>\n<li>To check for an event every day, select \"Date Change\" in Event</li>\n<li>To send an alert if a particular value changes, select \"Value Change\"</li>\n</ol>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('c81fd572b1','2013-01-23 19:54:43.000000','2015-04-04 15:11:28.894125','Administrator','Administrator',0,'Print Format','fields','DocType',9,'html','HTML','html','Code','Text Editor','HTML',0,0,NULL,0,0,0,NULL,0,0,NULL,'custom_format',0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),('c872d5c1b6','2015-02-04 04:33:36.330477','2015-04-04 15:11:11.308875','Administrator','Administrator',0,'DocShare','fields','DocType',4,'read','Read',NULL,'Check',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,NULL,NULL,'0',NULL,0,0,NULL,0,''),('c88d8362eb','2012-08-08 10:40:11.000000','2015-04-04 15:11:14.076672','Administrator','Administrator',0,'Comment','fields','DocType',8,'comment_docname','Comment Docname','comment_docname','Data','Data',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('c952fc5248','2013-01-19 10:23:30.000000','2015-04-04 15:11:25.438587','Administrator','Administrator',0,'Country','fields','DocType',2,'date_format','Date Format',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('ca4388275e','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',1,'label_and_type','Label and Type',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('caa85ae049','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',5,'column_break_4',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('cab98ea606','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',23,'footer_items','Footer Items',NULL,'Table',NULL,'Top Bar Item',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('cac7d73095','2013-01-23 19:54:43.000000','2015-04-04 15:11:28.894125','Administrator','Administrator',0,'Print Format','fields','DocType',10,'print_format_help','Print Format Help',NULL,'HTML',NULL,'<h3>Print Format Help</h3>\n<hr>\n<h4>Introduction</h4>\n<p>Print itemsFormats are rendered on the server side using the Jinja Templating Language. All forms have access to the <code>doc</code> object which contains information about the document that is being formatted. You can also access common utilities via the <code>frappe</code> module.</p>\n<p>For styling, the Boostrap CSS framework is provided and you can enjoy the full range of classes.</p>\n<hr>\n<h4>References</h4>\n<ol>\n	<li><a href=\"http://jinja.pocoo.org/docs/templates/\" target=\"_blank\">Jinja Tempalting Language: Reference</a></li>\n	<li><a href=\"http://getbootstrap.com\" target=\"_blank\">Bootstrap CSS Framework</a></li>\n</ol>\n<hr>\n<h4>Example</h4>\n<pre><code>&lt;h3&gt;{{ doc.select_print_heading or \"Invoice\" }}&lt;/h3&gt;\n&lt;div class=\"row\"&gt;\n	&lt;div class=\"col-md-3 text-right\"&gt;Customer Name&lt;/div&gt;\n	&lt;div class=\"col-md-9\"&gt;{{ doc.customer_name }}&lt;/div&gt;\n&lt;/div&gt;\n&lt;div class=\"row\"&gt;\n	&lt;div class=\"col-md-3 text-right\"&gt;Date&lt;/div&gt;\n	&lt;div class=\"col-md-9\"&gt;{{ doc.get_formatted(\"invoice_date\") }}&lt;/div&gt;\n&lt;/div&gt;\n&lt;table class=\"table table-bordered\"&gt;\n	&lt;tbody&gt;\n		&lt;tr&gt;\n			&lt;th&gt;Sr&lt;/th&gt;\n			&lt;th&gt;Item Name&lt;/th&gt;\n			&lt;th&gt;Description&lt;/th&gt;\n			&lt;th class=\"text-right\"&gt;Qty&lt;/th&gt;\n			&lt;th class=\"text-right\"&gt;Rate&lt;/th&gt;\n			&lt;th class=\"text-right\"&gt;Amount&lt;/th&gt;\n		&lt;/tr&gt;\n		{%- for row in doc.items -%}\n		&lt;tr&gt;\n			&lt;td style=\"width: 3%;\"&gt;{{ row.idx }}&lt;/td&gt;\n			&lt;td style=\"width: 20%;\"&gt;\n				{{ row.item_name }}\n				{% if row.item_code != row.item_name -%}\n				&lt;br&gt;Item Code: {{ row.item_code}}\n				{%- endif %}\n			&lt;/td&gt;\n			&lt;td style=\"width: 37%;\"&gt;\n				&lt;div style=\"border: 0px;\"&gt;{{ row.description }}&lt;/div&gt;&lt;/td&gt;\n			&lt;td style=\"width: 10%; text-align: right;\"&gt;{{ row.qty }} {{ row.uom or row.stock_uom }}&lt;/td&gt;\n			&lt;td style=\"width: 15%; text-align: right;\"&gt;{{\n				row.get_formatted(\"rate\", doc) }}&lt;/td&gt;\n			&lt;td style=\"width: 15%; text-align: right;\"&gt;{{\n				row.get_formatted(\"amount\", doc) }}&lt;/td&gt;\n		&lt;/tr&gt;\n		{%- endfor -%}\n	&lt;/tbody&gt;\n&lt;/table&gt;</code></pre>\n<hr>\n<h4>Common Functions</h4>\n<table class=\"table table-bordered\">\n	<tbody>\n		<tr>\n			<td style=\"width: 30%\"><code>doc.get_formatted(\"[fieldname]\", [parent_doc])</code></td>\n			<td>Get document value formatted as Date, Currency etc. Pass parent <code>doc</code> for curreny type fields.</td>\n		</tr>\n		<tr>\n			<td style=\"width: 30%\"><code>frappe.db.get_value(\"[doctype]\", \"[name]\", \"fieldname\")</code></td>\n			<td>Get value from another document.</td>\n		</tr>\n	</tbody>\n</table>\n',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'custom_format',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('cb3383c932','2012-07-03 13:29:42.000000','2015-04-04 15:11:25.760244','Administrator','Administrator',0,'Feed','fields','DocType',4,'subject','Subject',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('cb87742be5','2015-02-04 04:33:36.330477','2015-04-04 15:11:11.308875','Administrator','Administrator',0,'DocShare','fields','DocType',5,'write','Write',NULL,'Check',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,NULL,NULL,'0',NULL,0,0,NULL,0,''),('cb9a1f4721','2014-09-01 14:14:14.292173','2015-04-04 15:11:16.724128','Administrator','Administrator',0,'Web Form Field','fields','DocType',2,'fieldtype','Fieldtype',NULL,'Select',NULL,'Attach\nCheck\nData\nDate\nDatetime\nHTML\nSelect\nText',0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,1,NULL,0,NULL),('cbe8957897','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','fields','DocType',6,'reference_doctype','Reference DocType',NULL,'Link',NULL,'DocType',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('cc22595120','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',24,'integrations','Integrations',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('cca5a79a62','2012-12-27 11:51:24.000000','2015-04-04 15:11:19.003214','Administrator','Administrator',0,'Website Script','fields','DocType',1,'javascript','Javascript',NULL,'Code',NULL,'Javascript',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('ccd7927ce2','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',27,'report_hide','Report Hide','report_hide','Check','Check',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('cce1a2a7da','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',24,'participants','Participants',NULL,'Section Break','Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('cce8142059','2013-01-28 10:06:02.000000','2015-04-04 15:11:25.128723','Administrator','Administrator',0,'Currency','fields','DocType',3,'fraction','Fraction',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Sub-currency. For e.g. \"Cent\"',NULL,1,NULL,NULL,NULL),('cd18f488e0','2012-12-28 10:49:55.000000','2015-04-04 15:11:21.053948','Administrator','Administrator',0,'Workflow','fields','DocType',8,'workflow_state_field','Workflow State Field',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'workflow_state','Field that represents the Workflow State of the transaction (if field is not present, a new hidden Custom Field will be created)',NULL,NULL,NULL,NULL,NULL),('cd5553733d','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',17,'top_bar_items','Top Bar Items',NULL,'Table',NULL,'Top Bar Item',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('cd70e97938','2012-08-02 15:17:28.000000','2015-04-04 15:11:22.003996','Administrator','Administrator',0,'Bulk Email','fields','DocType',7,'reference_name','Reference DocName',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL),('cd82e51bb4','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',26,'roles','Roles','event_roles','Table','Table','Event Role',0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('cde3dae387','2013-03-28 10:35:30.000000','2015-04-04 15:11:16.027377','Administrator','Administrator',0,'Blog Post','fields','DocType',11,'page_name','Page Name',NULL,'Data',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL),('ce37d1183b','2012-07-03 13:30:35.000000','2015-04-04 15:11:26.811873','Administrator','Administrator',0,'ToDo','fields','DocType',2,'description','Description','description','Text','Text',NULL,0,0,NULL,0,0,1,NULL,0,0,NULL,NULL,0,NULL,'300px','300px',NULL,NULL,0,0,NULL,NULL,NULL),('cfc55c8dfb','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',10,'fold_10',NULL,NULL,'Fold',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('d00abce337','2012-07-03 13:30:35.000000','2015-04-04 15:11:26.811873','Administrator','Administrator',0,'ToDo','fields','DocType',13,'assigned_by','Assigned By',NULL,'Link',NULL,'User',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d0de525654','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',21,'column_break_19',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d115bba47e','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',3,'home_page_is_products','Home Page is Products',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'If checked, the Home page will be the default Item Group for the website.',NULL,1,NULL,NULL,NULL),('d1da780354','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',23,'sb3',NULL,NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:!doc.istable',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d2af2cf141','2013-02-21 20:12:42.000000','2015-04-04 15:11:15.105507','Administrator','Administrator',0,'Contact Us Settings','fields','DocType',6,'address','Address',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d2bd88a30d','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','fields','DocType',9,'content','Content',NULL,'Text Editor',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,'400',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d2dd8a483c','2013-01-29 17:55:08.000000','2015-04-04 15:11:24.475702','Administrator','Administrator',0,'Customize Form','fields','DocType',4,'search_fields','Search Fields',NULL,'Data',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Fields separated by comma (,) will be included in the<br /><b>Search By</b> list of Search dialog box',NULL,1,NULL,NULL,NULL),('d2df5ccbc1','2013-01-28 10:06:02.000000','2015-04-04 15:11:25.128723','Administrator','Administrator',0,'Currency','fields','DocType',5,'symbol','Symbol',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'A symbol for this currency. For e.g. $',NULL,1,NULL,NULL,NULL),('d3231f0f99','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',24,'allow_on_submit','Allow on Submit','allow_on_submit','Check','Check',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d362968eaa','2012-08-02 15:17:28.000000','2015-04-04 15:11:22.003996','Administrator','Administrator',0,'Bulk Email','fields','DocType',6,'reference_doctype','Reference DocType',NULL,'Link',NULL,'DocType',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL),('d37c180e22','2012-11-22 17:45:46.000000','2015-04-04 15:11:28.541028','Administrator','Administrator',0,'Letter Head','fields','DocType',2,'disabled','Disabled','disabled','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'letter_head_name',0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('d506451b8d','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',22,'default_outgoing','Default Outgoing',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'enable_outgoing',0,NULL,NULL,NULL,NULL,'Notifications and bulk mails will be sent from this outgoing server.',NULL,NULL,NULL,NULL,''),('d54e5906fc','2014-09-01 14:08:48.624556','2015-04-04 15:11:18.596754','Administrator','Administrator',0,'Web Form','fields','DocType',16,'success_url','Success URL',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Go to this url after completing the form.',NULL,NULL,NULL,NULL,NULL),('d55f066bc0','2013-03-19 12:02:15.000000','2015-04-04 15:11:17.521595','Administrator','Administrator',0,'About Us Settings','fields','DocType',1,'help','Help',NULL,'HTML',NULL,'<div class=\"alert\">Link for About Us Page is \"/about\"</div>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),('d5af041278','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',3,'istable','Is Child Table','istable','Check','Check',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Child Tables are shown as a Grid in other DocTypes.',NULL,NULL,NULL,NULL,NULL),('d63a6341c5','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',19,'hidden','Hidden',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d651ecc3c5','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',26,'in_list_view','In List View',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d66c02d40f','2013-03-25 16:00:51.000000','2015-04-04 15:11:17.917763','Administrator','Administrator',0,'Blogger','fields','DocType',2,'short_name','Short Name',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Will be used in url (usually first name).',NULL,NULL,NULL,NULL,NULL),('d6dc88b50b','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',16,'tuesday','Tuesday',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:doc.repeat_this_event && doc.repeat_on===\"Every Day\"',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('d791ade664','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',17,'report','Report',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'32px','32px','1',NULL,NULL,NULL,NULL,NULL,NULL),('d847df20aa','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',3,'section_break_3',NULL,NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('d852f4c9a4','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',43,'restrict_ip','Restrict IP',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Restrict user from this IP address only. Multiple IP addresses can be added by separating with commas. Also accepts partial IP addresses like (111.111.111)',NULL,NULL,NULL,1,NULL),('d888bb537b','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',9,'main_section','Main Section',NULL,'Text Editor',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Content in markdown format that appears on the main side of your page',NULL,NULL,NULL,NULL,NULL),('d93bcce922','2013-02-21 20:12:42.000000','2015-04-04 15:11:15.105507','Administrator','Administrator',0,'Contact Us Settings','fields','DocType',2,'forward_to_email','Forward To Email Address',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Send enquiries to this email address',NULL,NULL,NULL,NULL,NULL),('d9b5e8c858','2013-01-10 16:34:04.000000','2015-04-04 15:11:07.697838','Administrator','Administrator',0,'Property Setter','fields','DocType',3,'doctype_or_field','DocType or Field',NULL,'Select',NULL,'\nDocField\nDocType',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'eval:doc.__islocal',0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('da20f40671','2014-04-17 16:53:52.640856','2015-04-04 15:11:13.078614','Administrator','Administrator',0,'System Settings','fields','DocType',5,'date_format','Date Format',NULL,'Select',NULL,'yyyy-mm-dd\ndd-mm-yyyy\ndd/mm/yyyy\ndd.mm.yyyy\nmm/dd/yyyy\nmm-dd-yyyy',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('db69359542','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',36,'allow_copy','Hide Copy','allow_copy','Check','Check',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('dbfbd609e3','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',3,'show_title','Show Title',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,''),('dc33cdcddb','2013-03-09 15:45:57.000000','2015-04-04 15:11:13.159277','Administrator','Administrator',0,'Report','fields','DocType',9,'apply_user_permissions','Apply User Permissions',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:[\"Query Report\", \"Script Report\"].indexOf(doc.report_type)!==-1',0,NULL,NULL,NULL,'1',NULL,NULL,0,NULL,NULL,NULL),('dce3504a18','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',5,'permlevel','Level','permlevel','Int','Int',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,'40px','40px','0',NULL,NULL,1,NULL,NULL,NULL),('dd5a5cce3d','2013-01-10 16:34:01.000000','2015-04-04 15:11:24.153999','Administrator','Administrator',0,'Custom Script','fields','DocType',2,'script_type','Script Type','script_type','Select','Select','Client',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'Client',NULL,NULL,1,NULL,1,NULL),('dd92a7d013','2013-03-28 10:35:30.000000','2015-04-04 15:11:16.027377','Administrator','Administrator',0,'Blog Post','fields','DocType',1,'title','Title',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('de093ba724','2013-01-19 10:23:30.000000','2015-04-04 15:11:25.438587','Administrator','Administrator',0,'Country','fields','DocType',1,'country_name','Country Name','country_name','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('de3dac3a3a','2013-02-21 20:12:42.000000','2015-04-04 15:11:15.105507','Administrator','Administrator',0,'Contact Us Settings','fields','DocType',3,'heading','Heading',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Default: \"Contact Us\"',NULL,NULL,NULL,NULL,NULL),('ded242b66d','2013-01-23 19:54:43.000000','2015-04-04 15:11:28.894125','Administrator','Administrator',0,'Print Format','fields','DocType',1,'doc_type','DocType',NULL,'Link',NULL,'DocType',0,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'',1,1,NULL,NULL,NULL),('e02c651171','2013-03-07 11:55:11.000000','2015-04-04 15:11:17.629439','Administrator','Administrator',0,'About Us Team Member','fields','DocType',3,'bio','Bio',NULL,'Small Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,'200px',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('e0850ac3c4','2013-03-09 15:45:57.000000','2015-04-04 15:11:13.159277','Administrator','Administrator',0,'Report','fields','DocType',12,'javascript','Javascript',NULL,'Code',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',0,NULL,NULL,NULL,NULL,'JavaScript Format: frappe.query_reports[\'REPORTNAME\'] = {}',NULL,NULL,NULL,NULL,NULL),('e09a55281a','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',23,'background_color','Background Color',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('e139af7425','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',5,'fieldtype','Field Type','fieldtype','Select','Select','Attach\nButton\nCheck\nCode\nColumn Break\nCurrency\nData\nDate\nDatetime\nDynamic Link\nFloat\nHTML\nImage\nInt\nLink\nLong Text\nPassword\nPercent\nRead Only\nSection Break\nSelect\nSmall Text\nTable\nText\nText Editor\nTime',0,NULL,NULL,NULL,NULL,1,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,'Data',NULL,1,1,NULL,NULL,NULL),('e15ef9d84a','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',28,'js','JavaScript',NULL,'Code',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('e1727ed229','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',42,'login_before','Login Before',NULL,'Int',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Allow user to login only before this hour (0-24)',NULL,NULL,NULL,1,NULL),('e17fff4cd1','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',29,'column_break_22',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('e25a96f332','2014-09-01 14:08:48.624556','2015-04-04 15:11:18.596754','Administrator','Administrator',0,'Web Form','fields','DocType',2,'page_name','Page Name',NULL,'Data',NULL,NULL,0,0,0,0,0,1,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,'Website URL',0,0,NULL,0,NULL),('e2d5b334de','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',9,'write','Write','write','Check','Check',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,'32px','32px','1',NULL,NULL,1,NULL,NULL,NULL),('e2ebcb9734','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',11,'delete','Delete',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'1',NULL,NULL,1,NULL,NULL,NULL),('e3178c899d','2015-02-04 04:33:36.330477','2015-04-04 15:11:11.308875','Administrator','Administrator',0,'DocShare','fields','DocType',2,'share_doctype','Document Type',NULL,'Link',NULL,'DocType',1,0,0,0,0,1,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,1,NULL,0,''),('e33e46e000','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',35,'modules_html','Modules HTML',NULL,'HTML',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('e3bff893e2','2012-07-09 11:17:17.000000','2015-04-04 15:11:09.058572','Administrator','Administrator',0,'Tag','fields','DocType',1,'tag_name','Tag Name','tag_name','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('e3c03cc501','2012-08-02 15:17:28.000000','2015-04-04 15:11:22.003996','Administrator','Administrator',0,'Bulk Email','fields','DocType',3,'message','Message',NULL,'Code',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL),('e3fcbd2efb','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',20,'default','Default','default','Text','Text',NULL,0,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('e40d4b22d1','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',44,'column_break1',NULL,NULL,'Column Break','Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,'50%','50%',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('e425f1979b','2013-01-28 10:06:02.000000','2015-04-04 15:11:25.128723','Administrator','Administrator',0,'Currency','fields','DocType',1,'currency_name','Currency Name','currency_name','Data','Data',NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('e4c7c75e8f','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',3,'apply_user_permissions','Apply User Permissions',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Filter records based on User Permissions defined for a user',NULL,NULL,NULL,NULL,NULL),('e4fcd12b74','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',20,'thread_notify','Send Notifications for Transactions I Follow',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'1',NULL,NULL,NULL,NULL,NULL,''),('e61075eda3','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',12,'depends_on','Depends On','depends_on','Data','Data',NULL,NULL,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'This field will appear only if the fieldname defined here has value OR the rules are true (examples): <br>\nmyfield\neval:doc.myfield==\'My Value\'<br>\neval:doc.age>18',NULL,NULL,NULL,NULL,NULL),('e71d2e2920','2013-02-21 20:12:42.000000','2015-04-04 15:11:15.105507','Administrator','Administrator',0,'Contact Us Settings','fields','DocType',10,'city','City',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('e77c8196fb','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',26,'width','Width','width','Data','Data',NULL,0,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,'50px','50px',NULL,NULL,NULL,1,NULL,NULL,NULL),('e7b4027215','2013-03-09 15:45:57.000000','2015-04-04 15:11:13.159277','Administrator','Administrator',0,'Report','fields','DocType',8,'disabled','Disabled',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),('e7f737eab8','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','fields','DocType',21,'communication_date','Date',NULL,'Datetime',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'Today',NULL,NULL,NULL,NULL,NULL,NULL),('e8127af036','2013-03-11 17:48:16.000000','2015-04-04 15:11:17.486352','Administrator','Administrator',0,'Blog Settings','fields','DocType',2,'blog_introduction','Blog Introduction',NULL,'Small Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('e860185448','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',4,'cb4',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('e86c3d1c51','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',1,'sb0','Landing Page',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('e9d52b45ca','2014-07-17 06:54:20.782907','2015-04-04 15:11:29.372802','Administrator','Administrator',0,'Print Settings','fields','DocType',5,'print_style','Print Style',NULL,'Select',NULL,'Modern\nClassic\nStandard\nMonochrome',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'Modern',NULL,NULL,1,NULL,NULL,NULL),('ea286aaf46','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',10,'fieldname','Fieldname','fieldname','Data','Data',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,1,NULL),('ea3abca8cf','2012-08-08 10:40:11.000000','2015-04-04 15:11:14.076672','Administrator','Administrator',0,'Comment','fields','DocType',5,'comment_date','Comment Date','comment_date','Date','Date',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('ea3b3e1625','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',15,'monday','Monday',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:doc.repeat_this_event && doc.repeat_on===\"Every Day\"',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('ea80bad50b','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',2,'title','Title',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Title / headline of your page',NULL,NULL,NULL,NULL,NULL),('eb63ba364c','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',4,'slideshow','Slideshow',NULL,'Link',NULL,'Website Slideshow',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Begin this page with a slideshow of images',NULL,NULL,NULL,NULL,NULL),('ebb34af8cd','2013-03-28 10:35:30.000000','2015-04-04 15:11:16.027377','Administrator','Administrator',0,'Blog Post','fields','DocType',7,'parent_website_route','Parent Website Route',NULL,'Read Only',NULL,'',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL),('ebe7982f9a','2013-01-10 16:34:04.000000','2015-04-04 15:11:07.697838','Administrator','Administrator',0,'Property Setter','fields','DocType',10,'default_value','Default Value',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('ebec46a6cf','2013-03-19 12:02:15.000000','2015-04-04 15:11:17.521595','Administrator','Administrator',0,'About Us Settings','fields','DocType',2,'company_introduction','Company Introduction',NULL,'Text Editor',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Introduce your company to the website visitor.',NULL,1,NULL,0,NULL),('ebfea58968','2014-03-04 08:29:52.000000','2015-04-04 15:11:15.926427','Administrator','Administrator',0,'Social Login Keys','fields','DocType',7,'github','GitHub',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('ec09d5d772','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',21,'footer_text_color','Footer Text Color',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('ec2113f08c','2014-03-04 08:29:52.000000','2015-04-04 15:11:15.926427','Administrator','Administrator',0,'Social Login Keys','fields','DocType',3,'facebook_client_secret','Facebook Client Secret',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('ec29425020','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.960468','Administrator','Administrator',0,'DocPerm','fields','DocType',7,'section_break_4','Permissions',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('ecabda686f','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',24,'template_path','Template Path',NULL,'Data',NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL),('edd1d09c83','2013-05-24 13:41:00.000000','2015-04-04 15:11:27.356000','Administrator','Administrator',0,'Note','fields','DocType',2,'public','Public',NULL,'Check',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Everyone can read',NULL,0,NULL,NULL,NULL),('ee3a522cc3','2013-02-22 01:27:32.000000','2015-04-04 15:11:24.546380','Administrator','Administrator',0,'Customize Form Field','fields','DocType',5,'reqd','Mandatory','reqd','Check','Check',NULL,0,0,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,'50px','50px',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('ee6e8e8349','2014-03-04 08:29:52.000000','2015-04-04 15:11:15.926427','Administrator','Administrator',0,'Social Login Keys','fields','DocType',5,'google_client_id','Google Client ID',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('ee91d176f4','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',2,'enabled','Enabled','enabled','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,'1',NULL,NULL,0,NULL,1,NULL),('eea504f643','2013-01-10 16:34:04.000000','2015-04-04 15:11:07.697838','Administrator','Administrator',0,'Property Setter','fields','DocType',2,'sb0',NULL,NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('ef356bb0b5','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',38,'defaults','User Defaults',NULL,'Table',NULL,'DefaultValue',NULL,1,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Enter default value fields (keys) and values. If you add multiple values for a field, the first one will be picked. These defaults are also used to set \"match\" permission rules. To see list of fields, go to <a href=\"#Form/Customize Form/Customize Form\">Customize Form</a>.',NULL,NULL,NULL,NULL,NULL),('ef7bd8672f','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',21,'email_signature','Email Signature',NULL,'Small Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('efc8c75a4e','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',27,'header','Header',NULL,'Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'HTML for header section. Optional',NULL,NULL,NULL,NULL,NULL),('efcffe918b','2012-08-02 15:17:28.000000','2015-04-04 15:11:22.003996','Administrator','Administrator',0,'Bulk Email','fields','DocType',2,'recipient','Recipient',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('efe47ee0bd','2013-01-23 19:54:43.000000','2015-04-04 15:11:28.894125','Administrator','Administrator',0,'Print Format','fields','DocType',4,'standard','Standard','standard','Select','Select','No\nYes',1,0,NULL,0,0,1,NULL,1,0,NULL,NULL,0,NULL,NULL,NULL,'No',NULL,1,0,NULL,0,NULL),('f077cf27d0','2013-03-07 15:53:15.000000','2015-04-04 15:11:15.250035','Administrator','Administrator',0,'Website Slideshow','fields','DocType',3,'slideshow_items','Slideshow Items',NULL,'Table',NULL,'Website Slideshow Item',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'eval:!doc.__islocal',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('f09d3403ec','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',15,'insert_style','Insert Style',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('f0a9d3b82d','2012-07-03 13:30:35.000000','2015-04-04 15:11:26.811873','Administrator','Administrator',0,'ToDo','fields','DocType',12,'role','Role','role','Link','Link','Role',0,0,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL),('f0b7b2a657','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',8,'options','Options','options','Text','Text',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('f0e66e4e71','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','fields','DocType',22,'_user_tags','User Tags',NULL,'Data',NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('f18528b998','2013-01-29 17:55:08.000000','2015-04-04 15:11:24.475702','Administrator','Administrator',0,'Customize Form','fields','DocType',3,'default_print_format','Default Print Format',NULL,'Link',NULL,'Print Format',0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('f1a02f8eaf','2012-07-03 13:30:35.000000','2015-04-04 15:11:26.811873','Administrator','Administrator',0,'ToDo','fields','DocType',6,'date','Due Date','date','Date','Date',NULL,0,0,NULL,0,0,0,NULL,0,0,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL),('f1c17fa411','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',12,'sb1','Naming',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('f2034354d2','2013-01-10 16:34:04.000000','2015-04-04 15:11:07.697838','Administrator','Administrator',0,'Property Setter','fields','DocType',5,'column_break0',NULL,NULL,'Column Break',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('f3179c45e7','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',13,'column_break_14',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('f39fa9fffa','2013-02-22 01:27:33.000000','2015-04-04 15:11:05.759412','Administrator','Administrator',0,'DocField','fields','DocType',4,'fieldname','Name','fieldname','Data','Data',NULL,1,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('f3b7993d0f','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',30,'in_dialog','In Dialog','in_dialog','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('f3d2d38d4d','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',48,'third_party_authentication','Third Party Authentication',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('f3fc3f4e91','2012-07-03 13:30:35.000000','2015-04-04 15:11:26.811873','Administrator','Administrator',0,'ToDo','fields','DocType',3,'column_break_2',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('f42c7f6bc1','2013-01-10 16:34:01.000000','2015-04-04 15:11:24.153999','Administrator','Administrator',0,'Custom Script','fields','DocType',4,'sample','Sample',NULL,'HTML',NULL,'<h3>Custom Script Help</h3>\n<p>Custom Scripts are executed only on the client-side (i.e. in Forms). Here are some examples to get you started</p>\n<pre><code>\n// additional validation on dates\ncur_frm.cscript.custom_validate = function(doc) {\n    if (doc.from_date < get_today()) {\n        msgprint(\"You can not select past date in From Date\");\n        validated = false;\n    }\n}\n\n// make a field read-only after saving\ncur_frm.cscript.custom_refresh = function(doc) {\n    // use the __islocal value of doc, to check if the doc is saved or not\n    cur_frm.set_df_property(\"myfield\", \"read_only\", doc.__islocal ? 0 : 1);\n}\n\n// addtional permission checking\ncur_frm.cscript.custom_validate = function(doc) {\n    if(user==\"user1@example.com\" && doc.purpose!=\"Material Receipt\") {\n        msgprint(\"You are only allowed Material Receipt\");\n        validated = false;\n    }\n}\n\n// calculate sales incentive\ncur_frm.cscript.custom_validate = function(doc) {\n    // calculate incentives for each person on the deal\n    total_incentive = 0\n    $.each(doc.sales_team), function(i, d) {\n\n        // calculate incentive\n        var incentive_percent = 2;\n        if(doc.base_grand_total &gt; 400) incentive_percent = 4;\n\n        // actual incentive\n        d.incentives = flt(doc.base_grand_total) * incentive_percent / 100;\n        total_incentive += flt(d.incentives)\n    });\n\n    doc.total_incentive = total_incentive;\n}\n</code>\n</pre>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('f4a3c3e7c8','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','fields','DocType',27,'ref_type','Ref Type','ref_type','Link','Data','DocType',0,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),('f4a532dc56','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',30,'twitter_share','Twitter Share',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('f50c5f2fd1','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',7,'published','Published',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('f54fbe6b71','2013-01-10 16:34:04.000000','2015-04-04 15:11:07.697838','Administrator','Administrator',0,'Property Setter','fields','DocType',1,'help','Help',NULL,'HTML',NULL,'<div class=\"alert\">Please don\'t update it as it can mess up your form. Use the Customize Form View and Custom Fields to set properties!</div>',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('f55b7b0e9a','2013-03-25 16:00:51.000000','2015-04-04 15:11:17.917763','Administrator','Administrator',0,'Blogger','fields','DocType',4,'user','User',NULL,'Link',NULL,'User',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('f5974a11a8','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',22,'print_width','Print Width',NULL,'Data',NULL,NULL,NULL,1,NULL,1,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('f5a9ce676b','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','fields','DocType',4,'subject','Subject',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL),('f5cf1f68de','2013-03-28 10:35:30.000000','2015-04-04 15:11:16.027377','Administrator','Administrator',0,'Blog Post','fields','DocType',12,'email_sent','Email Sent',NULL,'Check',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('f5e40168ec','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',31,'read_only_onload','Show Print First','read_only_onload','Check','Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('f77c376e7d','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','fields','DocType',8,'section_break_8',NULL,NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('f7aac71cc1','2014-09-01 14:14:14.292173','2015-04-04 15:11:16.724128','Administrator','Administrator',0,'Web Form Field','fields','DocType',6,'hidden','Hidden',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('f80d38c990','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',47,'last_known_versions','Last Known Versions',NULL,'Text',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Stores the JSON of last known versions of various installed apps. It is used to show release notes.',NULL,NULL,NULL,1,''),('f82f2ec1e8','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',35,'hide_toolbar','Hide Toolbar','hide_toolbar','Check','Check',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('f84668ea58','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',17,'top_bar_text_color','Top Bar Text Color',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('f908a6b4d1','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',15,'unreplied_for_mins','Notify if unreplied for (in mins)',NULL,'Int',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'notify_if_unreplied',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('f964e0a17f','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','fields','DocType',20,'depends_on','Depends On',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('fa0677cb2d','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',36,'disable_signup','Disable Signup',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Disable Customer Signup link in Login page',NULL,NULL,NULL,NULL,NULL),('fa6f311a69','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',26,'auto_reply','',NULL,'Section Break',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,NULL,0,''),('fa86cca7a0','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',25,'background_image','Background Image',NULL,'Attach Image',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'If image is selected, color will be ignored.',NULL,NULL,NULL,NULL,''),('fad11095c6','2012-12-20 17:16:49.000000','2015-04-04 15:11:08.696742','Administrator','Administrator',0,'Page','fields','DocType',5,'column_break0',NULL,NULL,'Column Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('fad2e870ed','2014-09-01 14:14:14.292173','2015-04-04 15:11:16.724128','Administrator','Administrator',0,'Web Form Field','fields','DocType',5,'read_only','Read Only',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('fb19cce2fc','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','fields','DocType',53,'github_userid','Github User ID',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL),('fc019b45d1','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','fields','DocType',18,'enable_outgoing','Enable Outgoing',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,'','SMTP Settings for outgoing emails',NULL,NULL,NULL,NULL,''),('fcb21cb189','2014-09-01 14:14:14.292173','2015-04-04 15:11:16.724128','Administrator','Administrator',0,'Web Form Field','fields','DocType',12,'default','Default',NULL,'Data',NULL,NULL,0,0,0,0,0,0,NULL,0,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,0,0,NULL,0,NULL),('fcb8ed5161','2013-02-22 01:27:36.000000','2015-04-04 15:11:20.741323','Administrator','Administrator',0,'Workflow Document State','fields','DocType',6,'message','Message',NULL,'Text',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,'160px','160px',NULL,NULL,NULL,1,NULL,NULL,NULL),('fd29014e6a','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',15,'section_break_8',NULL,NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'apply_style',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('fd61f4768f','2013-03-25 16:00:51.000000','2015-04-04 15:11:17.917763','Administrator','Administrator',0,'Blogger','fields','DocType',3,'full_name','Full Name',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('fd88f390a7','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',22,'permissions','Permissions','permissions','Table','Table','DocPerm',0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('fddc6b3f62','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',28,'facebook_share','Facebook Share',NULL,'Check',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('fe46755d35','2014-07-11 17:18:09.923399','2015-04-04 15:11:22.628033','Administrator','Administrator',0,'Email Alert','fields','DocType',18,'view_properties','View Properties (via Customize Form)',NULL,'Button',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('fe58270321','2013-02-21 20:12:42.000000','2015-04-04 15:11:15.105507','Administrator','Administrator',0,'Contact Us Settings','fields','DocType',12,'pincode','Pincode',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('fe92c34470','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','fields','DocType',14,'custom_css','Custom CSS',NULL,'Section Break',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('feb014d824','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','fields','DocType',5,'title_prefix','Title Prefix',NULL,'Data',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Show title in browser window as \"Prefix - title\"',NULL,1,NULL,NULL,NULL),('ff0701246e','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','fields','DocType',14,'heading_style','Heading Style',NULL,'Select',NULL,'\nUPPERCASE\nTitle Case\nlowercase',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,''),('ff3705a1b1','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',9,'plugin','Plugin',NULL,'Data',NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL),('ff6c6b35a8','2012-08-08 10:40:11.000000','2015-04-04 15:11:14.076672','Administrator','Administrator',0,'Comment','fields','DocType',4,'comment_by_fullname','Comment By Fullname','comment_by_fullname','Data','Data',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL),('ff91706894','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','fields','DocType',4,'issingle','Is Single','issingle','Check','Check',NULL,0,0,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,'Single Types have only one record no tables associated. Values are stored in tabSingles',NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tabDocField` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDocPerm`
--

DROP TABLE IF EXISTS `tabDocPerm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDocPerm` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `permlevel` int(11) DEFAULT '0',
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `match` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `read` int(1) DEFAULT '1',
  `write` int(1) DEFAULT '1',
  `create` int(1) DEFAULT '1',
  `submit` int(1) DEFAULT NULL,
  `cancel` int(1) DEFAULT NULL,
  `delete` int(1) DEFAULT '1',
  `amend` int(1) DEFAULT NULL,
  `report` int(1) DEFAULT '1',
  `export` int(1) DEFAULT '1',
  `import` int(1) DEFAULT NULL,
  `share` int(1) DEFAULT '1',
  `print` int(1) DEFAULT '1',
  `email` int(1) DEFAULT '1',
  `restrict` int(1) DEFAULT NULL,
  `user_permission_doctypes` text COLLATE utf8mb4_unicode_ci,
  `set_user_permissions` int(1) DEFAULT NULL,
  `apply_user_permissions` int(1) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDocPerm`
--

LOCK TABLES `tabDocPerm` WRITE;
/*!40000 ALTER TABLE `tabDocPerm` DISABLE KEYS */;
INSERT INTO `tabDocPerm` VALUES ('016b6e0e76','2013-03-28 10:35:30.000000','2015-04-04 15:11:16.027377','Administrator','Administrator',0,'Blog Post','permissions','DocType',2,0,'Blogger',NULL,1,1,1,0,NULL,0,NULL,1,NULL,NULL,1,1,1,NULL,NULL,NULL,1),('0464a4f273','2013-03-08 09:41:11.000000','2015-04-04 15:11:15.582389','Administrator','Administrator',0,'Blog Category','permissions','DocType',1,0,'Website Manager',NULL,1,1,1,NULL,NULL,1,NULL,1,NULL,NULL,1,1,1,NULL,NULL,1,NULL),('05f1682811','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','permissions','DocType',2,0,'Guest',NULL,1,0,0,NULL,NULL,0,NULL,0,0,NULL,0,0,0,NULL,NULL,NULL,NULL),('0b4be9eff5','2013-03-09 15:45:57.000000','2015-04-04 15:11:13.159277','Administrator','Administrator',0,'Report','permissions','DocType',1,0,'Administrator',NULL,1,1,1,0,NULL,1,NULL,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('0bae3586ab','2013-01-29 17:55:08.000000','2015-04-04 15:11:24.475702','Administrator','Administrator',0,'Customize Form','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,NULL,NULL,NULL,0,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('1a897e525f','2014-02-20 17:22:37.000000','2015-04-04 15:11:12.769699','Administrator','Administrator',0,'Version','permissions','DocType',1,0,'System Manager',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('20691a13b5','2014-06-19 05:20:26.331041','2015-04-04 15:11:22.313767','Administrator','Administrator',0,'Standard Reply','permissions','DocType',1,0,'All',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('243345b89e','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,NULL,1,NULL,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('250dce1707','2014-07-17 06:54:20.782907','2015-04-04 15:11:29.372802','Administrator','Administrator',0,'Print Settings','permissions','DocType',1,0,'System Manager',NULL,1,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL),('26997ccd03','2013-01-17 11:36:45.000000','2015-04-04 15:11:12.426216','Administrator','Administrator',0,'Patch Log','permissions','DocType',1,0,'Administrator',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,1,1,NULL,NULL,NULL,NULL),('2a23cda88c','2013-03-25 16:00:51.000000','2015-04-04 15:11:17.917763','Administrator','Administrator',0,'Blogger','permissions','DocType',1,0,'Website Manager',NULL,1,1,1,NULL,NULL,1,NULL,1,1,1,1,1,1,NULL,NULL,1,NULL),('2d79f0f6dd','2013-01-16 13:09:40.000000','2015-04-04 15:11:14.607024','Administrator','Administrator',0,'Scheduler Log','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,0,1,NULL,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('2d7e6267ba','2012-08-08 10:40:11.000000','2015-04-04 15:11:14.076672','Administrator','Administrator',0,'Comment','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,0,1,NULL,1,1,1,1,1,1,NULL,NULL,NULL,NULL),('2fa51b8059','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','permissions','DocType',2,0,'Sales Manager',NULL,1,1,1,0,NULL,1,0,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('3027936521','2013-01-28 10:06:02.000000','2015-04-04 15:11:25.128723','Administrator','Administrator',0,'Currency','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,NULL,1,0,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('33430d673e','2015-03-18 09:41:20.216319','2015-04-04 15:11:23.842816','Administrator','Administrator',0,'Email Unsubscribe','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,0,1,0,1,1,0,1,1,1,NULL,NULL,0,0),('33518fa353','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,0,0,NULL,1,NULL,NULL,NULL,1,1,NULL,NULL,NULL,NULL),('33f7018175','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','permissions','DocType',1,0,'Website Manager',NULL,1,1,1,0,0,0,NULL,0,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('372c9e381d','2013-01-10 16:34:03.000000','2015-04-04 15:11:10.200963','Administrator','Administrator',0,'Module Def','permissions','DocType',2,0,'System Manager',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('37a7f67c27','2013-03-08 09:41:11.000000','2015-04-04 15:11:15.582389','Administrator','Administrator',0,'Blog Category','permissions','DocType',2,0,'Blogger',NULL,1,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,1,1,NULL,NULL,NULL,1),('37de5f8aeb','2015-02-04 04:33:36.330477','2015-04-04 15:11:11.308875','Administrator','Administrator',0,'DocShare','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,0,1,0,1,1,1,1,0,0,NULL,NULL,0,0),('37dffc7832','2012-07-09 11:17:17.000000','2015-04-04 15:11:09.058572','Administrator','Administrator',0,'Tag','permissions','DocType',1,0,'System Manager',NULL,1,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('3aff139aa2','2013-04-30 12:58:46.000000','2015-04-04 15:11:15.176823','Administrator','Administrator',0,'Website Settings','permissions','DocType',2,1,'All',NULL,1,NULL,0,0,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('3b28fb1a68','2013-01-23 19:54:43.000000','2015-04-04 15:11:28.894125','Administrator','Administrator',0,'Print Format','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,0,1,0,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('3d3de66f60','2013-03-28 10:35:30.000000','2015-04-04 15:11:17.056177','Administrator','Administrator',0,'Web Page','permissions','DocType',1,0,'Website Manager',NULL,1,1,1,0,0,1,NULL,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('3f4233bd79','2013-01-19 10:23:30.000000','2015-04-04 15:11:25.438587','Administrator','Administrator',0,'Country','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,NULL,NULL,0,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('46bacfb398','2013-01-10 16:34:04.000000','2015-04-04 15:11:07.697838','Administrator','Administrator',0,'Property Setter','permissions','DocType',2,0,'System Manager',NULL,1,1,1,0,0,1,NULL,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('4920f2c214','2013-02-21 20:12:42.000000','2015-04-04 15:11:15.105507','Administrator','Administrator',0,'Contact Us Settings','permissions','DocType',1,0,'Website Manager',NULL,1,1,1,0,NULL,NULL,NULL,0,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('4b6f827358','2013-01-10 16:34:04.000000','2015-04-04 15:11:07.697838','Administrator','Administrator',0,'Property Setter','permissions','DocType',1,0,'Administrator',NULL,1,1,1,0,0,1,NULL,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('4ed993e186','2012-07-03 13:29:42.000000','2015-04-04 15:11:25.760244','Administrator','Administrator',0,'Feed','permissions','DocType',1,0,'System Manager',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,1,1,NULL,NULL,NULL,NULL),('61bbc14a5e','2012-11-22 17:45:46.000000','2015-04-04 15:11:28.541028','Administrator','Administrator',0,'Letter Head','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,NULL,1,NULL,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('6674b3c63b','2012-07-03 13:30:35.000000','2015-04-04 15:11:26.811873','Administrator','Administrator',0,'ToDo','permissions','DocType',2,0,'System Manager',NULL,1,1,1,NULL,NULL,0,NULL,1,1,NULL,1,1,1,NULL,NULL,NULL,NULL),('770e081230','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','permissions','DocType',4,0,'System Manager',NULL,1,1,1,0,NULL,1,NULL,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('77d726ef56','2013-03-07 15:53:15.000000','2015-04-04 15:11:15.250035','Administrator','Administrator',0,'Website Slideshow','permissions','DocType',1,0,'Website Manager',NULL,1,1,1,0,0,1,NULL,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('796f2c5a55','2013-01-10 16:34:01.000000','2015-04-04 15:11:24.153999','Administrator','Administrator',0,'Custom Script','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,0,1,NULL,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('7ec1fdfcec','2013-01-19 10:23:30.000000','2015-04-04 15:11:25.438587','Administrator','Administrator',0,'Country','permissions','DocType',2,0,'All',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,1,1,NULL,NULL,NULL,1),('7f81c28716','2013-03-19 12:02:15.000000','2015-04-04 15:11:17.521595','Administrator','Administrator',0,'About Us Settings','permissions','DocType',1,0,'Website Manager',NULL,1,1,1,0,NULL,NULL,NULL,0,NULL,NULL,1,1,1,NULL,NULL,NULL,0),('8364c0295e','2014-09-11 12:04:34.163728','2015-04-04 15:11:23.360670','Administrator','Administrator',0,'Email Account','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,0,1,0,0,0,0,1,0,0,NULL,NULL,1,0),('854cc3a472','2012-12-28 10:49:56.000000','2015-04-04 15:11:20.373529','Administrator','Administrator',0,'Workflow Action','permissions','DocType',1,0,'System Manager',NULL,1,1,1,NULL,0,1,NULL,NULL,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('88317b9c34','2013-01-08 15:50:01.000000','2015-04-04 15:11:06.866524','Administrator','Administrator',0,'Role','permissions','DocType',2,0,'Administrator',NULL,1,1,1,0,NULL,1,NULL,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('89c9015029','2013-01-08 15:50:01.000000','2015-04-04 15:11:06.866524','Administrator','Administrator',0,'Role','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,NULL,NULL,0,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('8c9703c130','2013-03-09 15:45:57.000000','2015-04-04 15:11:13.159277','Administrator','Administrator',0,'Report','permissions','DocType',4,0,'All',NULL,1,NULL,NULL,0,NULL,0,NULL,1,NULL,NULL,NULL,1,1,NULL,NULL,NULL,1),('8e358f0a87','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','permissions','DocType',3,0,'Administrator',NULL,1,1,1,0,0,1,0,0,1,1,0,0,0,NULL,NULL,0,0),('98f6b0e49e','2012-11-22 17:45:46.000000','2015-04-04 15:11:28.541028','Administrator','Administrator',0,'Letter Head','permissions','DocType',2,0,'All',NULL,1,NULL,NULL,NULL,NULL,0,NULL,0,NULL,NULL,NULL,0,0,NULL,NULL,NULL,1),('990ba8d921','2013-03-25 16:00:51.000000','2015-04-04 15:11:17.917763','Administrator','Administrator',0,'Blogger','permissions','DocType',2,0,'Blogger',NULL,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,1,NULL,NULL,NULL,1),('9bd0730c0e','2014-04-17 16:53:52.640856','2015-04-04 15:11:13.078614','Administrator','Administrator',0,'System Settings','permissions','DocType',1,0,'System Manager',NULL,1,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL),('9c7fdaa9ee','2013-03-09 15:45:57.000000','2015-04-04 15:11:13.159277','Administrator','Administrator',0,'Report','permissions','DocType',3,0,'Report Manager',NULL,1,1,1,0,NULL,1,NULL,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('9da3e8170b','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','permissions','DocType',2,0,'System Manager',NULL,1,1,1,0,0,1,NULL,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('a41465363b','2012-12-20 17:16:49.000000','2015-04-04 15:11:08.696742','Administrator','Administrator',0,'Page','permissions','DocType',1,0,'Administrator',NULL,1,1,1,0,NULL,NULL,NULL,NULL,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('a67cb4741b','2013-03-28 10:35:30.000000','2015-04-04 15:11:16.027377','Administrator','Administrator',0,'Blog Post','permissions','DocType',3,0,'Guest',NULL,1,0,NULL,0,NULL,0,NULL,1,NULL,NULL,NULL,1,1,NULL,NULL,NULL,NULL),('aa98d43d28','2012-12-28 10:49:55.000000','2015-04-04 15:11:21.053948','Administrator','Administrator',0,'Workflow','permissions','DocType',1,0,'System Manager',NULL,1,1,1,0,0,1,NULL,NULL,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('ab6f9e300e','2014-06-19 05:20:26.331041','2015-04-04 15:11:22.313767','Administrator','Administrator',0,'Standard Reply','permissions','DocType',2,0,'All',NULL,1,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,1),('abe981fca5','2013-03-09 15:45:57.000000','2015-04-04 15:11:13.159277','Administrator','Administrator',0,'Report','permissions','DocType',2,0,'System Manager',NULL,1,1,1,0,NULL,1,NULL,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('acae383179','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','permissions','DocType',2,0,'System Manager',NULL,1,1,1,0,NULL,1,NULL,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('b61dfa0625','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','permissions','DocType',2,0,'Website Manager',NULL,1,1,1,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('b6b0d54ada','2013-01-08 15:50:01.000000','2015-04-04 15:11:06.866524','Administrator','Administrator',0,'Role','permissions','DocType',3,0,'All',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),('bbdfdbb7f2','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','permissions','DocType',3,0,'Sales User',NULL,1,1,1,0,NULL,1,0,1,NULL,NULL,1,1,1,NULL,NULL,NULL,1),('c16ee6d408','2013-01-28 10:06:02.000000','2015-04-04 15:11:25.128723','Administrator','Administrator',0,'Currency','permissions','DocType',2,0,'All',NULL,1,NULL,NULL,NULL,NULL,0,NULL,1,NULL,NULL,NULL,1,1,NULL,NULL,NULL,1),('c53a4357b6','2012-12-27 11:51:24.000000','2015-04-04 15:11:19.003214','Administrator','Administrator',0,'Website Script','permissions','DocType',1,0,'Website Manager',NULL,1,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('c7fca93503','2014-09-01 14:08:48.624556','2015-04-04 15:11:18.596754','Administrator','Administrator',0,'Web Form','permissions','DocType',1,0,'Website Manager',NULL,1,1,1,0,0,1,0,1,0,0,1,0,0,NULL,NULL,0,0),('c9709204d3','2012-07-03 13:29:42.000000','2015-04-04 15:11:25.760244','Administrator','Administrator',0,'Feed','permissions','DocType',2,0,'All',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),('ca5c67c9ce','2013-03-28 10:35:30.000000','2015-04-04 15:11:16.027377','Administrator','Administrator',0,'Blog Post','permissions','DocType',1,0,'Website Manager',NULL,1,1,1,0,NULL,1,NULL,1,NULL,NULL,1,1,1,NULL,NULL,1,NULL),('d21db7ad78','2014-06-19 05:20:26.331041','2015-04-04 15:11:22.313767','Administrator','Administrator',0,'Standard Reply','permissions','DocType',3,0,'System Manager',NULL,1,1,1,NULL,NULL,1,NULL,1,1,1,1,NULL,1,NULL,NULL,NULL,NULL),('d51d1343d1','2012-08-02 15:17:28.000000','2015-04-04 15:11:22.003996','Administrator','Administrator',0,'Bulk Email','permissions','DocType',1,0,'System Manager',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,1,1,NULL,NULL,NULL,NULL),('da2371aa49','2012-12-20 17:16:49.000000','2015-04-04 15:11:08.696742','Administrator','Administrator',0,'Page','permissions','DocType',3,0,'All',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,NULL,NULL,NULL,1),('de6c20f0ea','2013-05-24 13:41:00.000000','2015-04-04 15:11:27.356000','Administrator','Administrator',0,'Note','permissions','DocType',1,0,'All',NULL,1,1,1,NULL,NULL,1,NULL,NULL,NULL,NULL,1,1,1,NULL,NULL,NULL,1),('df798a3949','2012-12-20 17:16:49.000000','2015-04-04 15:11:08.696742','Administrator','Administrator',0,'Page','permissions','DocType',2,0,'System Manager',NULL,1,1,0,0,0,0,0,0,0,0,1,1,1,NULL,NULL,0,0),('e2964fc6da','2013-06-10 13:17:47.000000','2015-04-04 15:11:26.274554','Administrator','Administrator',0,'Event','permissions','DocType',1,0,'All',NULL,1,1,1,0,NULL,0,NULL,1,NULL,NULL,1,1,1,NULL,NULL,NULL,1),('e2df2b063e','2012-12-28 10:49:56.000000','2015-04-04 15:11:21.707031','Administrator','Administrator',0,'Workflow State','permissions','DocType',1,0,'System Manager',NULL,1,1,1,NULL,0,1,NULL,NULL,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('e3dfc2b945','2012-12-12 11:19:22.000000','2015-04-04 15:11:13.498761','Administrator','Administrator',0,'File Data','permissions','DocType',1,0,'System Manager',NULL,1,1,1,NULL,0,1,NULL,NULL,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('e6841131fc','2014-03-04 08:29:52.000000','2015-04-04 15:11:15.926427','Administrator','Administrator',0,'Social Login Keys','permissions','DocType',1,0,'System Manager',NULL,1,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL),('ee44df1721','2013-01-29 10:47:14.000000','2015-04-04 15:11:08.163353','Administrator','Administrator',0,'Communication','permissions','DocType',1,0,'Support Team',NULL,1,1,1,0,NULL,1,0,1,NULL,NULL,1,1,1,NULL,NULL,NULL,1),('f1ce826a38','2013-02-18 13:36:19.000000','2015-04-04 15:11:06.222041','Administrator','Administrator',0,'DocType','permissions','DocType',2,0,'Administrator',NULL,1,1,1,0,0,1,NULL,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('f1f1c72df1','2014-03-11 14:55:00.000000','2015-04-04 15:11:06.404703','Administrator','Administrator',0,'User','permissions','DocType',2,1,'System Manager',NULL,1,1,0,0,0,0,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('f333d99353','2014-07-11 17:18:09.923399','2015-04-04 15:11:22.628033','Administrator','Administrator',0,'Email Alert','permissions','DocType',1,0,'System Manager',NULL,1,1,1,NULL,NULL,1,NULL,1,1,0,1,NULL,NULL,NULL,NULL,NULL,NULL),('f3cfe1cbaa','2013-03-11 17:48:16.000000','2015-04-04 15:11:17.486352','Administrator','Administrator',0,'Blog Settings','permissions','DocType',1,0,'Website Manager',NULL,1,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('f4e7630a69','2013-01-10 16:34:03.000000','2015-04-04 15:11:10.200963','Administrator','Administrator',0,'Module Def','permissions','DocType',1,0,'Administrator',NULL,1,1,1,0,0,1,0,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('f87ce1dd03','2012-07-03 13:30:35.000000','2015-04-04 15:11:26.811873','Administrator','Administrator',0,'ToDo','permissions','DocType',1,0,'All',NULL,1,1,1,0,NULL,0,NULL,1,0,NULL,1,1,1,NULL,NULL,NULL,1),('f90a5e4a50','2015-02-18 12:46:38.168929','2015-04-04 15:11:19.041436','Administrator','Administrator',0,'Website Theme','permissions','DocType',1,0,'All',NULL,1,0,0,0,0,0,0,0,0,0,0,0,0,NULL,NULL,0,0),('fe90951bcd','2013-01-10 16:34:01.000000','2015-04-04 15:11:24.153999','Administrator','Administrator',0,'Custom Script','permissions','DocType',2,0,'Administrator',NULL,1,1,1,0,0,1,NULL,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL),('ff726c9fc1','2013-01-10 16:34:01.000000','2015-04-04 15:11:07.314410','Administrator','Administrator',0,'Custom Field','permissions','DocType',1,0,'Administrator',NULL,1,1,1,0,0,1,NULL,1,NULL,NULL,1,1,1,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tabDocPerm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDocShare`
--

DROP TABLE IF EXISTS `tabDocShare`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDocShare` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `share_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `read` int(1) DEFAULT '0',
  `share` int(1) DEFAULT '0',
  `write` int(1) DEFAULT '0',
  `user` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `share_doctype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `share_name` (`share_name`),
  KEY `user` (`user`),
  KEY `share_doctype` (`share_doctype`),
  KEY `parent` (`parent`),
  KEY `user_share_doctype_index` (`user`,`share_doctype`),
  KEY `share_doctype_share_name_index` (`share_doctype`,`share_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDocShare`
--

LOCK TABLES `tabDocShare` WRITE;
/*!40000 ALTER TABLE `tabDocShare` DISABLE KEYS */;
INSERT INTO `tabDocShare` VALUES ('07c175e068','2015-04-04 15:11:31.011235','2015-04-04 15:11:31.011235','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Guest',1,1,1,'Guest','User'),('d378ad4b44','2015-04-04 15:11:30.970050','2015-04-04 15:11:31.587309','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Administrator',1,1,1,'Administrator','User');
/*!40000 ALTER TABLE `tabDocShare` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabDocType`
--

DROP TABLE IF EXISTS `tabDocType`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabDocType` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `search_fields` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `issingle` int(1) DEFAULT NULL,
  `istable` int(1) DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `module` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `plugin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `autoname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_case` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title_field` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_field` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'modified',
  `sort_order` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'DESC',
  `description` text COLLATE utf8mb4_unicode_ci,
  `colour` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `read_only` int(1) DEFAULT NULL,
  `in_create` int(1) DEFAULT NULL,
  `show_in_menu` int(1) DEFAULT NULL,
  `menu_index` int(11) DEFAULT NULL,
  `parent_node` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smallicon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allow_print` int(1) DEFAULT NULL,
  `allow_email` int(1) DEFAULT NULL,
  `allow_copy` int(1) DEFAULT NULL,
  `allow_rename` int(1) DEFAULT NULL,
  `allow_import` int(1) DEFAULT NULL,
  `hide_toolbar` int(1) DEFAULT NULL,
  `hide_heading` int(1) DEFAULT NULL,
  `use_template` int(1) DEFAULT NULL,
  `max_attachments` int(11) DEFAULT NULL,
  `print_outline` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_transaction_doc` int(1) DEFAULT NULL,
  `read_only_onload` int(1) DEFAULT NULL,
  `allow_trash` int(1) DEFAULT NULL,
  `in_dialog` int(1) DEFAULT NULL,
  `document_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tag_fields` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `_last_update` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_print_format` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_submittable` int(1) DEFAULT NULL,
  `_user_tags` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom` int(1) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`),
  KEY `module` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabDocType`
--

LOCK TABLES `tabDocType` WRITE;
/*!40000 ALTER TABLE `tabDocType` DISABLE KEYS */;
INSERT INTO `tabDocType` VALUES ('About Us Settings','2013-03-19 12:02:15.000000','2015-02-05 05:11:33.993407','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,1,NULL,NULL,'Website',NULL,NULL,NULL,NULL,NULL,NULL,'Settings for the About Us Page',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Other','icon-group',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('About Us Team Member','2013-03-07 11:55:11.000000','2015-02-19 09:29:46.804175','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,1,NULL,'Website',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Block Module','2015-03-24 14:28:15.882903','2015-03-24 16:03:52.359042','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,0,1,NULL,'Core',NULL,NULL,'',NULL,'modified','DESC',NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL,NULL,NULL,NULL,0,NULL,0,'Other',NULL,NULL,NULL,NULL,NULL,0,NULL,0),('Blog Category','2013-03-08 09:41:11.000000','2015-02-05 05:11:34.877605','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'Website',NULL,'field:category_name',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Master','icon-tag',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Blog Post','2013-03-28 10:35:30.000000','2015-02-05 05:11:34.931739','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'Website',NULL,NULL,NULL,'title',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,5,NULL,NULL,NULL,NULL,NULL,NULL,'icon-quote-left',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Blog Settings','2013-03-11 17:48:16.000000','2015-02-05 05:11:34.999631','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,1,NULL,NULL,'Website',NULL,NULL,NULL,NULL,NULL,NULL,'Blog Settings',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'icon-cog',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Blogger','2013-03-25 16:00:51.000000','2015-02-19 09:29:25.836280','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'Website',NULL,'field:short_name',NULL,'full_name',NULL,NULL,'User ID of a Blogger',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,'Master','icon-user',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Bulk Email','2012-08-02 15:17:28.000000','2015-04-01 10:00:20.892939','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'Email',NULL,'hash',NULL,NULL,NULL,NULL,'Bulk Email records.',NULL,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'System','icon-envelope',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Comment','2012-08-08 10:40:11.000000','2015-02-11 15:32:45.807458','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,0,NULL,NULL,'Core',NULL,'hash',NULL,'comment',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'icon-comments',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Communication','2013-01-29 10:47:14.000000','2015-03-23 02:33:55.289739','Administrator','Administrator',0,NULL,NULL,NULL,1,'subject',0,NULL,NULL,'Core',NULL,'naming_series:',NULL,'subject',NULL,NULL,'Keep a track of all communications',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'Master','icon-comment',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Company History','2013-02-22 01:28:08.000000','2013-12-20 19:23:01.000000','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,1,NULL,'Website',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Contact Us Settings','2013-02-21 20:12:42.000000','2015-03-11 18:08:13.531919','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,1,NULL,NULL,'Website',NULL,NULL,NULL,NULL,NULL,NULL,'Settings for Contact Us Page',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'icon-cog',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Country','2013-01-19 10:23:30.000000','2015-02-05 05:11:36.234753','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'Geo',NULL,'field:country_name',NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Master','icon-globe',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Currency','2013-01-28 10:06:02.000000','2015-02-05 05:11:36.294972','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'Geo',NULL,'field:currency_name',NULL,NULL,NULL,NULL,'**Currency** Master',NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'icon-bitcoin',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Custom Field','2013-01-10 16:34:01.000000','2015-02-25 03:39:23.573928','Administrator','Administrator',0,NULL,NULL,NULL,1,'dt,label,fieldtype,options',NULL,NULL,NULL,'Custom',NULL,NULL,NULL,NULL,NULL,NULL,'Adds a custom field to a DocType',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'icon-glass',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Custom Script','2013-01-10 16:34:01.000000','2015-02-05 05:11:36.533034','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'Custom',NULL,'CustomScript.####',NULL,NULL,NULL,NULL,'Adds a custom script (client or server) to a DocType',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'icon-glass',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Customize Form','2013-01-29 17:55:08.000000','2015-03-25 06:18:19.010091','Administrator','Administrator',0,NULL,NULL,NULL,1,'doc_type',1,NULL,NULL,'Custom',NULL,'DL.####',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'icon-glass',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Customize Form Field','2013-02-22 01:27:32.000000','2015-02-19 01:06:59.524746','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,0,1,NULL,'Custom',NULL,'hash',NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('DefaultValue','2013-02-22 01:27:32.000000','2015-02-19 01:06:59.622792','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,0,1,NULL,'Core',NULL,'hash',NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('DocField','2013-02-22 01:27:33.000000','2015-02-23 02:06:59.836515','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,0,1,NULL,'Core',NULL,'hash',NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('DocPerm','2013-02-22 01:27:33.000000','2015-03-18 06:09:58.928014','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,0,1,NULL,'Core',NULL,'hash',NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('DocShare','2015-02-04 04:33:36.330477','2015-02-12 11:30:52.968078','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'Core',NULL,'hash','',NULL,'modified','DESC','Internal record of document shares',NULL,1,1,NULL,NULL,NULL,NULL,NULL,NULL,0,0,1,0,0,NULL,NULL,NULL,NULL,0,NULL,0,'System',NULL,NULL,NULL,NULL,NULL,0,NULL,0),('DocType','2013-02-18 13:36:19.000000','2015-03-03 10:40:45.768116','Administrator','Administrator',0,NULL,NULL,NULL,1,'module',0,0,NULL,'Core',NULL,'Prompt',NULL,NULL,'name','ASC','DocType is a Table / Form in the application.',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'icon-bolt',NULL,NULL,NULL,NULL,NULL,NULL,0),('Email Account','2014-09-11 12:04:34.163728','2015-03-25 05:32:14.036800','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'Email',NULL,'field:email_account_name','',NULL,'modified','DESC',NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL,NULL,NULL,NULL,0,NULL,0,'Master','icon-inbox',NULL,NULL,NULL,NULL,0,NULL,0),('Email Alert','2014-07-11 17:18:09.923399','2015-03-25 06:20:07.472953','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Email',NULL,'hash','','subject','modified','DESC',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'System','icon-envelope',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Email Alert Recipient','2014-07-11 17:19:37.037109','2014-07-11 17:54:53.298536','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,'Email',NULL,NULL,'',NULL,'modified','DESC',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Email Unsubscribe','2015-03-18 09:41:20.216319','2015-03-18 09:41:20.216319','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'Email',NULL,NULL,'',NULL,'modified','DESC',NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL,NULL,NULL,NULL,0,NULL,0,'System',NULL,NULL,NULL,NULL,NULL,0,NULL,0),('Event','2013-06-10 13:17:47.000000','2015-02-20 05:08:30.153381','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'Desk',NULL,'EV.#####',NULL,'subject',NULL,NULL,NULL,NULL,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'icon-calendar',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Event Role','2013-02-22 01:27:33.000000','2015-02-19 01:07:00.166770','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,1,NULL,'Desk',NULL,'hash',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Feed','2012-07-03 13:29:42.000000','2015-01-07 13:40:10.882588','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'Desk',NULL,'hash',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'icon-rss',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('File Data','2012-12-12 11:19:22.000000','2015-02-05 05:11:38.944926','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'Core',NULL,'File.######',NULL,NULL,NULL,NULL,NULL,NULL,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'icon-file',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Letter Head','2012-11-22 17:45:46.000000','2015-02-05 05:11:40.906941','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'Print',NULL,'field:letter_head_name',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,3,NULL,NULL,NULL,NULL,NULL,NULL,'icon-font',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Module Def','2013-01-10 16:34:03.000000','2015-02-05 05:11:41.388856','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'Core',NULL,'field:module_name',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'icon-sitemap',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Note','2013-05-24 13:41:00.000000','2015-02-06 00:44:06.475116','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'Desk',NULL,NULL,NULL,NULL,NULL,NULL,'Note is a free page where users can share documents / notes',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Transaction','icon-file-text',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Page','2012-12-20 17:16:49.000000','2015-02-05 05:11:41.982758','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,0,0,NULL,'Core',NULL,'field:page_name',NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'icon-file',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Page Role','2013-02-22 01:27:34.000000','2015-02-19 01:07:00.897854','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,0,1,NULL,'Core',NULL,'hash',NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Patch Log','2013-01-17 11:36:45.000000','2013-12-20 19:24:15.000000','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'Core',NULL,'PATCHLOG.#####',NULL,NULL,NULL,NULL,'List of patches executed',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'System','icon-cog',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Print Format','2013-01-23 19:54:43.000000','2015-02-05 05:11:42.667447','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,0,0,NULL,'Print',NULL,'Prompt',NULL,NULL,'modified','DESC',NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,0,1,NULL,0,0,NULL,0,NULL,NULL,0,NULL,0,NULL,'icon-print',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Print Settings','2014-07-17 06:54:20.782907','2015-03-25 07:10:38.893958','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Print',NULL,NULL,'',NULL,'modified','DESC',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'System','icon-cog',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Property Setter','2013-01-10 16:34:04.000000','2015-02-05 05:11:43.216164','Administrator','Administrator',0,NULL,NULL,NULL,1,'doc_type,property',NULL,NULL,NULL,'Custom',NULL,NULL,NULL,NULL,NULL,NULL,'Property Setter overrides a standard DocType or Field property',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'icon-glass',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Report','2013-03-09 15:45:57.000000','2015-02-05 05:11:44.753200','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'Core',NULL,'field:report_name',NULL,NULL,'modified','DESC',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'System','icon-table',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Role','2013-01-08 15:50:01.000000','2015-02-05 05:11:44.831475','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,0,0,NULL,'Core',NULL,'field:role_name',NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'icon-bookmark',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Scheduler Log','2013-01-16 13:09:40.000000','2015-02-05 05:11:46.339879','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'Core',NULL,'SCHLOG.#####',NULL,NULL,NULL,NULL,'Log of Scheduler Errors',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'System','icon-warning-sign',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Social Login Keys','2014-03-04 08:29:52.000000','2015-02-05 05:11:46.875246','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,1,NULL,NULL,'Website',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'System','icon-signin',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Standard Reply','2014-06-19 05:20:26.331041','2015-02-05 05:11:46.922356','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Email',NULL,'field:subject','',NULL,'modified','DESC',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Transaction','icon-comment',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('System Settings','2014-04-17 16:53:52.640856','2015-02-05 05:11:47.880614','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,'Core',NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'System','icon-cog',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Tag','2012-07-09 11:17:17.000000','2015-02-05 05:11:47.937816','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'Core',NULL,'field:tag_name','Title Case',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'icon-tag',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('ToDo','2012-07-03 13:30:35.000000','2015-02-05 05:11:48.421852','Administrator','Administrator',0,NULL,NULL,NULL,1,'description, reference_type, reference_name',0,NULL,NULL,'Desk',NULL,'hash',NULL,'description',NULL,NULL,NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL,0,0,NULL,0,NULL,NULL,0,NULL,0,NULL,'icon-check',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Top Bar Item','2013-02-22 01:28:08.000000','2015-02-19 13:07:34.558311','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,1,NULL,'Website',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('User','2014-03-11 14:55:00.000000','2015-03-24 17:56:43.743847','Administrator','Administrator',0,NULL,NULL,NULL,1,'first_name, last_name',0,0,NULL,'Core',NULL,NULL,NULL,NULL,NULL,NULL,'Represents a User in the system.',NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,1,1,0,0,NULL,5,NULL,NULL,NULL,NULL,NULL,'Master','icon-user',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('UserRole','2013-02-06 11:30:13.000000','2015-02-19 01:07:02.561834','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,0,1,NULL,'Core',NULL,'hash',NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Version','2014-02-20 17:22:37.000000','2014-08-05 01:23:37.541856','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'Core',NULL,'_VER.######',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Master','icon-copy',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Web Form','2014-09-01 14:08:48.624556','2015-02-05 05:11:48.897157','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,0,0,NULL,'Website',NULL,'field:title','','title','modified','DESC',NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL,NULL,NULL,NULL,0,NULL,0,'Transaction','icon-edit',NULL,NULL,NULL,NULL,0,NULL,0),('Web Form Field','2014-09-01 14:14:14.292173','2014-09-03 15:47:51.643284','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,0,1,NULL,'Website',NULL,NULL,'',NULL,'modified','DESC',NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,NULL,NULL,NULL,NULL,0,NULL,0,'',NULL,NULL,NULL,NULL,NULL,0,NULL,0),('Web Page','2013-03-28 10:35:30.000000','2015-03-24 11:22:36.357479','Administrator','Administrator',0,NULL,NULL,NULL,1,'title,main_section',NULL,NULL,NULL,'Website',NULL,NULL,NULL,'title',NULL,NULL,'Page to show on the website\n',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,20,NULL,NULL,NULL,NULL,NULL,'Transaction','icon-file-alt',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Website Script','2012-12-27 11:51:24.000000','2015-02-05 05:11:49.093880','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,1,NULL,NULL,'Website',NULL,NULL,NULL,NULL,NULL,NULL,'Script to attach to all web pages.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Other','icon-code',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Website Settings','2013-04-30 12:58:46.000000','2015-02-21 08:48:35.438463','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,1,NULL,NULL,'Website',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,10,NULL,NULL,NULL,NULL,NULL,'Other','icon-cog',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Website Slideshow','2013-03-07 15:53:15.000000','2015-02-20 05:04:19.614170','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'Website',NULL,'field:slideshow_name',NULL,NULL,NULL,NULL,'Slideshow like display for the website',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,10,NULL,NULL,NULL,NULL,NULL,'Transaction','icon-play',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Website Slideshow Item','2013-03-07 12:26:33.000000','2015-02-19 09:27:05.003437','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,1,NULL,'Website',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,10,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Website Theme','2015-02-18 12:46:38.168929','2015-02-20 11:56:21.252046','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'',0,0,NULL,'Website',NULL,'field:theme','','','modified','DESC',NULL,NULL,0,0,NULL,NULL,NULL,NULL,NULL,NULL,0,0,1,0,0,NULL,NULL,NULL,NULL,0,NULL,0,'Master',NULL,NULL,NULL,NULL,NULL,0,NULL,0),('Workflow','2012-12-28 10:49:55.000000','2015-02-05 05:11:49.280959','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'Workflow',NULL,'field:workflow_name',NULL,NULL,NULL,NULL,'Defines workflow states and rules for a document.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Transaction','icon-random',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Workflow Action','2012-12-28 10:49:56.000000','2015-02-05 05:12:45.535606','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'Workflow',NULL,'field:workflow_action_name',NULL,NULL,NULL,NULL,'Workflow Action Master',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'icon-flag',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Workflow Document State','2013-02-22 01:27:36.000000','2014-05-27 06:35:01.070158','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,1,NULL,'Workflow',NULL,NULL,NULL,NULL,NULL,NULL,'Represents the states allowed in one document and role assigned to change the state.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Master',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Workflow State','2012-12-28 10:49:56.000000','2015-02-05 05:13:30.654079','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,'Workflow',NULL,'field:workflow_state_name',NULL,NULL,NULL,NULL,'Workflow state represents the current state of a document.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Master','icon-flag',NULL,NULL,NULL,NULL,NULL,NULL,NULL),('Workflow Transition','2013-02-22 01:27:36.000000','2013-12-20 19:21:55.000001','Administrator','Administrator',0,NULL,NULL,NULL,1,NULL,NULL,1,NULL,'Workflow',NULL,NULL,NULL,NULL,NULL,NULL,'Defines actions on states and the next step and allowed roles.',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tabDocType` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabEmail Account`
--

DROP TABLE IF EXISTS `tabEmail Account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabEmail Account` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `default_outgoing` int(1) DEFAULT NULL,
  `email_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auto_reply_message` longtext COLLATE utf8mb4_unicode_ci,
  `use_ssl` int(1) DEFAULT NULL,
  `send_notification_to` text COLLATE utf8mb4_unicode_ci,
  `default_incoming` int(1) DEFAULT NULL,
  `service` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_port` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_server` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `use_tls` int(1) DEFAULT NULL,
  `enable_incoming` int(1) DEFAULT NULL,
  `attachment_limit` int(11) DEFAULT '1',
  `pop3_server` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enable_auto_reply` int(1) DEFAULT NULL,
  `enable_outgoing` int(1) DEFAULT NULL,
  `add_signature` int(1) DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_account_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer` longtext COLLATE utf8mb4_unicode_ci,
  `unreplied_for_mins` int(11) DEFAULT NULL,
  `append_to` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `signature` longtext COLLATE utf8mb4_unicode_ci,
  `notify_if_unreplied` int(1) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabEmail Account`
--

LOCK TABLES `tabEmail Account` WRITE;
/*!40000 ALTER TABLE `tabEmail Account` DISABLE KEYS */;
INSERT INTO `tabEmail Account` VALUES ('Notifications','2015-04-04 15:11:31.112436','2015-04-04 15:11:31.112436','Administrator','Administrator',0,NULL,NULL,NULL,NULL,1,'notifications@example.com',NULL,0,NULL,0,'',NULL,NULL,0,0,1,NULL,0,0,0,NULL,'Notifications',NULL,NULL,NULL,NULL,0),('Replies','2015-04-04 15:11:31.127807','2015-04-04 15:11:31.127807','Administrator','Administrator',0,NULL,NULL,NULL,NULL,0,'replies@example.com',NULL,0,NULL,1,'',NULL,NULL,0,0,1,NULL,0,0,0,NULL,'Replies',NULL,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `tabEmail Account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabEmail Alert`
--

DROP TABLE IF EXISTS `tabEmail Alert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabEmail Alert` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `document_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled` int(1) DEFAULT '1',
  `days_in_advance` int(11) DEFAULT '0',
  `value_changed` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_changed` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `attach_print` int(1) DEFAULT NULL,
  `event` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `condition` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `document_type` (`document_type`),
  KEY `event` (`event`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabEmail Alert`
--

LOCK TABLES `tabEmail Alert` WRITE;
/*!40000 ALTER TABLE `tabEmail Alert` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabEmail Alert` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabEmail Alert Recipient`
--

DROP TABLE IF EXISTS `tabEmail Alert Recipient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabEmail Alert Recipient` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `cc` text COLLATE utf8mb4_unicode_ci,
  `email_by_document_field` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `condition` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabEmail Alert Recipient`
--

LOCK TABLES `tabEmail Alert Recipient` WRITE;
/*!40000 ALTER TABLE `tabEmail Alert Recipient` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabEmail Alert Recipient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabEmail Unsubscribe`
--

DROP TABLE IF EXISTS `tabEmail Unsubscribe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabEmail Unsubscribe` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `reference_doctype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabEmail Unsubscribe`
--

LOCK TABLES `tabEmail Unsubscribe` WRITE;
/*!40000 ALTER TABLE `tabEmail Unsubscribe` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabEmail Unsubscribe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabEvent`
--

DROP TABLE IF EXISTS `tabEvent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabEvent` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `event_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tuesday` int(1) DEFAULT NULL,
  `all_day` int(1) DEFAULT NULL,
  `thursday` int(1) DEFAULT NULL,
  `saturday` int(1) DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `repeat_this_event` int(1) DEFAULT NULL,
  `repeat_till` date DEFAULT NULL,
  `sunday` int(1) DEFAULT NULL,
  `send_reminder` int(1) DEFAULT '1',
  `ref_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `monday` int(1) DEFAULT NULL,
  `friday` int(1) DEFAULT NULL,
  `starts_on` datetime(6) DEFAULT NULL,
  `wednesday` int(1) DEFAULT NULL,
  `ends_on` datetime(6) DEFAULT NULL,
  `repeat_on` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `event_type` (`event_type`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabEvent`
--

LOCK TABLES `tabEvent` WRITE;
/*!40000 ALTER TABLE `tabEvent` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabEvent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabEvent Role`
--

DROP TABLE IF EXISTS `tabEvent Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabEvent Role` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabEvent Role`
--

LOCK TABLES `tabEvent Role` WRITE;
/*!40000 ALTER TABLE `tabEvent Role` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabEvent Role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabFeed`
--

DROP TABLE IF EXISTS `tabFeed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabFeed` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `doc_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `doc_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `feed_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`),
  KEY `feed_doctype_docname_index` (`doc_type`,`doc_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabFeed`
--

LOCK TABLES `tabFeed` WRITE;
/*!40000 ALTER TABLE `tabFeed` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabFeed` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabFile Data`
--

DROP TABLE IF EXISTS `tabFile Data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabFile Data` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `module` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attached_to_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `attached_to_doctype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `content_hash` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`),
  KEY `attached_to_name` (`attached_to_name`),
  KEY `attached_to_doctype` (`attached_to_doctype`),
  KEY `attached_to_doctype_attached_to_name_index` (`attached_to_doctype`,`attached_to_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabFile Data`
--

LOCK TABLES `tabFile Data` WRITE;
/*!40000 ALTER TABLE `tabFile Data` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabFile Data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabLetter Head`
--

DROP TABLE IF EXISTS `tabLetter Head`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabLetter Head` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `is_default` int(1) DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `letter_head_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disabled` int(1) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `is_default` (`is_default`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabLetter Head`
--

LOCK TABLES `tabLetter Head` WRITE;
/*!40000 ALTER TABLE `tabLetter Head` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabLetter Head` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabModule Def`
--

DROP TABLE IF EXISTS `tabModule Def`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabModule Def` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `module_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `app_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabModule Def`
--

LOCK TABLES `tabModule Def` WRITE;
/*!40000 ALTER TABLE `tabModule Def` DISABLE KEYS */;
INSERT INTO `tabModule Def` VALUES ('Core','2015-04-04 15:11:10.486324','2015-04-04 15:11:10.486324','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Core','frappe'),('Custom','2015-04-04 15:11:24.441623','2015-04-04 15:11:24.441623','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Custom','frappe'),('Desk','2015-04-04 15:11:26.058369','2015-04-04 15:11:26.058369','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Desk','frappe'),('Email','2015-04-04 15:11:22.291002','2015-04-04 15:11:22.291002','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Email','frappe'),('Geo','2015-04-04 15:11:25.405336','2015-04-04 15:11:25.405336','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Geo','frappe'),('Print','2015-04-04 15:11:28.860349','2015-04-04 15:11:28.860349','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Print','frappe'),('Website','2015-04-04 15:11:15.136239','2015-04-04 15:11:15.136239','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Website','frappe'),('Workflow','2015-04-04 15:11:20.707477','2015-04-04 15:11:20.707477','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Workflow','frappe');
/*!40000 ALTER TABLE `tabModule Def` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabNote`
--

DROP TABLE IF EXISTS `tabNote`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabNote` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `public` int(1) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabNote`
--

LOCK TABLES `tabNote` WRITE;
/*!40000 ALTER TABLE `tabNote` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabNote` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabPage`
--

DROP TABLE IF EXISTS `tabPage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabPage` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `module` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `standard` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `page_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `standard` (`standard`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabPage`
--

LOCK TABLES `tabPage` WRITE;
/*!40000 ALTER TABLE `tabPage` DISABLE KEYS */;
INSERT INTO `tabPage` VALUES ('activity','2013-04-09 11:45:31.000000','2013-07-11 14:40:20.000001','Administrator','Administrator',0,NULL,NULL,NULL,1,'Activity','Desk','Yes','activity','icon-play'),('applications','2013-12-23 11:01:52.000000','2013-12-23 11:01:52.000001','Administrator','Administrator',0,NULL,NULL,NULL,1,'Applications','Desk','Yes','applications','icon-magic'),('data-import-tool','2012-06-14 15:07:25.000000','2014-02-13 16:09:27.000000','Administrator','Administrator',0,NULL,NULL,NULL,1,'Data Import Tool','Core','Yes','data-import-tool','icon-upload'),('desktop','2013-02-14 17:37:37.000000','2013-07-11 14:41:56.000000','Administrator','Administrator',0,NULL,NULL,NULL,1,'Desktop','Core','Yes','desktop','icon-th'),('messages','2012-06-14 18:44:56.000000','2013-07-11 14:43:32.000001','Administrator','Administrator',0,NULL,NULL,NULL,1,'Messages','Desk','Yes','messages','icon-envelope'),('modules_setup','2012-10-04 18:45:29.000000','2013-07-11 14:43:37.000000','Administrator','Administrator',0,NULL,NULL,NULL,1,'Modules Setup','Core','Yes','modules_setup','icon-cog'),('permission-manager','2013-01-01 11:00:01.000000','2013-07-11 14:43:43.000000','Administrator','Administrator',0,NULL,NULL,NULL,1,'Role Permissions Manager','Core','Yes','permission-manager','icon-lock'),('print-format-builder','2015-01-27 04:35:43.872918','2015-01-27 04:35:43.872918','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Print Format Builder','Print','Yes','print-format-builder',NULL),('user-permissions','2013-01-01 18:50:55.000000','2014-05-28 16:53:43.103533','Administrator','Administrator',0,NULL,NULL,NULL,1,'User Permissions Manager','Core','Yes','user-permissions','icon-user');
/*!40000 ALTER TABLE `tabPage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabPage Role`
--

DROP TABLE IF EXISTS `tabPage Role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabPage Role` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabPage Role`
--

LOCK TABLES `tabPage Role` WRITE;
/*!40000 ALTER TABLE `tabPage Role` DISABLE KEYS */;
INSERT INTO `tabPage Role` VALUES ('058ccf09d3','2012-06-14 15:07:25.000000','2015-04-04 15:11:14.919661','Administrator','Administrator',0,'data-import-tool','roles','Page',1,'System Manager'),('05cdb8cb14','2013-01-01 11:00:01.000000','2015-04-04 15:11:14.982100','Administrator','Administrator',0,'permission-manager','roles','Page',1,'System Manager'),('1c474465bd','2012-10-04 18:45:29.000000','2015-04-04 15:11:14.937903','Administrator','Administrator',0,'modules_setup','roles','Page',1,'System Manager'),('25d93a3fb6','2013-02-14 17:37:37.000000','2015-04-04 15:11:15.004283','Administrator','Administrator',0,'desktop','roles','Page',1,'All'),('2fa22104aa','2013-04-09 11:45:31.000000','2015-04-04 15:11:28.483180','Administrator','Administrator',0,'activity','roles','Page',1,'All'),('317a899461','2013-12-23 11:01:52.000000','2015-04-04 15:11:28.452818','Administrator','Administrator',0,'applications','roles','Page',1,'System Manager'),('b1ad328146','2012-06-14 18:44:56.000000','2015-04-04 15:11:28.506508','Administrator','Administrator',0,'messages','roles','Page',1,'All'),('c33b6e606d','2015-01-27 04:35:43.872918','2015-04-04 15:11:29.413257','Administrator','Administrator',0,'print-format-builder','roles','Page',1,'System Manager');
/*!40000 ALTER TABLE `tabPage Role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabPatch Log`
--

DROP TABLE IF EXISTS `tabPatch Log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabPatch Log` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `patch` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabPatch Log`
--

LOCK TABLES `tabPatch Log` WRITE;
/*!40000 ALTER TABLE `tabPatch Log` DISABLE KEYS */;
INSERT INTO `tabPatch Log` VALUES ('PATCHLOG00001','2015-04-04 15:11:30.532964','2015-04-04 15:11:30.532964','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.db.sql(\"\"\"update `tabPatch Log` set patch=replace(patch, \'.4_0.\', \'.v4_0.\')\"\"\") #2014-05-12'),('PATCHLOG00002','2015-04-04 15:11:30.536831','2015-04-04 15:11:30.536831','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v5_0.convert_to_barracuda_and_utf8mb4'),('PATCHLOG00003','2015-04-04 15:11:30.540559','2015-04-04 15:11:30.540559','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.reload_doc(\'core\', \'doctype\', \'doctype\', force=True) #2014-01-24'),('PATCHLOG00004','2015-04-04 15:11:30.543929','2015-04-04 15:11:30.543929','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.reload_doc(\'core\', \'doctype\', \'docfield\', force=True) #2015-01-01'),('PATCHLOG00005','2015-04-04 15:11:30.547212','2015-04-04 15:11:30.547212','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.reload_doc(\'core\', \'doctype\', \'docperm\') #2014-06-04'),('PATCHLOG00006','2015-04-04 15:11:30.550782','2015-04-04 15:11:30.550782','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.reload_doc(\'core\', \'doctype\', \'page\') #2013-13-26'),('PATCHLOG00007','2015-04-04 15:11:30.554244','2015-04-04 15:11:30.554244','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.reload_doc(\'core\', \'doctype\', \'report\') #2014-06-03'),('PATCHLOG00008','2015-04-04 15:11:30.558081','2015-04-04 15:11:30.558081','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.reload_doc(\'core\', \'doctype\', \'version\') #2014-02-21'),('PATCHLOG00009','2015-04-04 15:11:30.562186','2015-04-04 15:11:30.562186','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.reload_doc(\'email\', \'doctype\', \'email_alert\') #2014-07-15'),('PATCHLOG00010','2015-04-04 15:11:30.566286','2015-04-04 15:11:30.566286','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.reload_doc(\'desk\', \'doctype\', \'todo\') #2014-12-31-1'),('PATCHLOG00011','2015-04-04 15:11:30.570391','2015-04-04 15:11:30.570391','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.reload_doc(\'custom\', \'doctype\', \'property_setter\') #2014-12-31-1'),('PATCHLOG00012','2015-04-04 15:11:30.574528','2015-04-04 15:11:30.574528','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.db.sql(\"alter table `tabSessions` modify `user` varchar(255), engine=InnoDB\")'),('PATCHLOG00013','2015-04-04 15:11:30.578612','2015-04-04 15:11:30.578612','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.db.sql(\"delete from `tabDocField` where parent=\'0\'\")'),('PATCHLOG00014','2015-04-04 15:11:30.582691','2015-04-04 15:11:30.582691','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.change_varchar_length'),('PATCHLOG00015','2015-04-04 15:11:30.586907','2015-04-04 15:11:30.586907','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v5_0.v4_to_v5'),('PATCHLOG00016','2015-04-04 15:11:30.590891','2015-04-04 15:11:30.590891','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v5_0.remove_shopping_cart_app'),('PATCHLOG00017','2015-04-04 15:11:30.594868','2015-04-04 15:11:30.594868','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.webnotes_to_frappe'),('PATCHLOG00018','2015-04-04 15:11:30.599826','2015-04-04 15:11:30.599826','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.permissions.reset_perms(\"Module Def\")'),('PATCHLOG00019','2015-04-04 15:11:30.605288','2015-04-04 15:11:30.605288','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:import frappe.installer;frappe.installer.make_site_dirs() #2014-02-19'),('PATCHLOG00020','2015-04-04 15:11:30.609444','2015-04-04 15:11:30.609444','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.rename_profile_to_user'),('PATCHLOG00021','2015-04-04 15:11:30.612317','2015-04-04 15:11:30.612317','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.deprecate_control_panel'),('PATCHLOG00022','2015-04-04 15:11:30.615345','2015-04-04 15:11:30.615345','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.remove_old_parent'),('PATCHLOG00023','2015-04-04 15:11:30.618240','2015-04-04 15:11:30.618240','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.rename_sitemap_to_route'),('PATCHLOG00024','2015-04-04 15:11:30.621163','2015-04-04 15:11:30.621163','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.website_sitemap_hierarchy'),('PATCHLOG00025','2015-04-04 15:11:30.624442','2015-04-04 15:11:30.624442','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.remove_index_sitemap'),('PATCHLOG00026','2015-04-04 15:11:30.627714','2015-04-04 15:11:30.627714','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.set_website_route_idx'),('PATCHLOG00027','2015-04-04 15:11:30.630982','2015-04-04 15:11:30.630982','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.add_delete_permission'),('PATCHLOG00028','2015-04-04 15:11:30.634389','2015-04-04 15:11:30.634389','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.set_todo_checked_as_closed'),('PATCHLOG00029','2015-04-04 15:11:30.637825','2015-04-04 15:11:30.637825','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.private_backups'),('PATCHLOG00030','2015-04-04 15:11:30.641266','2015-04-04 15:11:30.641266','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.set_module_in_report'),('PATCHLOG00031','2015-04-04 15:11:30.644695','2015-04-04 15:11:30.644695','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.update_datetime'),('PATCHLOG00032','2015-04-04 15:11:30.648106','2015-04-04 15:11:30.648106','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.file_manager_hooks'),('PATCHLOG00033','2015-04-04 15:11:30.651219','2015-04-04 15:11:30.651219','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.get_doc(\"User\", \"Guest\").save()'),('PATCHLOG00034','2015-04-04 15:11:30.654520','2015-04-04 15:11:30.654520','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.update_custom_field_insert_after'),('PATCHLOG00035','2015-04-04 15:11:30.657933','2015-04-04 15:11:30.657933','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.deprecate_link_selects'),('PATCHLOG00036','2015-04-04 15:11:30.661576','2015-04-04 15:11:30.661576','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.set_user_gravatar'),('PATCHLOG00037','2015-04-04 15:11:30.665388','2015-04-04 15:11:30.665388','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.set_user_permissions'),('PATCHLOG00038','2015-04-04 15:11:30.669098','2015-04-04 15:11:30.669098','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.create_custom_field_for_owner_match'),('PATCHLOG00039','2015-04-04 15:11:30.673093','2015-04-04 15:11:30.673093','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.enable_scheduler_in_system_settings'),('PATCHLOG00040','2015-04-04 15:11:30.676747','2015-04-04 15:11:30.676747','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.db.sql(\"update tabReport set apply_user_permissions=1\") #2014-06-03'),('PATCHLOG00041','2015-04-04 15:11:30.680358','2015-04-04 15:11:30.680358','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.replace_deprecated_timezones'),('PATCHLOG00042','2015-04-04 15:11:30.683487','2015-04-04 15:11:30.683487','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:import frappe.website.render; frappe.website.render.clear_cache(\"login\"); #2014-06-10'),('PATCHLOG00043','2015-04-04 15:11:30.687400','2015-04-04 15:11:30.687400','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.fix_attach_field_file_url'),('PATCHLOG00044','2015-04-04 15:11:30.693280','2015-04-04 15:11:30.693280','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.permissions.reset_perms(\"User\") #2015-03-24'),('PATCHLOG00045','2015-04-04 15:11:30.698211','2015-04-04 15:11:30.698211','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.db.sql(\"\"\"delete from `tabUserRole` where ifnull(parentfield, \'\')=\'\' or ifnull(`role`, \'\')=\'\'\"\"\") #2014-08-18'),('PATCHLOG00046','2015-04-04 15:11:30.702145','2015-04-04 15:11:30.702145','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_0.remove_user_owner_custom_field'),('PATCHLOG00047','2015-04-04 15:11:30.706252','2015-04-04 15:11:30.706252','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.delete_doc(\"DocType\", \"Website Template\")'),('PATCHLOG00048','2015-04-04 15:11:30.710439','2015-04-04 15:11:30.710439','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.db.sql(\"\"\"update `tabProperty Setter` set property_type=\'Text\' where property in (\'options\', \'default\')\"\"\") #2014-06-20'),('PATCHLOG00049','2015-04-04 15:11:30.714813','2015-04-04 15:11:30.714813','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_1.enable_outgoing_email_settings'),('PATCHLOG00050','2015-04-04 15:11:30.719259','2015-04-04 15:11:30.719259','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.db.sql(\"\"\"update `tabSingles` set `value`=`doctype` where `field`=\'name\'\"\"\") #2014-07-04'),('PATCHLOG00051','2015-04-04 15:11:30.723662','2015-04-04 15:11:30.723662','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_1.enable_print_as_pdf #2014-06-17'),('PATCHLOG00052','2015-04-04 15:11:30.727788','2015-04-04 15:11:30.727788','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.db.sql(\"\"\"update `tabDocPerm` set email=1 where parent=\'User\' and permlevel=0 and `role`=\'All\' and `read`=1 and apply_user_permissions=1\"\"\") #2014-07-15'),('PATCHLOG00053','2015-04-04 15:11:30.732795','2015-04-04 15:11:30.732795','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.db.sql(\"\"\"update `tabPrint Format` set print_format_type=\'Client\' where ifnull(print_format_type, \'\')=\'\'\"\"\") #2014-07-28'),('PATCHLOG00054','2015-04-04 15:11:30.738108','2015-04-04 15:11:30.738108','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_1.file_manager_fix'),('PATCHLOG00055','2015-04-04 15:11:30.741854','2015-04-04 15:11:30.741854','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_2.print_with_letterhead'),('PATCHLOG00056','2015-04-04 15:11:30.745079','2015-04-04 15:11:30.745079','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.delete_doc(\"DocType\", \"Control Panel\", force=1)'),('PATCHLOG00057','2015-04-04 15:11:30.748263','2015-04-04 15:11:30.748263','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.reload_doc(\'website\', \'doctype\', \'web_form\') #2014-09-04'),('PATCHLOG00058','2015-04-04 15:11:30.753219','2015-04-04 15:11:30.753219','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.reload_doc(\'website\', \'doctype\', \'web_form_field\') #2014-09-04'),('PATCHLOG00059','2015-04-04 15:11:30.757191','2015-04-04 15:11:30.757191','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_2.refactor_website_routing'),('PATCHLOG00060','2015-04-04 15:11:30.761052','2015-04-04 15:11:30.761052','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_2.set_assign_in_doc'),('PATCHLOG00061','2015-04-04 15:11:30.764957','2015-04-04 15:11:30.764957','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v4_3.remove_allow_on_submit_customization'),('PATCHLOG00062','2015-04-04 15:11:30.768805','2015-04-04 15:11:30.768805','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v5_0.rename_table_fieldnames'),('PATCHLOG00063','2015-04-04 15:11:30.772439','2015-04-04 15:11:30.772439','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v5_0.communication_parent'),('PATCHLOG00064','2015-04-04 15:11:30.775918','2015-04-04 15:11:30.775918','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v5_0.clear_website_group_and_notifications'),('PATCHLOG00065','2015-04-04 15:11:30.779229','2015-04-04 15:11:30.779229','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'execute:frappe.db.sql(\"\"\"update tabComment set comment = substr(comment, 6, locate(\":\", comment)-6) where comment_type in (\"Assigned\", \"Assignment Completed\")\"\"\")'),('PATCHLOG00066','2015-04-04 15:11:30.782578','2015-04-04 15:11:30.782578','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v5_0.fix_feed'),('PATCHLOG00067','2015-04-04 15:11:30.785936','2015-04-04 15:11:30.785936','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v5_0.update_shared'),('PATCHLOG00068','2015-04-04 15:11:30.789836','2015-04-04 15:11:30.789836','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v5_0.bookmarks_to_stars'),('PATCHLOG00069','2015-04-04 15:11:30.795367','2015-04-04 15:11:30.795367','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v5_0.style_settings_to_website_theme'),('PATCHLOG00070','2015-04-04 15:11:30.800282','2015-04-04 15:11:30.800282','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v5_0.rename_ref_type_fieldnames'),('PATCHLOG00071','2015-04-04 15:11:30.804422','2015-04-04 15:11:30.804422','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'frappe.patches.v5_0.fix_email_alert');
/*!40000 ALTER TABLE `tabPatch Log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabPrint Format`
--

DROP TABLE IF EXISTS `tabPrint Format`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabPrint Format` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `doc_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `print_format_builder` int(1) DEFAULT NULL,
  `standard` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'No',
  `disabled` int(1) DEFAULT NULL,
  `html` longtext COLLATE utf8mb4_unicode_ci,
  `custom_format` int(1) DEFAULT NULL,
  `print_format_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Server',
  `format_data` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`name`),
  KEY `standard` (`standard`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabPrint Format`
--

LOCK TABLES `tabPrint Format` WRITE;
/*!40000 ALTER TABLE `tabPrint Format` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabPrint Format` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabProperty Setter`
--

DROP TABLE IF EXISTS `tabProperty Setter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabProperty Setter` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `default_value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `doc_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `property_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `doctype_or_field` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `property` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `doc_type` (`doc_type`),
  KEY `property` (`property`),
  KEY `field_name` (`field_name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabProperty Setter`
--

LOCK TABLES `tabProperty Setter` WRITE;
/*!40000 ALTER TABLE `tabProperty Setter` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabProperty Setter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabReport`
--

DROP TABLE IF EXISTS `tabReport`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabReport` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `apply_user_permissions` int(1) DEFAULT '1',
  `javascript` longtext COLLATE utf8mb4_unicode_ci,
  `add_total_row` int(1) DEFAULT NULL,
  `ref_doctype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `module` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `report_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `disabled` int(1) DEFAULT NULL,
  `json` text COLLATE utf8mb4_unicode_ci,
  `is_standard` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `report_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `query` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabReport`
--

LOCK TABLES `tabReport` WRITE;
/*!40000 ALTER TABLE `tabReport` DISABLE KEYS */;
INSERT INTO `tabReport` VALUES ('Document Share Report','2015-02-05 06:01:35.060098','2015-02-05 06:01:52.870622','Administrator','Administrator',0,NULL,NULL,NULL,NULL,1,NULL,0,'DocShare','Core','Document Share Report',0,'{\"filters\":[],\"columns\":[[\"name\",\"DocShare\"],[\"user\",\"DocShare\"],[\"share_doctype\",\"DocShare\"],[\"share_name\",\"DocShare\"],[\"read\",\"DocShare\"],[\"write\",\"DocShare\"],[\"share\",\"DocShare\"]],\"sort_by\":\"DocShare.modified\",\"sort_order\":\"desc\",\"sort_by_next\":null,\"sort_order_next\":\"desc\"}','Yes','Report Builder',NULL),('Permitted Documents For User','2014-06-03 05:20:35.218263','2014-06-03 07:18:17.218526','Administrator','Administrator',0,NULL,NULL,NULL,NULL,1,NULL,NULL,'User','Core','Permitted Documents For User',NULL,NULL,'Yes','Script Report',NULL),('ToDo','2013-02-25 14:26:30.000000','2014-06-03 07:18:17.374222','Administrator','Administrator',0,NULL,NULL,NULL,1,1,NULL,NULL,'ToDo','Core','ToDo',NULL,NULL,'Yes','Script Report',NULL);
/*!40000 ALTER TABLE `tabReport` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabRole`
--

DROP TABLE IF EXISTS `tabRole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabRole` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `role_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabRole`
--

LOCK TABLES `tabRole` WRITE;
/*!40000 ALTER TABLE `tabRole` DISABLE KEYS */;
INSERT INTO `tabRole` VALUES ('Administrator','2015-04-04 15:11:10.496842','2015-04-04 15:11:10.496842','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Administrator'),('All','2015-04-04 15:11:10.495401','2015-04-04 15:11:10.495401','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'All'),('Blogger','2015-04-04 15:11:15.891392','2015-04-04 15:11:15.891392','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Blogger'),('Guest','2015-04-04 15:11:10.498169','2015-04-04 15:11:10.498169','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Guest'),('Report Manager','2015-04-04 15:11:13.476476','2015-04-04 15:11:13.476476','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Report Manager'),('System Manager','2015-04-04 15:11:10.493853','2015-04-04 15:11:10.493853','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'System Manager'),('Website Manager','2015-04-04 15:11:15.147610','2015-04-04 15:11:15.147610','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Website Manager');
/*!40000 ALTER TABLE `tabRole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabScheduler Log`
--

DROP TABLE IF EXISTS `tabScheduler Log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabScheduler Log` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `error` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabScheduler Log`
--

LOCK TABLES `tabScheduler Log` WRITE;
/*!40000 ALTER TABLE `tabScheduler Log` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabScheduler Log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabSeries`
--

DROP TABLE IF EXISTS `tabSeries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabSeries` (
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabSeries`
--

LOCK TABLES `tabSeries` WRITE;
/*!40000 ALTER TABLE `tabSeries` DISABLE KEYS */;
INSERT INTO `tabSeries` VALUES ('PATCHLOG',71);
/*!40000 ALTER TABLE `tabSeries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabSessions`
--

DROP TABLE IF EXISTS `tabSessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabSessions` (
  `user` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sessiondata` longtext COLLATE utf8mb4_unicode_ci,
  `ipaddress` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastupdate` datetime(6) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  KEY `sid` (`sid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabSessions`
--

LOCK TABLES `tabSessions` WRITE;
/*!40000 ALTER TABLE `tabSessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabSessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabSingles`
--

DROP TABLE IF EXISTS `tabSingles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabSingles` (
  `doctype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  KEY `singles_doctype_field_index` (`doctype`,`field`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabSingles`
--

LOCK TABLES `tabSingles` WRITE;
/*!40000 ALTER TABLE `tabSingles` DISABLE KEYS */;
INSERT INTO `tabSingles` VALUES ('About Us Settings','modified_by','Administrator'),('About Us Settings','name','About Us Settings'),('About Us Settings','parent',NULL),('About Us Settings','footer',NULL),('About Us Settings','company_introduction',NULL),('About Us Settings','creation','2015-04-04 15:11:29.589245'),('About Us Settings','modified','2015-04-04 15:11:29.589245'),('About Us Settings','idx',NULL),('About Us Settings','parenttype',NULL),('About Us Settings','company_history_heading',NULL),('About Us Settings','owner','Administrator'),('About Us Settings','docstatus','0'),('About Us Settings','team_members_heading',NULL),('About Us Settings','parentfield',NULL),('Blog Settings','modified_by','Administrator'),('Blog Settings','name','Blog Settings'),('Blog Settings','parent',NULL),('Blog Settings','creation','2015-04-04 15:11:29.611172'),('Blog Settings','modified','2015-04-04 15:11:29.611172'),('Blog Settings','idx',NULL),('Blog Settings','parenttype',NULL),('Blog Settings','owner','Administrator'),('Blog Settings','docstatus','0'),('Blog Settings','writers_introduction',NULL),('Blog Settings','blog_title',NULL),('Blog Settings','blog_introduction',NULL),('Blog Settings','parentfield',NULL),('Contact Us Settings','address_line2',NULL),('Contact Us Settings','city',NULL),('Contact Us Settings','address_line1',NULL),('Contact Us Settings','modified_by','Administrator'),('Contact Us Settings','name','Contact Us Settings'),('Contact Us Settings','parent',NULL),('Contact Us Settings','state',NULL),('Contact Us Settings','introduction',NULL),('Contact Us Settings','country',NULL),('Contact Us Settings','creation','2015-04-04 15:11:29.644419'),('Contact Us Settings','forward_to_email',NULL),('Contact Us Settings','modified','2015-04-04 15:11:29.644419'),('Contact Us Settings','pincode',NULL),('Contact Us Settings','idx',NULL),('Contact Us Settings','parenttype',NULL),('Contact Us Settings','address_title',NULL),('Contact Us Settings','owner','Administrator'),('Contact Us Settings','docstatus','0'),('Contact Us Settings','heading',NULL),('Contact Us Settings','query_options',NULL),('Contact Us Settings','parentfield',NULL),('Social Login Keys','github_client_secret',NULL),('Social Login Keys','facebook_client_secret',NULL),('Social Login Keys','modified_by','Administrator'),('Social Login Keys','name','Social Login Keys'),('Social Login Keys','parent',NULL),('Social Login Keys','creation','2015-04-04 15:11:29.837257'),('Social Login Keys','modified','2015-04-04 15:11:29.837257'),('Social Login Keys','facebook_client_id',NULL),('Social Login Keys','google_client_secret',NULL),('Social Login Keys','idx',NULL),('Social Login Keys','parenttype',NULL),('Social Login Keys','owner','Administrator'),('Social Login Keys','docstatus','0'),('Social Login Keys','google_client_id',NULL),('Social Login Keys','github_client_id',NULL),('Social Login Keys','parentfield',NULL),('System Settings','session_expiry','06:00'),('System Settings','date_format','yyyy-mm-dd'),('System Settings','modified_by','Administrator'),('System Settings','name','System Settings'),('System Settings','parent',NULL),('System Settings','language',NULL),('System Settings','creation','2015-04-04 15:11:29.861797'),('System Settings','modified','2015-04-04 15:11:29.861797'),('System Settings','time_zone',NULL),('System Settings','idx',NULL),('System Settings','parenttype',NULL),('System Settings','float_precision',''),('System Settings','owner','Administrator'),('System Settings','docstatus','0'),('System Settings','enable_scheduler','0'),('System Settings','number_format','#,###.##'),('System Settings','parentfield',NULL),('Website Script','javascript',NULL),('Website Script','modified_by','Administrator'),('Website Script','name','Website Script'),('Website Script','parent',NULL),('Website Script','creation','2015-04-04 15:11:30.341504'),('Website Script','modified','2015-04-04 15:11:30.341504'),('Website Script','idx',NULL),('Website Script','parenttype',NULL),('Website Script','owner','Administrator'),('Website Script','docstatus','0'),('Website Script','parentfield',NULL),('Website Settings','creation','2015-04-04 15:11:30.383105'),('Website Settings','favicon',NULL),('Website Settings','docstatus','0'),('Website Settings','owner','Administrator'),('Website Settings','home_page_is_products','0'),('Website Settings','banner_html',NULL),('Website Settings','google_plus_one','0'),('Website Settings','google_analytics_id',NULL),('Website Settings','modified_by','Administrator'),('Website Settings','copyright',NULL),('Website Settings','home_page',NULL),('Website Settings','twitter_share','0'),('Website Settings','brand_html',NULL),('Website Settings','title_prefix',NULL),('Website Settings','subdomain',NULL),('Website Settings','parent',NULL),('Website Settings','disable_signup','0'),('Website Settings','facebook_share','0'),('Website Settings','banner_image',NULL),('Website Settings','address',NULL),('Website Settings','website_theme_image_link',NULL),('Website Settings','website_theme','Standard'),('Website Settings','name','Website Settings'),('Website Settings','idx',NULL),('Website Settings','modified','2015-04-04 15:11:30.383105'),('Website Settings','linked_in_share','0'),('Website Settings','parenttype',NULL),('Website Settings','twitter_share_via',NULL),('Website Settings','parentfield',NULL),('Print Settings','modified_by','Administrator'),('Print Settings','name','Print Settings'),('Print Settings','parent',NULL),('Print Settings','creation','2015-04-04 15:11:29.735480'),('Print Settings','modified','2015-04-04 15:11:31.484557'),('Print Settings','idx',NULL),('Print Settings','parenttype',NULL),('Print Settings','print_style','Modern'),('Print Settings','with_letterhead','1'),('Print Settings','pdf_page_size','A4'),('Print Settings','owner','Administrator'),('Print Settings','docstatus','0'),('Print Settings','font_size',NULL),('Print Settings','send_print_as_pdf','1'),('Print Settings','parentfield',NULL);
/*!40000 ALTER TABLE `tabSingles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabStandard Reply`
--

DROP TABLE IF EXISTS `tabStandard Reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabStandard Reply` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `response` longtext COLLATE utf8mb4_unicode_ci,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabStandard Reply`
--

LOCK TABLES `tabStandard Reply` WRITE;
/*!40000 ALTER TABLE `tabStandard Reply` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabStandard Reply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabTag`
--

DROP TABLE IF EXISTS `tabTag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabTag` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `tag_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabTag`
--

LOCK TABLES `tabTag` WRITE;
/*!40000 ALTER TABLE `tabTag` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabTag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabToDo`
--

DROP TABLE IF EXISTS `tabToDo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabToDo` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Open',
  `date` date DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `assigned_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reference_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priority` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Medium',
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`),
  KEY `reference_type_reference_name_index` (`reference_type`,`reference_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabToDo`
--

LOCK TABLES `tabToDo` WRITE;
/*!40000 ALTER TABLE `tabToDo` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabToDo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabTop Bar Item`
--

DROP TABLE IF EXISTS `tabTop Bar Item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabTop Bar Item` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `right` int(1) DEFAULT NULL,
  `target` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabTop Bar Item`
--

LOCK TABLES `tabTop Bar Item` WRITE;
/*!40000 ALTER TABLE `tabTop Bar Item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabTop Bar Item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabUser`
--

DROP TABLE IF EXISTS `tabUser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabUser` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_ip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'System User',
  `github_username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reset_password_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_userid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_known_versions` text COLLATE utf8mb4_unicode_ci,
  `restrict_ip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `middle_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_login` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `github_userid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `login_after` int(11) DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bio` text COLLATE utf8mb4_unicode_ci,
  `fb_userid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `background_style` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thread_notify` int(1) DEFAULT '1',
  `background_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_signature` text COLLATE utf8mb4_unicode_ci,
  `language` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `login_before` int(11) DEFAULT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled` int(1) DEFAULT '1',
  `time_zone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fb_username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `unsubscribed` int(1) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabUser`
--

LOCK TABLES `tabUser` WRITE;
/*!40000 ALTER TABLE `tabUser` DISABLE KEYS */;
INSERT INTO `tabUser` VALUES ('Administrator','2015-04-04 15:11:30.948586','2015-04-04 15:11:31.597480','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,'https://secure.gravatar.com/avatar/7b7bc2512ee1fedcd76bdc68926d4f7b?d=retro',NULL,'System User',NULL,NULL,NULL,NULL,NULL,'Administrator',NULL,'',NULL,NULL,NULL,'admin@example.com',NULL,NULL,NULL,'Fill Screen',1,NULL,NULL,NULL,NULL,'',1,NULL,NULL,NULL,0),('Guest','2015-04-04 15:11:31.004291','2015-04-04 15:11:31.024758','Administrator','Administrator',0,NULL,NULL,NULL,NULL,NULL,'https://secure.gravatar.com/avatar/adb831a7fdd83dd1e2a309ce7591dff8?d=retro',NULL,'System User',NULL,NULL,NULL,NULL,NULL,'Guest',NULL,'',NULL,NULL,NULL,'guest@example.com',NULL,NULL,NULL,'Fill Screen',1,NULL,NULL,NULL,NULL,'',1,NULL,NULL,NULL,0);
/*!40000 ALTER TABLE `tabUser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabUserRole`
--

DROP TABLE IF EXISTS `tabUserRole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabUserRole` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabUserRole`
--

LOCK TABLES `tabUserRole` WRITE;
/*!40000 ALTER TABLE `tabUserRole` DISABLE KEYS */;
INSERT INTO `tabUserRole` VALUES ('06b1eb666c','2015-04-04 15:11:30.948586','2015-04-04 15:11:31.564711','Administrator','Administrator',0,'Administrator','user_roles','User',3,'Blogger'),('1af408178f','2015-04-04 15:11:30.948586','2015-04-04 15:11:31.564711','Administrator','Administrator',0,'Administrator','user_roles','User',2,'All'),('1e2c66e4fe','2015-04-04 15:11:30.948586','2015-04-04 15:11:31.564711','Administrator','Administrator',0,'Administrator','user_roles','User',7,'Website Manager'),('3e31523deb','2015-04-04 15:11:30.948586','2015-04-04 15:11:31.564711','Administrator','Administrator',0,'Administrator','user_roles','User',6,'System Manager'),('749099261d','2015-04-04 15:11:31.027374','2015-04-04 15:11:31.564711','Administrator','Administrator',0,'Administrator','user_roles','User',1,'Administrator'),('d17957452a','2015-04-04 15:11:31.031341','2015-04-04 15:11:31.031341','Administrator','Administrator',0,'Guest','user_roles','User',NULL,'Guest'),('d467cc29e0','2015-04-04 15:11:30.948586','2015-04-04 15:11:31.564711','Administrator','Administrator',0,'Administrator','user_roles','User',5,'Report Manager'),('e37a3faa6f','2015-04-04 15:11:30.948586','2015-04-04 15:11:31.564711','Administrator','Administrator',0,'Administrator','user_roles','User',4,'Guest');
/*!40000 ALTER TABLE `tabUserRole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabVersion`
--

DROP TABLE IF EXISTS `tabVersion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabVersion` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `docname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `doclist_json` longtext COLLATE utf8mb4_unicode_ci,
  `ref_doctype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabVersion`
--

LOCK TABLES `tabVersion` WRITE;
/*!40000 ALTER TABLE `tabVersion` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabVersion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWeb Form`
--

DROP TABLE IF EXISTS `tabWeb Form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWeb Form` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `allow_edit` int(1) DEFAULT NULL,
  `doc_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allow_comments` int(1) DEFAULT NULL,
  `allow_multiple` int(1) DEFAULT NULL,
  `breadcrumbs` text COLLATE utf8mb4_unicode_ci,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `login_required` int(1) DEFAULT NULL,
  `page_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allow_delete` int(1) DEFAULT NULL,
  `success_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `success_message` text COLLATE utf8mb4_unicode_ci,
  `published` int(1) DEFAULT NULL,
  `web_page_link_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `introduction_text` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWeb Form`
--

LOCK TABLES `tabWeb Form` WRITE;
/*!40000 ALTER TABLE `tabWeb Form` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabWeb Form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWeb Form Field`
--

DROP TABLE IF EXISTS `tabWeb Form Field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWeb Form Field` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `read_only` int(1) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `default` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fieldname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fieldtype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reqd` int(1) DEFAULT NULL,
  `hidden` int(1) DEFAULT NULL,
  `options` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWeb Form Field`
--

LOCK TABLES `tabWeb Form Field` WRITE;
/*!40000 ALTER TABLE `tabWeb Form Field` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabWeb Form Field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWeb Page`
--

DROP TABLE IF EXISTS `tabWeb Page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWeb Page` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `insert_style` int(1) DEFAULT NULL,
  `parent_website_route` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `header` text COLLATE utf8mb4_unicode_ci,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text_align` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `page_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enable_comments` int(1) DEFAULT NULL,
  `parent_web_page` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `css` longtext COLLATE utf8mb4_unicode_ci,
  `description` text COLLATE utf8mb4_unicode_ci,
  `insert_code` int(1) DEFAULT NULL,
  `javascript` longtext COLLATE utf8mb4_unicode_ci,
  `slideshow` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_title` int(1) DEFAULT '1',
  `main_section` longtext COLLATE utf8mb4_unicode_ci,
  `template_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published` int(1) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWeb Page`
--

LOCK TABLES `tabWeb Page` WRITE;
/*!40000 ALTER TABLE `tabWeb Page` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabWeb Page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWebsite Slideshow`
--

DROP TABLE IF EXISTS `tabWebsite Slideshow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWebsite Slideshow` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `slideshow_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `header` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWebsite Slideshow`
--

LOCK TABLES `tabWebsite Slideshow` WRITE;
/*!40000 ALTER TABLE `tabWebsite Slideshow` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabWebsite Slideshow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWebsite Slideshow Item`
--

DROP TABLE IF EXISTS `tabWebsite Slideshow Item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWebsite Slideshow Item` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `heading` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWebsite Slideshow Item`
--

LOCK TABLES `tabWebsite Slideshow Item` WRITE;
/*!40000 ALTER TABLE `tabWebsite Slideshow Item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabWebsite Slideshow Item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWebsite Theme`
--

DROP TABLE IF EXISTS `tabWebsite Theme`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWebsite Theme` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `heading_style` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bootstrap` text COLLATE utf8mb4_unicode_ci,
  `link_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `module` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Website',
  `footer_text_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `heading_webfont` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `background_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `apply_style` int(1) DEFAULT '1',
  `background_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `top_bar_text_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom` int(1) DEFAULT '1',
  `theme` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `css` longtext COLLATE utf8mb4_unicode_ci,
  `text_webfont` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `js` longtext COLLATE utf8mb4_unicode_ci,
  `font_size` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `no_sidebar` int(1) DEFAULT NULL,
  `top_bar_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `theme` (`theme`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWebsite Theme`
--

LOCK TABLES `tabWebsite Theme` WRITE;
/*!40000 ALTER TABLE `tabWebsite Theme` DISABLE KEYS */;
INSERT INTO `tabWebsite Theme` VALUES ('Standard','2015-02-19 13:37:33.925909','2015-02-19 20:01:19.478005','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'',NULL,NULL,'Website',NULL,NULL,NULL,1,NULL,NULL,0,'Standard',NULL,NULL,NULL,NULL,NULL,'14px',NULL,NULL);
/*!40000 ALTER TABLE `tabWebsite Theme` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWorkflow`
--

DROP TABLE IF EXISTS `tabWorkflow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWorkflow` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `workflow_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` int(1) DEFAULT NULL,
  `workflow_state_field` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'workflow_state',
  `document_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWorkflow`
--

LOCK TABLES `tabWorkflow` WRITE;
/*!40000 ALTER TABLE `tabWorkflow` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabWorkflow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWorkflow Action`
--

DROP TABLE IF EXISTS `tabWorkflow Action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWorkflow Action` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `workflow_action_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWorkflow Action`
--

LOCK TABLES `tabWorkflow Action` WRITE;
/*!40000 ALTER TABLE `tabWorkflow Action` DISABLE KEYS */;
INSERT INTO `tabWorkflow Action` VALUES ('Approve','2015-04-04 15:11:31.075336','2015-04-04 15:11:31.075336','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Approve'),('Reject','2015-04-04 15:11:31.078675','2015-04-04 15:11:31.078675','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Reject'),('Review','2015-04-04 15:11:31.081932','2015-04-04 15:11:31.081932','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Review');
/*!40000 ALTER TABLE `tabWorkflow Action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWorkflow Document State`
--

DROP TABLE IF EXISTS `tabWorkflow Document State`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWorkflow Document State` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `allow_edit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `update_field` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `update_value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `doc_status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWorkflow Document State`
--

LOCK TABLES `tabWorkflow Document State` WRITE;
/*!40000 ALTER TABLE `tabWorkflow Document State` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabWorkflow Document State` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWorkflow State`
--

DROP TABLE IF EXISTS `tabWorkflow State`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWorkflow State` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `style` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workflow_state_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWorkflow State`
--

LOCK TABLES `tabWorkflow State` WRITE;
/*!40000 ALTER TABLE `tabWorkflow State` DISABLE KEYS */;
INSERT INTO `tabWorkflow State` VALUES ('Approved','2015-04-04 15:11:31.060709','2015-04-04 15:11:31.060709','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Success','Approved','ok-sign'),('Pending','2015-04-04 15:11:31.056904','2015-04-04 15:11:31.056904','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'','Pending','question-sign'),('Rejected','2015-04-04 15:11:31.064192','2015-04-04 15:11:31.064192','Administrator','Administrator',0,NULL,NULL,NULL,NULL,'Danger','Rejected','remove');
/*!40000 ALTER TABLE `tabWorkflow State` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tabWorkflow Transition`
--

DROP TABLE IF EXISTS `tabWorkflow Transition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tabWorkflow Transition` (
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creation` datetime(6) DEFAULT NULL,
  `modified` datetime(6) DEFAULT NULL,
  `modified_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `docstatus` int(1) DEFAULT '0',
  `parent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parentfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parenttype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `idx` int(8) DEFAULT NULL,
  `action` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `allowed` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `next_state` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `parent` (`parent`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPRESSED;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tabWorkflow Transition`
--

LOCK TABLES `tabWorkflow Transition` WRITE;
/*!40000 ALTER TABLE `tabWorkflow Transition` DISABLE KEYS */;
/*!40000 ALTER TABLE `tabWorkflow Transition` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-04 15:12:51
